package cons

const Version = "1.0.3 beta"
const VerDate = "2021-04-25 12:00:00"
