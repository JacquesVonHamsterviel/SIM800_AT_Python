package cons

const (
	JsonErrDefault         = 1
	JsonErrTTYCall         = 1201
	JsonErrTTYUSB          = 1202
	JsonErrAliyunAccess    = 1301
	JsonErrAliyunISIAppKey = 1302
	JsonErrAliyunOSS       = 1303
)
