package cmd

func CheckNetwork() {
	return
}

func LoopNetwork() {
	return
}
