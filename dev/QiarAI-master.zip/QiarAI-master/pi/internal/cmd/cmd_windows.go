package cmd

import (
	"VGO/pi/internal/pkg/file"
	"time"
)

var basePath = "cmd"
var logIO *file.Log
var Pid = 0

func Bash(exe string) string {
	return ""
}

func Shell(sh string, timeout time.Duration) {
	return
}
