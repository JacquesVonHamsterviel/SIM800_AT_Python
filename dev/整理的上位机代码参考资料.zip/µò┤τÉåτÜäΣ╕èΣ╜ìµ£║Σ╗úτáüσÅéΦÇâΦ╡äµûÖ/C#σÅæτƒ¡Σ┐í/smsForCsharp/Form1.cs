using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Threading;
using System.Text;
using JustinIO;
using SMS;
using System.IO;


namespace smsForCsharp
{
	/// <summary>
	/// Form1 ��ժҪ˵����
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		static  JustinIO.CommPort ss_port = new JustinIO.CommPort();
		PDUdecoding sms = new SMS.PDUdecoding();
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.TextBox targetNumber;
		private System.Windows.Forms.TextBox CenterNumber;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label ConnectState;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.Button btnSend;
		private System.Windows.Forms.Button btnConnect;
		private System.Windows.Forms.Button btnExit;
		private System.Windows.Forms.TextBox smsState;
		private System.Windows.Forms.TextBox smsContent;
		private System.Windows.Forms.ComboBox ConnectPort;
		private System.Windows.Forms.ComboBox ConnectBaudRate;
		private System.Windows.Forms.Button about;
		
		/// <summary>
		/// ����������������
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Windows ���������֧���������
			//
			InitializeComponent();

			//
			// TODO: �� InitializeComponent ���ú������κι��캯������
			//
		}

		/// <summary>
		/// ������������ʹ�õ���Դ��
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// �����֧������ķ��� - ��Ҫʹ�ô���༭���޸�
		/// �˷��������ݡ�
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.smsState = new System.Windows.Forms.TextBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.smsContent = new System.Windows.Forms.TextBox();
			this.targetNumber = new System.Windows.Forms.TextBox();
			this.CenterNumber = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.ConnectState = new System.Windows.Forms.Label();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.ConnectBaudRate = new System.Windows.Forms.ComboBox();
			this.ConnectPort = new System.Windows.Forms.ComboBox();
			this.btnSend = new System.Windows.Forms.Button();
			this.btnConnect = new System.Windows.Forms.Button();
			this.btnExit = new System.Windows.Forms.Button();
			this.about = new System.Windows.Forms.Button();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(0, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(72, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "�Է��ֻ���:";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(272, 8);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(72, 16);
			this.label2.TabIndex = 1;
			this.label2.Text = "�������ĺ�:";
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.smsState});
			this.groupBox1.Location = new System.Drawing.Point(0, 32);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(496, 136);
			this.groupBox1.TabIndex = 3;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "���ŷ���״̬";
			// 
			// smsState
			// 
			this.smsState.Location = new System.Drawing.Point(8, 16);
			this.smsState.Multiline = true;
			this.smsState.Name = "smsState";
			this.smsState.ReadOnly = true;
			this.smsState.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
			this.smsState.Size = new System.Drawing.Size(480, 112);
			this.smsState.TabIndex = 0;
			this.smsState.Text = "";
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.smsContent});
			this.groupBox2.Location = new System.Drawing.Point(0, 176);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(248, 152);
			this.groupBox2.TabIndex = 4;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "��������";
			// 
			// smsContent
			// 
			this.smsContent.Location = new System.Drawing.Point(8, 17);
			this.smsContent.Multiline = true;
			this.smsContent.Name = "smsContent";
			this.smsContent.Size = new System.Drawing.Size(229, 127);
			this.smsContent.TabIndex = 0;
			this.smsContent.Text = "";
			// 
			// targetNumber
			// 
			this.targetNumber.Location = new System.Drawing.Point(72, 8);
			this.targetNumber.Name = "targetNumber";
			this.targetNumber.TabIndex = 5;
			this.targetNumber.Text = "";
			// 
			// CenterNumber
			// 
			this.CenterNumber.Location = new System.Drawing.Point(344, 8);
			this.CenterNumber.Name = "CenterNumber";
			this.CenterNumber.TabIndex = 6;
			this.CenterNumber.Text = "";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(24, 24);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(66, 14);
			this.label3.TabIndex = 7;
			this.label3.Text = "ͨ�Ŷ˿ڣ�";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(24, 56);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(66, 14);
			this.label4.TabIndex = 8;
			this.label4.Text = "�� �� �ʣ�";
			// 
			// ConnectState
			// 
			this.ConnectState.BackColor = System.Drawing.SystemColors.Control;
			this.ConnectState.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.ConnectState.ForeColor = System.Drawing.Color.Red;
			this.ConnectState.Location = new System.Drawing.Point(8, 80);
			this.ConnectState.Name = "ConnectState";
			this.ConnectState.Size = new System.Drawing.Size(224, 16);
			this.ConnectState.TabIndex = 10;
			this.ConnectState.Text = "��δ���κ��豸����";
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.ConnectBaudRate,
																					this.ConnectPort,
																					this.ConnectState,
																					this.label3,
																					this.label4});
			this.groupBox3.Location = new System.Drawing.Point(248, 176);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(240, 104);
			this.groupBox3.TabIndex = 0;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "�˿�����";
			// 
			// ConnectBaudRate
			// 
			this.ConnectBaudRate.Items.AddRange(new object[] {
																 "9600",
																 "14400",
																 "19200",
																 "57600"});
			this.ConnectBaudRate.Location = new System.Drawing.Point(120, 56);
			this.ConnectBaudRate.Name = "ConnectBaudRate";
			this.ConnectBaudRate.Size = new System.Drawing.Size(80, 20);
			this.ConnectBaudRate.TabIndex = 12;
			this.ConnectBaudRate.Text = "19200";
			// 
			// ConnectPort
			// 
			this.ConnectPort.Items.AddRange(new object[] {
															 "COM1",
															 "COM2",
															 "COM3",
															 "COM4"});
			this.ConnectPort.Location = new System.Drawing.Point(120, 24);
			this.ConnectPort.Name = "ConnectPort";
			this.ConnectPort.Size = new System.Drawing.Size(80, 20);
			this.ConnectPort.TabIndex = 11;
			this.ConnectPort.Text = "COM1";
			// 
			// btnSend
			// 
			this.btnSend.Enabled = false;
			this.btnSend.Location = new System.Drawing.Point(256, 288);
			this.btnSend.Name = "btnSend";
			this.btnSend.Size = new System.Drawing.Size(48, 32);
			this.btnSend.TabIndex = 0;
			this.btnSend.Text = "����";
			this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
			// 
			// btnConnect
			// 
			this.btnConnect.Location = new System.Drawing.Point(312, 288);
			this.btnConnect.Name = "btnConnect";
			this.btnConnect.Size = new System.Drawing.Size(48, 32);
			this.btnConnect.TabIndex = 1;
			this.btnConnect.Text = "����";
			this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
			// 
			// btnExit
			// 
			this.btnExit.Location = new System.Drawing.Point(438, 288);
			this.btnExit.Name = "btnExit";
			this.btnExit.Size = new System.Drawing.Size(48, 32);
			this.btnExit.TabIndex = 3;
			this.btnExit.Text = "�˳�";
			this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
			// 
			// about
			// 
			this.about.Location = new System.Drawing.Point(376, 288);
			this.about.Name = "about";
			this.about.Size = new System.Drawing.Size(48, 32);
			this.about.TabIndex = 7;
			this.about.Text = "˵��";
			this.about.Click += new System.EventHandler(this.about_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(6, 14);
			this.ClientSize = new System.Drawing.Size(504, 333);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.about,
																		  this.CenterNumber,
																		  this.targetNumber,
																		  this.groupBox2,
																		  this.groupBox1,
																		  this.label2,
																		  this.label1,
																		  this.groupBox3,
																		  this.btnExit,
																		  this.btnConnect,
																		  this.btnSend});
			this.Name = "Form1";
			this.Text = "�ն˶���C#�� ---- �켫��";
			this.groupBox1.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.groupBox3.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// Ӧ�ó��������ڵ㡣
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		/// <summary>
		/// ��ʼ������
		/// </summary>
		public bool InitCom(string m_port, int m_baudrate)
		{
			ss_port.PortNum = m_port;
			ss_port.BaudRate = m_baudrate;
			ss_port.ByteSize = 8;
			ss_port.Parity = 0;
			ss_port.StopBits = 1;
			ss_port.ReadTimeout = 1000;
			try
			{
				if (ss_port.Opened)
				{
					ss_port.Close();
					ss_port.Open();
				}
				else
				{
					ss_port.Open();//�򿪴���
				}
				return true;
			}
			catch
				(Exception e) 
			{
				MessageBox.Show("����" + e.Message);
				return false;
			}
		}

		/// <summary>
		/// ��ʼ�����룬����ȡ�ֻ������Ϣ
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnConnect_Click(object sender, System.EventArgs e)
		{
			bool opened = InitCom(ConnectPort.SelectedItem.ToString(),Convert.ToInt32(ConnectBaudRate.SelectedItem.ToString()));
			bool Connected = false;
			if (opened)
			{
				ss_port.Write(Encoding.ASCII.GetBytes("AT+CGMI\r")); //��ȡ�ֻ�Ʒ��
				string response = Encoding.ASCII.GetString(ss_port.Read(128));
				if (response.Length > 0)
				{
					ConnectState.Text = response.Substring(10,7);
					Connected = true;
				}
			else
				 {
					ConnectState.Text = "���ֻ����Ӳ��ɹ�";
					Connected = false;
				 }
				ss_port.Write(Encoding.ASCII.GetBytes("AT+CGMM\r"));//��ȡ�ֻ��ͺ�
				response = Encoding.ASCII.GetString(ss_port.Read(128));
				if(response.Length > 0)
				{
					ConnectState.Text =ConnectState.Text+ " " + response.Substring(10,5) + "  ������......";
					Connected = true;
				}
				else
				{
					ConnectState.Text = "���ֻ����Ӳ��ɹ�";
					Connected = false;
				}
				ss_port.Write(Encoding.ASCII.GetBytes("AT+CSCA?\r"));//��ȡ�ֻ��������ĺ�
                response = Encoding.ASCII.GetString(ss_port.Read(128));
				if(response.Length > 0)
				{
					CenterNumber.Text = response.Substring(20,13);
					Connected = true;
				}
				else
				{
					Connected = false;
				}
				if (Connected == true)
				{
					btnConnect.Enabled = false;
					btnSend.Enabled = true;
				}
				else
				{
					btnConnect.Enabled = true;
					btnSend.Enabled = false;
				}
			}
		}

		/// <summary>
		/// ���Ͷ���
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnSend_Click(object sender, System.EventArgs e)
		{
			string decodedSMS = sms.smsDecodedsms(CenterNumber.Text,targetNumber.Text,smsContent.Text);
			byte[] buf =Encoding.ASCII.GetBytes(String.Format("AT+CMGS={0}\r",sms.nLength));
			ss_port.Write(buf);
			string response = Encoding.ASCII.GetString(ss_port.Read(128));
			string SendState = "";
			if( response.Length > 0 && response.EndsWith("> "))
			{
				ss_port.Write(Encoding.ASCII.GetBytes(String.Format("{0}\x01a",decodedSMS)));
				SendState = "���ͳɹ�!";
			}
			else
			{
				SendState = "����ʧ��";
			}

			string Result = String.Format("{0},{1},{2}��\n\r",targetNumber.Text,smsContent.Text,SendState);
			smsState.Text += Result;
		}

		/// <summary>
		/// �رմ��ڣ��˳�����
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnExit_Click(object sender, System.EventArgs e)
		{
			ss_port.Close();
			Application.Exit();
		}

		private void about_Click(object sender, System.EventArgs e)
		{
			Form about = new about();
			about.ShowDialog();
		}
	}
}