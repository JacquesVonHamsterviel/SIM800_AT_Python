
#pragma once

#define DEFAULT_PORT	5000

#define SMPP_VERSION_33			0x33
#define SMPP_VERSION_34			0x34
#define SMPP_INTERFACE_VERSION	0x34

#ifdef SMPPLIB_EXPORTING
   #define SMPPLIB_DECLSPEC    __declspec(dllexport)
#else
   #define SMPPLIB_DECLSPEC    __declspec(dllimport)
#endif


typedef unsigned short  ushort;
typedef unsigned int    uint;
typedef unsigned char	uchar;
typedef char	int8;				/* Signed integer >= 8	bits */
typedef short	int16;				/* Signed integer >= 16 bits */
typedef unsigned char	uint8;		/* Short for unsigned integer >= 8  bits */
typedef unsigned short	uint16;		/* Short for unsigned integer >= 16 bits */
typedef int		int32;
typedef unsigned int	uint32;		/* Short for unsigned integer >= 32 bits */
typedef unsigned long ulong;
typedef unsigned hyper ulonglong;



//Starting here, for Big Endian defition
#define storeInt(T, A) {	\
	*((T)+3) =	(uchar) ((A));	\
	*((T)+2) = (uchar) (((A) >> 8));	\
	*((T)+1) = (uchar) (((A) >> 16));	\
	*(T) = (uchar) (((A) >> 24)); }

#define storeInt2(T, A) {	\
	*((T)+1) = (uchar) (((A)));	\
	*(T) = (uchar) (((A) >> 8)); }

#define readInt(A)	((int) (	\
				    (((int) ((uchar) (A)[0])) << 24) +\
				    (((uint32) ((uchar) (A)[1])) << 16) +\
				    (((uint32) ((uchar) (A)[2])) << 8) +\
					((uchar) (A)[3])))

#define readInt2(A)	((int) (	\
				    (((int) ((uchar) (A)[0])) << 8) +\
					((uchar) (A)[1])))