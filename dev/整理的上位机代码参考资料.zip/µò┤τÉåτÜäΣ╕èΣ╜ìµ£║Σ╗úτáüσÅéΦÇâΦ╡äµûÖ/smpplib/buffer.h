// Buffer.h: interface for the CBuffer class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BUFFER_H__829F6693_AC4D_11D2_8C37_00600877E420__INCLUDED_)
#define AFX_BUFFER_H__829F6693_AC4D_11D2_8C37_00600877E420__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "common.h"

//##ModelId=3B70A76902BD
class /*CLASS_DECLSPEC*/ CBuffer  
{
// Attributes
protected:
	//##ModelId=3B70A76902C7
	PBYTE	m_pBase;
	//##ModelId=3B70A76902DB
	PBYTE	m_pPtr;
	//##ModelId=3B70A76902E5
	UINT	m_nSize;

// Methods
protected:
	//##ModelId=3B70A76902EF
	UINT ReAllocateBuffer(UINT nRequestedSize);
	//##ModelId=3B70A7690303
	UINT DeAllocateBuffer(UINT nRequestedSize);
	//##ModelId=3B70A7690317
	UINT GetMemSize();

	//##ModelId=3B70A7690321
	CRITICAL_SECTION	m_cs;

public:
	//##ModelId=3B70A7690335
	void ClearBuffer();

	//##ModelId=3B70A7690336
	UINT Delete(UINT nSize);
	//##ModelId=3B70A7690349
	UINT Read(PBYTE pData, UINT nSize);
	//##ModelId=3B70A769035D
	BOOL Write(PBYTE pData, UINT nSize);
	//##ModelId=3B70A7690371
	BOOL Write(CString& strData);

	BOOL WriteNULL();

	//##ModelId=3B70A769037C
	UINT GetBufferLen();
	//##ModelId=3B70A769038F
	int Scan(PBYTE pScan,UINT nPos);
	//##ModelId=3B70A769039A
	BOOL Insert(PBYTE pData, UINT nSize);
	//##ModelId=3B70A76903B7
	BOOL Insert(CString& strData);

	//##ModelId=3B70A76903C1
	void Copy(CBuffer& buffer);	

	//##ModelId=3B70A76903CB
	PBYTE GetBuffer(UINT nPos=0);

	//##ModelId=3B70A76903D5
	CBuffer();
	//##ModelId=3B70A76903DF
	virtual ~CBuffer();

	//##ModelId=3B70A76A000B
	void FileWrite(const CString& strFileName);

};

#endif // !defined(AFX_BUFFER_H__829F6693_AC4D_11D2_8C37_00600877E420__INCLUDED_)
