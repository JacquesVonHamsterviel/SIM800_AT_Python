// EsmeTransceiver.cpp: implementation of the CEsmeTransceiver class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
//#include "SMPPAPI.h"
#include "EsmeTransceiver.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

#ifdef SMPPAPI_EVALUATION
	uint32 CEsmeTransceiver::m_eval_counter = 1;
#endif

CEsmeTransceiver::CEsmeTransceiver()
{
}

CEsmeTransceiver::~CEsmeTransceiver()
{

}

int CEsmeTransceiver::bind(CString sysid, CString passwd, CString systype, CSmppAddress &addrrange)
{
	bool ret = 1;

	m_system_id = sysid;
	m_password = passwd;
	m_system_type = systype;

	m_address_range = addrrange;

	if (open())
	{
		CBindTransceiver	pak;

		pak.setSystemId(sysid);
		pak.setPassword(passwd);
		pak.setSystemType(systype);

		pak.setSourceRange(addrrange);

		if (sendPacket(pak))
			ret = 0;
	}

	return ret;
}

int CEsmeTransceiver::submitMessage(CSubmitSM &pak)
{
	#ifdef SMPPAPI_EVALUATION
		m_eval_counter++;
		if (m_eval_counter > 200)
			return 1;
	#endif

	sendPacket(pak);

	return 0;
}

int CEsmeTransceiver::submitMessage(CString msg, CString dst, uint32 ton, uint32 npi)
{
	CSmppAddress dst_addr(ton, npi, dst);

	return submitMessage(msg, dst_addr);
}

int CEsmeTransceiver::submitMessage(CString msg, CSmppAddress &dst)
{
	CSubmitSM s;

	s.setMessage( (PBYTE) msg.GetBuffer(0), msg.GetLength());
	msg.ReleaseBuffer();

	s.setDestination(dst);
	s.setSource(m_address_range);

	return submitMessage(s);

}

int CEsmeTransceiver::submitMessage(PBYTE msg, uint32 msglen, uint32 enc, CSmppAddress &dst, uint32 esm)
{
		CSubmitSM s;

		s.setMessage(msg, msglen);
		s.setDestination(dst);
		s.setSource(m_address_range);
		s.setDataCoding(enc);
		s.setEsmClass(esm);

		return submitMessage(s);

}

void CEsmeTransceiver::parse_packet(PBYTE pby, int nsz)
{
	#ifdef SMPPAPI_EVALUATION
		m_eval_counter++;
		if (m_eval_counter > 200)
			return;
	#endif

	if (nsz < 16)
		return;

	uint32 cmdId = readInt(pby);

#ifdef _DEBUG

	TCHAR buff[100];
	sprintf(buff, "CommandId is %x", cmdId);
	TRACE(buff);

#endif

	int cmdStatus = readInt(pby+4);
	int seqNum = readInt(pby+8);

	switch (cmdId)
	{
		case SMPP_GENERIC_NACK:
		{
			CGenericNack* ppak;
			ppak = new CGenericNack();
			ppak->loadPacket(pby, nsz);

			//call back
			if (m_pProcessPacket != NULL)
			{
				m_pProcessPacket(ppak, m_Param);
			}

			delete ppak;
		}
			break;

		case SMPP_SPECIAL_LINKCLOSE:
		{
			CLinkClose* ppak;
			ppak = new CLinkClose();
			ppak->loadPacket(pby, nsz);

			//call back
			if (m_pProcessPacket != NULL)
			{
				m_pProcessPacket(ppak, m_Param);
			}

			delete ppak;
		}
			break;

		case SMPP_BIND_TRANSCEIVER_RESP:
		{
			CBindTransceiverResp* ppak;
			ppak = new CBindTransceiverResp();
			ppak->loadPacket(pby, nsz);

			//call back
			if (m_pProcessPacket != NULL)
			{
				m_pProcessPacket(ppak, m_Param);
			}

			delete ppak;
		}
			break;
			
		case SMPP_SUBMIT_SM_RESP:
		{
			CSubmitSMResp* ppak;
			ppak = new CSubmitSMResp();
			ppak->loadPacket(pby, nsz);

			//call back
			if (m_pProcessPacket != NULL)
			{
				m_pProcessPacket(ppak, m_Param);
			}

			delete ppak;
		}
			break;

		case SMPP_QUERY_SM_RESP:
		{
			CQuerySMResp* ppak;
			ppak = new CQuerySMResp();
			ppak->loadPacket(pby, nsz);

			//call back
			if (m_pProcessPacket != NULL)
			{
				m_pProcessPacket(ppak, m_Param);
			}

			delete ppak;
		}
			break;

		case SMPP_UNBIND_RESP:
		{
			CUnbindResp* ppak;
			ppak = new CUnbindResp();
			ppak->loadPacket(pby, nsz);

			//call back
			if (m_pProcessPacket != NULL)
			{
				m_pProcessPacket(ppak, m_Param);
			}

			delete ppak;
		}
			break;

		case SMPP_DELIVER_SM:
		{
			CDeliverSM*	ppak;
			ppak = new CDeliverSM();
			ppak->loadPacket(pby, nsz);

			//call back
			if (m_pProcessPacket != NULL)
			{
				m_pProcessPacket(ppak, m_Param);
			}

			delete ppak;
		}
			break;

		case SMPP_ENQUIRE_LINK:
		{
			CEnquireLink* ppak;
			ppak = new CEnquireLink();
			ppak->loadPacket(pby, nsz);

			//call back
			if (m_pProcessPacket != NULL)
			{
				m_pProcessPacket(ppak, m_Param);
			}

			delete ppak;
		}
			break;

		case SMPP_ENQUIRE_LINK_RESP:
		{
			CEnquireLinkResp* ppak;
			ppak = new CEnquireLinkResp();
			ppak->loadPacket(pby, nsz);

			//call back
			if (m_pProcessPacket != NULL)
			{
				m_pProcessPacket(ppak, m_Param);
			}

			delete ppak;
		}
			break;

		default:
			break;
	}
}
