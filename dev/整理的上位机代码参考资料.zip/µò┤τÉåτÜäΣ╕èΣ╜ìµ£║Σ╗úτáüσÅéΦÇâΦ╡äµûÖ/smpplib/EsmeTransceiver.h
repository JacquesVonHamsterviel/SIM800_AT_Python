// EsmeTransceiver.h: interface for the CEsmeTransceiver class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ESMETRANSCEIVER_H__B53152CE_79FD_401D_AD5E_E0A43F82F65C__INCLUDED_)
#define AFX_ESMETRANSCEIVER_H__B53152CE_79FD_401D_AD5E_E0A43F82F65C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "smpppacket.h"
#include "SmppConnection.h"

class SMPPLIB_DECLSPEC CEsmeTransceiver : public CSmppConnection 
{
public:
	CEsmeTransceiver();
	virtual ~CEsmeTransceiver();

	int bind(CString sysid, CString passwd, CString systype, CSmppAddress &srcrange);

	int submitMessage(CSubmitSM &pak);
	int submitMessage(CString msg, CString dst, uint32 ton, uint32 npi);
	int submitMessage(CString msg, CSmppAddress &dst);
	int submitMessage(PBYTE msg, uint32 msglen, uint32 enc, CSmppAddress &dst, uint32 esm = 0);

protected:
	void parse_packet(PBYTE pby, int nsz);

	#ifdef SMPPAPI_EVALUATION
		static uint32 m_eval_counter;
	#endif

};

#endif // !defined(AFX_ESMETRANSCEIVER_H__B53152CE_79FD_401D_AD5E_E0A43F82F65C__INCLUDED_)
