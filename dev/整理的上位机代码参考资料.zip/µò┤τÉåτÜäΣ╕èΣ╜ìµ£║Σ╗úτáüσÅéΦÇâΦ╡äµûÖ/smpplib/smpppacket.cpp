#include "stdafx.h"
#include "smpppacket.h"
#include "smpp.h"


CLinkClose::CLinkClose()
{
	setCommandId(SMPP_SPECIAL_LINKCLOSE);
}

CLinkClose::~CLinkClose()
{
}

void CLinkClose::encodeBody(PBYTE &pby, int &nsz)
{
	CPacketBase::encodeBody(pby, nsz);

	nsz = m_buffer.GetBufferLen();
	pby = new byte[nsz];

	memcpy(pby, m_buffer.GetBuffer(), nsz);
}

CBindTransmitter::CBindTransmitter()
{
	setCommandId(SMPP_BIND_TRANSMITTER);
}

CBindTransmitter::~CBindTransmitter()
{
}

CBindReceiver::CBindReceiver()
{
	setCommandId(SMPP_BIND_RECEIVER);
}

CBindReceiver::~CBindReceiver()
{
}

CBindTransceiver::CBindTransceiver()
{
	setCommandId(SMPP_BIND_TRANSCEIVER);
}

CBindTransceiver::~CBindTransceiver()
{
}

CQuerySM::CQuerySM()
{
	m_message_id = "";
	setCommandId(SMPP_QUERY_SM);
}

CQuerySM::~CQuerySM()
{
}

CString CQuerySM::getMessageId()
{
	return m_message_id;
}

void CQuerySM::setMessageId(CString msgid)
{
	m_message_id = msgid;
}

void CQuerySM::encodeBody(PBYTE &pby, int &nsz)
{
	CPacketBase::encodeBody(pby, nsz);

	BYTE by;

	m_buffer.Write(m_message_id);
	m_buffer.WriteNULL();

	by = static_cast<byte>(m_source.m_addr_ton);
	m_buffer.Write(&by, 1);

	by = static_cast<byte>(m_source.m_addr_npi);
	m_buffer.Write(&by, 1);

	m_buffer.Write(m_source.m_addr);
	m_buffer.WriteNULL();

	nsz = m_buffer.GetBufferLen();
	pby = new byte[nsz];

	ASSERT( getCommandLength() == static_cast<uint32>(nsz));

	memcpy(pby, m_buffer.GetBuffer(), nsz);
}

bool CQuerySM::loadPacket(PBYTE pby, int nsz)
{
	if (!CPacketBase::loadPacket(pby, nsz))
		return false;

	if (getCommandStatus() != 0)
		return false;

	int pos = 12;

	m_message_id = (LPTSTR) pby+pos;
	pos += m_message_id.GetLength() + 1;

	m_source.setAddrTon(*(pby+pos));
	pos += 1;
	m_source.setAddrNpi(*(pby+pos));
	pos += 1;
	m_source.m_addr = (LPTSTR) pby+pos;
	pos += m_source.m_addr.GetLength() + 1;

	return true;
}

uint32 CQuerySM::getCommandLength()
{
	int len = (CPacketBase::getCommandLength()
		+ ((!m_message_id.IsEmpty()) ? m_message_id.GetLength() : 0)
		+ (m_source.getLength()) );

	return (len + 1);
}

CUnbind::CUnbind()
{
	setCommandId(SMPP_UNBIND);
}

CUnbind::~CUnbind()
{
}

void CUnbind::encodeBody(PBYTE &pby, int &nsz)
{
	CPacketBase::encodeBody(pby, nsz);

	nsz = m_buffer.GetBufferLen();
	pby = new byte[nsz];

	memcpy(pby, m_buffer.GetBuffer(), nsz);
}

CSubmitSM::CSubmitSM()
{
	setCommandId(SMPP_SUBMIT_SM);
}

CSubmitSM::~CSubmitSM()
{
}

CDeliverSM::CDeliverSM()
{
	setCommandId(SMPP_DELIVER_SM);
}

CDeliverSM::~CDeliverSM()
{
}

CDataSM::CDataSM()
{
	setCommandId(SMPP_DATA_SM);
}

CDataSM::~CDataSM()
{
}

CDataSMResp::CDataSMResp()
{
	setCommandId(SMPP_DATA_SM_RESP);
}

CDataSMResp::CDataSMResp(CDataSM &pak)
{
	setCommandId(SMPP_DATA_SM_RESP);
	setSequenceNumber(pak.getSequenceNumber());
}

CDataSMResp::~CDataSMResp()
{
}

CBindTransmitterResp::CBindTransmitterResp()
{
	setCommandId(SMPP_BIND_TRANSMITTER_RESP);
}

CBindTransmitterResp::CBindTransmitterResp(CBindTransmitter &pak)
{
	setCommandId(SMPP_BIND_TRANSMITTER_RESP);
	setSequenceNumber(pak.getSequenceNumber());
}

CBindTransmitterResp::~CBindTransmitterResp()
{
}

CBindReceiverResp::CBindReceiverResp()
{
	setCommandId(SMPP_BIND_RECEIVER_RESP);
}

CBindReceiverResp::CBindReceiverResp(CBindReceiver &pak)
{
	setCommandId(SMPP_BIND_RECEIVER_RESP);
	setSequenceNumber(pak.getSequenceNumber());
}

CBindReceiverResp::~CBindReceiverResp()
{
}

CBindTransceiverResp::CBindTransceiverResp()
{
	setCommandId(SMPP_BIND_TRANSCEIVER_RESP);
}

CBindTransceiverResp::CBindTransceiverResp(CBindTransceiver &pak)
{
	setCommandId(SMPP_BIND_TRANSCEIVER_RESP);
	setSequenceNumber(pak.getSequenceNumber());
}

CBindTransceiverResp::~CBindTransceiverResp()
{
}

CQuerySMResp::CQuerySMResp()
{
	setCommandId(SMPP_QUERY_SM_RESP);
	m_message_id = "";
	m_error_code = 0;
	m_message_state = 0;
}

CQuerySMResp::CQuerySMResp(CQuerySM &pak)
{
	setCommandId(SMPP_QUERY_SM_RESP);
	m_message_id = "";
	m_error_code = 0;
	m_message_state = 0;

	setSequenceNumber(pak.getSequenceNumber());
}

CQuerySMResp::~CQuerySMResp()
{
}

CString CQuerySMResp::getMessageId()
{
	return m_message_id;
}

void CQuerySMResp::setMessageId(CString msgid)
{
	m_message_id = msgid;
}

CSmppDate CQuerySMResp::getFinalDate()
{
	return m_final_date;
}

void CQuerySMResp::setFinalDate(CSmppDate &fldate)
{
	m_final_date = fldate;
}

uint32 CQuerySMResp::getMessageState()
{
	return m_message_state;
}

void CQuerySMResp::setMessageState(uint32 msgst)
{
	m_message_state = msgst;
}

uint32 CQuerySMResp::getErrorCode()
{
	return m_error_code;
}

void CQuerySMResp::setErrorCode(uint32 errcode)
{
	m_error_code = errcode;
}

void CQuerySMResp::encodeBody(PBYTE &pby, int &nsz)
{
	CPacketBase::encodeBody(pby, nsz);

	BYTE by;

	m_buffer.Write(m_message_id);
	m_buffer.WriteNULL();

	m_buffer.Write(m_final_date.toString());
	m_buffer.WriteNULL();

	by = static_cast<byte>(m_message_state);
	m_buffer.Write(&by, 1);

	by = static_cast<byte>(m_error_code);
	m_buffer.Write(&by, 1);

	nsz = m_buffer.GetBufferLen();
	pby = new byte[nsz];

	ASSERT( getCommandLength() == static_cast<uint32>(nsz));

	memcpy(pby, m_buffer.GetBuffer(), nsz);
}

bool CQuerySMResp::loadPacket(PBYTE pby, int nsz)
{
	if (!CPacketBase::loadPacket(pby, nsz))
		return false;

	if (getCommandStatus() != 0)
		return false;

	int pos = 12;

	m_message_id = (LPTSTR) pby+pos;
	pos += m_message_id.GetLength() + 1;

	CString finaldt = (LPTSTR) pby+pos;
	pos += finaldt.GetLength() + 1;
	
	if (!finaldt.IsEmpty())
		m_final_date.setDate(finaldt);

	m_message_state = static_cast<uint32>(*(pby+pos));
	pos += 1;

	m_error_code = static_cast<uint32>(*(pby+pos));
	pos += 1;

	return true;
}

uint32 CQuerySMResp::getCommandLength()
{
	int len = (CPacketBase::getCommandLength()
		+ ((!m_message_id.IsEmpty()) ? m_message_id.GetLength() : 0)
		+ (m_final_date.getLength()) );

	return (len + 2 + 2);
}

CSubmitSMResp::CSubmitSMResp()
{
	setCommandId(SMPP_SUBMIT_SM_RESP);
}

CSubmitSMResp::CSubmitSMResp(CSubmitSM &pak)
{
	setCommandId(SMPP_SUBMIT_SM_RESP);
	setSequenceNumber(pak.getSequenceNumber());
}

CSubmitSMResp::~CSubmitSMResp()
{
}

CDeliverSMResp::CDeliverSMResp()
{
	setCommandId(SMPP_DELIVER_SM_RESP);
}

CDeliverSMResp::CDeliverSMResp(CDeliverSM &pak)
{
	setCommandId(SMPP_DELIVER_SM_RESP);
	setSequenceNumber(pak.getSequenceNumber());
}

CDeliverSMResp::~CDeliverSMResp()
{
}

CUnbindResp::CUnbindResp()
{
	setCommandId(SMPP_UNBIND_RESP);
}

CUnbindResp::CUnbindResp(CUnbind &pak)
{
	setCommandId(SMPP_UNBIND_RESP);
	setSequenceNumber(pak.getSequenceNumber());
}

CUnbindResp::~CUnbindResp()
{
}

void CUnbindResp::encodeBody(PBYTE &pby, int &nsz)
{
	CPacketBase::encodeBody(pby, nsz);

	nsz = m_buffer.GetBufferLen();
	pby = new byte[nsz];

	memcpy(pby, m_buffer.GetBuffer(), nsz);
}

CEnquireLink::CEnquireLink()
{
	setCommandId(SMPP_ENQUIRE_LINK);
}

CEnquireLink::~CEnquireLink()
{
}

void CEnquireLink::encodeBody(PBYTE &pby, int &nsz)
{
	CPacketBase::encodeBody(pby, nsz);

	nsz = m_buffer.GetBufferLen();
	pby = new byte[nsz];

	memcpy(pby, m_buffer.GetBuffer(), nsz);
}

CEnquireLinkResp::CEnquireLinkResp()
{
	setCommandId(SMPP_ENQUIRE_LINK_RESP);
}

CEnquireLinkResp::CEnquireLinkResp(CEnquireLink &pak)
{
	setCommandId(SMPP_ENQUIRE_LINK_RESP);
	setSequenceNumber(pak.getSequenceNumber());
}

CEnquireLinkResp::~CEnquireLinkResp()
{
}

void CEnquireLinkResp::encodeBody(PBYTE &pby, int &nsz)
{
	CPacketBase::encodeBody(pby, nsz);

	nsz = m_buffer.GetBufferLen();
	pby = new byte[nsz];

	memcpy(pby, m_buffer.GetBuffer(), nsz);
}

CGenericNack::CGenericNack()
{
	setCommandId(SMPP_GENERIC_NACK);
}

CGenericNack::~CGenericNack()
{
}

void CGenericNack::encodeBody(PBYTE &pby, int &nsz)
{
	CPacketBase::encodeBody(pby, nsz);

	nsz = m_buffer.GetBufferLen();
	pby = new byte[nsz];

	memcpy(pby, m_buffer.GetBuffer(), nsz);
}


CAlertNotification::CAlertNotification()
{
	setCommandId(SMPP_ALERT_NOTIFICATION);
}

CAlertNotification::~CAlertNotification()
{
}

CSmppAddress CAlertNotification::getSource()
{
	return m_source;
}

CSmppAddress CAlertNotification::getEsme()
{
	return m_esme;
}

void CAlertNotification::setSource(CSmppAddress &src)
{
	m_source = src;
}
void CAlertNotification::setEsme(CSmppAddress &esme)
{
	m_esme = esme;
}

void CAlertNotification::encodeBody(PBYTE &pby, int &nsz)
{
	CPacketBase::encodeBody(pby, nsz);

	BYTE by;

	by = static_cast<byte>(m_source.m_addr_ton);
	m_buffer.Write(&by, 1);

	by = static_cast<byte>(m_source.m_addr_npi);
	m_buffer.Write(&by, 1);

	m_buffer.Write(m_source.m_addr);
	m_buffer.WriteNULL();

	by = static_cast<byte>(m_esme.m_addr_ton);
	m_buffer.Write(&by, 1);

	by = static_cast<byte>(m_esme.m_addr_npi);
	m_buffer.Write(&by, 1);

	m_buffer.Write(m_esme.m_addr);
	m_buffer.WriteNULL();

	nsz = m_buffer.GetBufferLen();
	pby = new byte[nsz];

	ASSERT( getCommandLength() == static_cast<uint32>(nsz));

	memcpy(pby, m_buffer.GetBuffer(), nsz);
}

bool CAlertNotification::loadPacket(PBYTE pby, int nsz)
{
	if (!CPacketBase::loadPacket(pby, nsz))
		return false;

	if (getCommandStatus() != 0)
		return false;

	int pos = 12;

	m_source.setAddrTon(*(pby+pos));
	pos += 1;
	m_source.setAddrNpi(*(pby+pos));
	pos += 1;
	m_source.m_addr = (LPTSTR) pby+pos;
	pos += m_source.m_addr.GetLength() + 1;

	m_esme.setAddrTon(*(pby+pos));
	pos += 1;
	m_esme.setAddrNpi(*(pby+pos));
	pos += 1;
	m_esme.m_addr = (LPTSTR) pby+pos;
	pos += m_esme.m_addr.GetLength() + 1;

	return true;
}

uint32 CAlertNotification::getCommandLength()
{
	int len = (CPacketBase::getCommandLength()
		+ (m_source.getLength())
		+ (m_esme.getLength()) );

	return (len + 1);
}

