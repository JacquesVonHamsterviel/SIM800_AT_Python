#include "stdafx.h"
#include "common.h"
#include "packetbase.h"
#include "smpp.h"

#ifdef SMPPAPI_GOLD

//COptional Parameter

COptionalParameter::COptionalParameter()
{
	m_length = 0;
	m_value = NULL;
}

COptionalParameter::~COptionalParameter()
{
	if (m_value != NULL)
		delete m_value;
}

OPTIONAL_PARAMETER COptionalParameter::getParameterTag()
{
	return m_parameter_tag;
}

uint32 COptionalParameter::getLength()
{
	return m_length;
}

void COptionalParameter::getValue(PBYTE &val, uint32 &nsz)
{
	if (m_value != NULL)
	{
		val = new BYTE[m_length];

		memcpy(val, m_value, m_length);
		nsz = m_length;
	}
	else
	{
		val = NULL;
		nsz = 0;
	}
}


void COptionalParameter::setParameterTag(OPTIONAL_PARAMETER pt)
{
	m_parameter_tag = pt;
}

void COptionalParameter::setValue(PBYTE val, uint32 nsz)
{
	if (m_value != NULL)
		delete m_value;

	m_length = nsz;
	m_value = new BYTE[nsz];

	memcpy(m_value, val, nsz);
}

uint32 COptionalParameter::encodePacket(PBYTE &pby, int &nsz)
{
	int pos = 0;

	storeInt2(pby+pos, m_parameter_tag);
	pos += 2;

	storeInt2(pby+pos, m_length);
	pos += 2;

	memcpy(pby+pos, m_value, m_length);
	pos += m_length;

	return pos;
}

uint32 COptionalParameter::loadPacket(PBYTE pby, int nsz)
{
	int pos = 0;

	m_parameter_tag = static_cast<OPTIONAL_PARAMETER>(readInt2(pby+pos));
	pos += 2;
	
	m_length = readInt2(pby+pos);
	pos += 2;

	memcpy(m_value, pby+pos, m_length);
	pos += m_length;

	return pos;
}

//COptionalParameter

#endif


//CPacketBaseInitializer

uint32 CPacketBaseInitializer::m_seqnum_counter = 1;
CRITICAL_SECTION CPacketBaseInitializer::m_cs_seqnum;

CPacketBaseInitializer::CPacketBaseInitializer()
{
	InitializeCriticalSection(&m_cs_seqnum);
	TRACE("CS_seqnum initialized\n");
}

CPacketBaseInitializer::~CPacketBaseInitializer()
{
	DeleteCriticalSection(&m_cs_seqnum);
	TRACE("CS_seqnum deleted\n");
}

uint32 CPacketBaseInitializer::getNewSeqNum()
{
	uint32 ret;

	EnterCriticalSection(&m_cs_seqnum);
	ret = m_seqnum_counter++;
	LeaveCriticalSection(&m_cs_seqnum);

	return ret;
}

//global declaration
CPacketBaseInitializer packetbase_initializer;

//CPacketBase

CPacketBase::CPacketBase()
{
	m_command_id = 0;
	m_command_status = 0;
	m_sequence_number = getNewSeqNum();

	m_command_length = getHeaderLength();
}

CPacketBase::CPacketBase(uint32 seqnum)
{
	m_command_id = 0;
	m_command_status = 0;
	m_sequence_number = seqnum;

	m_command_length = getHeaderLength();
}

CPacketBase::~CPacketBase()
{
}

bool CPacketBase::loadPacket(PBYTE pby, int nsz)
{
	if (nsz < 16)
		return false;

	//commandlen has been stripped off

	uint32 cmdLen = nsz;

	m_command_id = readInt(pby);
	m_command_status = readInt(pby+4);
	m_sequence_number = readInt(pby+8);

	return true;
}

void CPacketBase::encodeBody(PBYTE &pby, int &nsz)
{
	int cmdLen = getCommandLength();

	BYTE by4[4];
	
	storeInt(by4, cmdLen);
	m_buffer.Write(by4, 4);

	storeInt(by4, m_command_id);
	m_buffer.Write(by4, 4);

	storeInt(by4, m_command_status);
	m_buffer.Write(by4, 4);

	storeInt(by4, m_sequence_number);
	m_buffer.Write(by4, 4);

}

uint32 CPacketBase::getCommandLength()
{
	return getHeaderLength();
}

uint32 CPacketBase::getHeaderLength()
{
	return 16;
}

//getter

uint32 CPacketBase::getCommandId()
{
	return m_command_id;
}

uint32 CPacketBase::getCommandStatus()
{
	return m_command_status;
}

uint32 CPacketBase::getSequenceNumber()
{
	return m_sequence_number;
}

//setter
void CPacketBase::setCommandId(uint32 cmid)
{
	m_command_id = cmid;
}

void CPacketBase::setCommandStatus(uint32 cmst)
{
	m_command_status = cmst;
}

void CPacketBase::setSequenceNumber(uint32 seqn)
{
	m_sequence_number = seqn;
}

uint32 CPacketBase::getNewSeqNum()
{
	return packetbase_initializer.getNewSeqNum();
}

//CPacketBase end


//CBindPacketBase

CBindPacketBase::CBindPacketBase()
{
	m_system_id = "";
	m_system_type = "";
	m_password = "";

	m_interface_version = SMPP_INTERFACE_VERSION;
}

CBindPacketBase::~CBindPacketBase()
{
}

CString CBindPacketBase::getSystemId()
{
	return m_system_id;
}

CString CBindPacketBase::getPassword()
{
	return m_password;
}

CString CBindPacketBase::getSystemType()
{
	return m_system_type;
}

CSmppAddress& CBindPacketBase::getSourceRange()
{
	return m_address_range;
}

void CBindPacketBase::setSystemId(CString sid)
{
	m_system_id = sid;
}

void CBindPacketBase::setSystemType(CString stype)
{
	m_system_type = stype;
}

void CBindPacketBase::setPassword(CString pwd)
{
	m_password = pwd;
}

void CBindPacketBase::setSourceRange(CSmppAddress &addr)
{
	m_address_range = addr;
}

void CBindPacketBase::setInterfaceVersion(uint32 iver)
{
	m_interface_version = iver;
}

void CBindPacketBase::encodeBody(PBYTE &pby, int &nsz)
{
	CPacketBase::encodeBody(pby, nsz);

	m_buffer.Write(m_system_id);
	m_buffer.WriteNULL();

	m_buffer.Write(m_password);
	m_buffer.WriteNULL();

	m_buffer.Write(m_system_type);
	m_buffer.WriteNULL();

	byte by = static_cast<byte>(m_interface_version);
	m_buffer.Write(&by, 1);

	by = static_cast<byte>(m_address_range.m_addr_ton);
	m_buffer.Write(&by, 1);

	by = static_cast<byte>(m_address_range.m_addr_npi);
	m_buffer.Write(&by, 1);

	m_buffer.Write(m_address_range.m_addr);
	m_buffer.WriteNULL();

	nsz = m_buffer.GetBufferLen();
	pby = new byte[nsz];

	ASSERT( getCommandLength() == static_cast<uint32>(nsz));

	memcpy(pby, m_buffer.GetBuffer(), nsz);
}

bool CBindPacketBase::loadPacket(PBYTE pby, int nsz)
{
	if (!CPacketBase::loadPacket(pby, nsz))
		return false;

	if (getCommandStatus() != 0)
		return false;

	int pos = 12;

	m_system_id = (LPTSTR) pby+pos;
	pos += m_system_id.GetLength() + 1;

	m_password = (LPTSTR) pby+pos;
	pos += m_password.GetLength() + 1;

	m_system_type = (LPTSTR) pby+pos;
	pos += m_system_type.GetLength() + 1;

	m_interface_version = static_cast<uint32>(*(pby+pos));
	pos += 1;

	//
	uint32 addrTon = static_cast<uint32>(*(pby+pos));
	pos += 1;

	uint32 addrNpi = static_cast<uint32>(*(pby+pos));
	pos += 1;

	CString addressRange = (LPTSTR) pby+pos;
	pos += addressRange.GetLength() + 1;
	//

	m_address_range.setAddrTon(addrTon);
	m_address_range.setAddrNpi(addrNpi);
	m_address_range.setAddr(addressRange);

	return true;
}

uint32 CBindPacketBase::getCommandLength()
{

#ifdef _DEBUG
	TCHAR buf[100];

	sprintf(buf, "sysid : %d, pwd : %d, sys_type : %d, addr_rng : %d\n",
		m_system_id.GetLength(),
		m_password.GetLength(),
		m_system_type.GetLength(),
		m_address_range.getLength());

	TRACE(buf);

#endif

	int len = (CPacketBase::getCommandLength()
		+ ((!m_system_id.IsEmpty()) ? m_system_id.GetLength() : 0)
		+ ((!m_password.IsEmpty()) ? m_password.GetLength() : 0)
		+ ((!m_system_type.IsEmpty()) ? m_system_type.GetLength() : 0)
		+ (m_address_range.getLength()));

	return (len + 1 + 3);
}

//CBindPacketBase end

//CMessagePacketBase

CMessagePacketBase::CMessagePacketBase()
{
	m_message = NULL;
	m_sm_length = 0;

	m_service_type = "";
	m_esm_class = 0;
	m_protocol_id = 0;
	m_priority_flag = 0;
	m_registered_delivery = 0;
	m_replace_if_present = 0;
	m_data_coding = 0;
	m_sm_default_msg_id = 0;
}

CMessagePacketBase::~CMessagePacketBase()
{
	if (m_message != NULL)
		delete m_message;
}

//getter

CString CMessagePacketBase::getServiceType()
{
	return m_service_type;
}

CSmppAddress CMessagePacketBase::getSource()
{
	return m_source;
}

CSmppAddress CMessagePacketBase::getDestination()
{
	return m_destination;
}

uint32 CMessagePacketBase::getEsmClass()
{
	return m_esm_class;
}

uint32 CMessagePacketBase::getProtocolId()
{
	return m_protocol_id;
}

uint32 CMessagePacketBase::getPriorityFlag()
{
	return m_priority_flag;
}

CSmppDate CMessagePacketBase::getScheduledDelivery()
{
	return m_scheduled_delivery;
}

CSmppDate CMessagePacketBase::getValidityPeriod()
{
	return m_validity_period;
}

uint32 CMessagePacketBase::getRegisteredDelivery()
{
	return m_registered_delivery;
}

uint32 CMessagePacketBase::getReplaceIfPresent()
{
	return m_replace_if_present;
}

uint32 CMessagePacketBase::getSmDefaultMsgId()
{
	return m_sm_default_msg_id;
}

uint32 CMessagePacketBase::getDataCoding()
{
	return m_data_coding;
}

uint32 CMessagePacketBase::getSmLength()
{
	return m_sm_length;
}

void CMessagePacketBase::getMessage(PBYTE &msg, uint32 &nsz)
{
	if (m_message != NULL)
	{
		msg = new BYTE[m_sm_length];

		memcpy(msg, m_message, m_sm_length);
		nsz = m_sm_length;
	}
	else
	{
		msg = NULL;
		nsz = 0;
	}
}

//setter
void CMessagePacketBase::setServiceType(CString stype)
{
	m_service_type = stype;
}

void CMessagePacketBase::setSource(CSmppAddress &src)
{
	m_source = src;
}

void CMessagePacketBase::setDestination(CSmppAddress &dest)
{
	m_destination = dest;
}

void CMessagePacketBase::setEsmClass(uint32 esm)
{
	m_esm_class = esm;
}

void CMessagePacketBase::setProtocolId(uint32 pid)
{
	m_protocol_id = pid;
}

void CMessagePacketBase::setPriorityFlag(uint32 pflag)
{
	m_priority_flag = pflag;
}

void CMessagePacketBase::setScheduledDelivery(CSmppDate &schdel)
{
	m_scheduled_delivery = schdel;
}

void CMessagePacketBase::setValidityPeriod(CSmppDate &valprd)
{
	m_validity_period = valprd;
}

void CMessagePacketBase::setRegisteredDelivery(uint32 reg)
{
	m_registered_delivery = reg;
}

void CMessagePacketBase::setReplaceIfPresent(uint32 rip)
{
	m_replace_if_present = rip;
}

void CMessagePacketBase::setDataCoding(uint32 enc)
{
	m_data_coding = enc;
}

void CMessagePacketBase::setSmDefaultMsgId(uint32 mdefid)
{
	m_sm_default_msg_id = mdefid;
}

void CMessagePacketBase::setSmLength(uint32 smlen)
{
	m_sm_length = smlen;
}

void CMessagePacketBase::setMessage(PBYTE msg, uint32 nsz)
{
	if (m_message != NULL)
		delete m_message;

	m_sm_length = nsz;
	m_message = new BYTE[nsz];

	memcpy(m_message, msg, nsz);
}

void CMessagePacketBase::encodeBody(PBYTE &pby, int &nsz)
{
	BYTE by;

	CPacketBase::encodeBody(pby, nsz);

	m_buffer.Write(m_service_type);
	m_buffer.WriteNULL();

	by = static_cast<byte>(m_source.m_addr_ton);
	m_buffer.Write(&by, 1);

	by = static_cast<byte>(m_source.m_addr_npi);
	m_buffer.Write(&by, 1);

	m_buffer.Write(m_source.m_addr);
	m_buffer.WriteNULL();

	by = static_cast<byte>(m_destination.m_addr_ton);
	m_buffer.Write(&by, 1);

	by = static_cast<byte>(m_destination.m_addr_npi);
	m_buffer.Write(&by, 1);

	m_buffer.Write(m_destination.m_addr);
	m_buffer.WriteNULL();

	by = static_cast<byte>(m_esm_class);
	m_buffer.Write(&by, 1);

	by = static_cast<byte>(m_protocol_id);
	m_buffer.Write(&by, 1);

	by = static_cast<byte>(m_priority_flag);
	m_buffer.Write(&by, 1);

	m_buffer.Write(m_scheduled_delivery.toString());
	m_buffer.WriteNULL();

	m_buffer.Write(m_validity_period.toString());
	m_buffer.WriteNULL();

	m_registered_delivery ? by = 1 : by = 0;
	m_buffer.Write(&by, 1);

	m_replace_if_present ? by = 1 : by = 0;
	m_buffer.Write(&by, 1);

	by = static_cast<byte>(m_data_coding);
	m_buffer.Write(&by, 1);

	by = static_cast<byte>(m_sm_default_msg_id);
	m_buffer.Write(&by, 1);

	by = static_cast<byte>(m_sm_length);
	m_buffer.Write(&by, 1);
	if (m_sm_length > 0)
	{
	    m_buffer.Write(m_message, m_sm_length);
	}

	nsz = m_buffer.GetBufferLen();
	pby = new byte[nsz];

	int test = getCommandLength();

	ASSERT( getCommandLength() == static_cast<uint32>(nsz));

	memcpy(pby, m_buffer.GetBuffer(), nsz);

}

bool CMessagePacketBase::loadPacket(PBYTE pby, int nsz)
{
	if (!CPacketBase::loadPacket(pby, nsz))
		return false;

	if (getCommandStatus() != 0)
		return false;

	int pos = 12;

	int smLength = 0;

	CString delivery, valid;

	// First the service type
	m_service_type =  (LPTSTR) pby+pos;
	pos += m_service_type.GetLength() + 1;

	m_source.setAddrTon(*(pby+pos));
	pos += 1;
	m_source.setAddrNpi(*(pby+pos));
	pos += 1;
	m_source.m_addr = (LPTSTR) pby+pos;
	pos += m_source.m_addr.GetLength() + 1;

	m_destination.setAddrTon(*(pby+pos));
	pos += 1;
	m_destination.setAddrNpi(*(pby+pos));
	pos += 1;
	m_destination.m_addr = (LPTSTR) pby+pos;
	pos += m_destination.m_addr.GetLength() + 1;

	// ESM class, protocol Id, priorityFlag...
	m_esm_class = static_cast<uint32>(*(pby+pos));
	pos += 1;

	m_protocol_id = static_cast<uint32>(*(pby+pos));
	pos += 1;

	m_priority_flag = static_cast<uint32>(*(pby+pos));
	pos += 1;

	delivery = (LPTSTR) pby+pos;
	pos += delivery.GetLength() + 1;

	valid = (LPTSTR) pby+pos;
	pos += valid.GetLength() + 1;
	
	if (!delivery.IsEmpty())
		m_scheduled_delivery.setDate(delivery);
	if (!valid.IsEmpty())
		m_validity_period.setDate(valid);

	// Registered delivery, replace if present, data coding, default msg
	// and message length
	m_registered_delivery = (*(pby+pos) == 0) ? false : true;
	pos += 1;

	m_replace_if_present = (*(pby+pos) == 0) ? false : true;
	pos += 1;

	m_data_coding = *(pby+pos);
	pos += 1;
	m_sm_default_msg_id = *(pby+pos);
	pos += 1;
	m_sm_length = *(pby+pos);
	pos += 1;

	if (m_sm_length > 0) {
	    m_message = new byte[m_sm_length];
		memcpy(m_message, pby+pos, m_sm_length);
		pos += m_sm_length;
	}
	
	return true;
}

uint32 CMessagePacketBase::getCommandLength()
{
	int len = (CPacketBase::getCommandLength()
		+ ((!m_service_type.IsEmpty()) ? m_service_type.GetLength() : 0)
		+ (m_source.getLength())
		+ (m_destination.getLength())
		+ (m_scheduled_delivery.getLength())
		+ (m_validity_period.getLength())
		+ (m_sm_length) );

	return (len + 8 + 3);
}

//CMessagePacketBase


//CDataPacketBase

CDataPacketBase::CDataPacketBase()
{
	m_service_type = "";
	m_esm_class = 0;
	m_registered_delivery = 0;
	m_data_coding = 0;
}

CDataPacketBase::~CDataPacketBase()
{
}

//getter

CString CDataPacketBase::getServiceType()
{
	return m_service_type;
}

CSmppAddress CDataPacketBase::getSource()
{
	return m_source;
}

CSmppAddress CDataPacketBase::getDestination()
{
	return m_destination;
}

uint32 CDataPacketBase::getEsmClass()
{
	return m_esm_class;
}

uint32 CDataPacketBase::getRegisteredDelivery()
{
	return m_registered_delivery;
}

uint32 CDataPacketBase::getDataCoding()
{
	return m_data_coding;
}

//setter
void CDataPacketBase::setServiceType(CString stype)
{
	m_service_type = stype;
}

void CDataPacketBase::setSource(CSmppAddress &src)
{
	m_source = src;
}

void CDataPacketBase::setDestination(CSmppAddress &dest)
{
	m_destination = dest;
}

void CDataPacketBase::setEsmClass(uint32 esm)
{
	m_esm_class = esm;
}

void CDataPacketBase::setRegisteredDelivery(uint32 reg)
{
	m_registered_delivery = reg;
}

void CDataPacketBase::setDataCoding(uint32 enc)
{
	m_data_coding = enc;
}

void CDataPacketBase::encodeBody(PBYTE &pby, int &nsz)
{
	BYTE by;

	CPacketBase::encodeBody(pby, nsz);

	m_buffer.Write(m_service_type);
	m_buffer.WriteNULL();

	by = static_cast<byte>(m_source.m_addr_ton);
	m_buffer.Write(&by, 1);

	by = static_cast<byte>(m_source.m_addr_npi);
	m_buffer.Write(&by, 1);

	m_buffer.Write(m_source.m_addr);
	m_buffer.WriteNULL();

	by = static_cast<byte>(m_destination.m_addr_ton);
	m_buffer.Write(&by, 1);

	by = static_cast<byte>(m_destination.m_addr_npi);
	m_buffer.Write(&by, 1);

	m_buffer.Write(m_destination.m_addr);
	m_buffer.WriteNULL();

	by = static_cast<byte>(m_esm_class);
	m_buffer.Write(&by, 1);

	m_registered_delivery ? by = 1 : by = 0;
	m_buffer.Write(&by, 1);

	by = static_cast<byte>(m_data_coding);
	m_buffer.Write(&by, 1);

	nsz = m_buffer.GetBufferLen();
	pby = new byte[nsz];

	ASSERT( getCommandLength() == static_cast<uint32>(nsz));

	memcpy(pby, m_buffer.GetBuffer(), nsz);

}

bool CDataPacketBase::loadPacket(PBYTE pby, int nsz)
{
	if (!CPacketBase::loadPacket(pby, nsz))
		return false;

	if (getCommandStatus() != 0)
		return false;

	int pos = 12;

	// First the service type
	m_service_type =  (LPTSTR) pby+pos;
	pos += m_service_type.GetLength() + 1;

	m_source.setAddrTon(*(pby+pos));
	pos += 1;
	m_source.setAddrNpi(*(pby+pos));
	pos += 1;
	m_source.m_addr = (LPTSTR) pby+pos;
	pos += m_source.m_addr.GetLength() + 1;

	m_destination.setAddrTon(*(pby+pos));
	pos += 1;
	m_destination.setAddrNpi(*(pby+pos));
	pos += 1;
	m_destination.m_addr = (LPTSTR) pby+pos;
	pos += m_destination.m_addr.GetLength() + 1;

	// ESM class, protocol Id, priorityFlag...
	m_esm_class = static_cast<uint32>(*(pby+pos));
	pos += 1;

	// Registered delivery, replace if present, data coding, default msg
	// and message length
	m_registered_delivery = (*(pby+pos) == 0) ? false : true;
	pos += 1;

	m_data_coding = *(pby+pos);
	pos += 1;
	
	return true;
}

uint32 CDataPacketBase::getCommandLength()
{
	int len = (CPacketBase::getCommandLength()
		+ ((!m_service_type.IsEmpty()) ? m_service_type.GetLength() : 0)
		+ (m_source.getLength())
		+ (m_destination.getLength()));

	return (len + 1 + 3);
}

//CDataPacketBase


CDataPacketRespBase::CDataPacketRespBase()
{
	m_message_id = "";
}

CDataPacketRespBase::~CDataPacketRespBase()
{
}

CString CDataPacketRespBase::getMessageId()
{
	return m_message_id;
}

	//setter
void CDataPacketRespBase::setMessageId(CString msgid)
{
	m_message_id = msgid;
}

void CDataPacketRespBase::encodeBody(PBYTE &pby, int &nsz)
{
	CPacketBase::encodeBody(pby, nsz);

	m_buffer.Write(m_message_id);
	m_buffer.WriteNULL();

	nsz = m_buffer.GetBufferLen();
	pby = new byte[nsz];

	ASSERT( getCommandLength() == static_cast<uint32>(nsz));

	memcpy(pby, m_buffer.GetBuffer(), nsz);
}

bool CDataPacketRespBase::loadPacket(PBYTE pby, int nsz)
{
	if (!CPacketBase::loadPacket(pby, nsz))
		return false;

	if (getCommandStatus() != 0)
		return false;

	int pos = 12;

	m_message_id = (LPTSTR) pby+pos;
	pos += m_message_id.GetLength() + 1;

	return true;
}

uint32 CDataPacketRespBase::getCommandLength()
{
	int len = (CPacketBase::getCommandLength()
			+ m_message_id.GetLength());

	return (len + 1);
}

//CDataPacketRespBase

//CBindRespBase

CBindRespBase::CBindRespBase()
{
	m_system_id = "";
}

CBindRespBase::~CBindRespBase()
{
}

void CBindRespBase::encodeBody(PBYTE &pby, int &nsz)
{
	CPacketBase::encodeBody(pby, nsz);

	m_buffer.Write(m_system_id);
	m_buffer.WriteNULL();

	nsz = m_buffer.GetBufferLen();
	pby = new byte[nsz];

	memcpy(pby, m_buffer.GetBuffer(), nsz);
}

bool CBindRespBase::loadPacket(PBYTE pby, int nsz)
{
	if (!CPacketBase::loadPacket(pby, nsz))
		return false;

	if (getCommandStatus() != 0)
		return false;

	int pos = 12;

	m_system_id = (LPTSTR) pby+pos;
	pos += m_system_id.GetLength() + 1;

	return true;
}

uint32 CBindRespBase::getCommandLength()
{
	int len = ( CPacketBase::getCommandLength()
				+ m_system_id.GetLength() );

	return (len + 1);
}

void CBindRespBase::setSystemId(CString sid)
{
	m_system_id = sid;
}

CString CBindRespBase::getSystemId()
{
	return m_system_id;
}

//CBindRespBase


//CMessageRespBase

CMessageRespBase::CMessageRespBase()
{
	m_message_id = "";
}

CMessageRespBase::~CMessageRespBase()
{
}

CString CMessageRespBase::getMessageId()
{
	return m_message_id;
}

void CMessageRespBase::setMessageId(CString msgid)
{
	m_message_id = msgid;
}

void CMessageRespBase::encodeBody(PBYTE &pby, int &nsz)
{
	CPacketBase::encodeBody(pby, nsz);

	m_buffer.Write(m_message_id);
	m_buffer.WriteNULL();

	nsz = m_buffer.GetBufferLen();
	pby = new byte[nsz];

	memcpy(pby, m_buffer.GetBuffer(), nsz);
}

bool CMessageRespBase::loadPacket(PBYTE pby, int nsz)
{
	if (!CPacketBase::loadPacket(pby, nsz))
		return false;

	if (getCommandStatus() != 0)
		return false;

	int pos = 12;

	m_message_id = (LPTSTR) pby+pos;
	pos += m_message_id.GetLength() + 1;

	return true;
}

uint32 CMessageRespBase::getCommandLength()
{
	int len = ( CPacketBase::getCommandLength()
				+ m_message_id.GetLength() );

	return (len + 1);
}
//