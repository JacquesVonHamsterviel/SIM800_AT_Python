#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//special command_id (defined ourself in SMSC Vendor range)

	#define SMPP_SPECIAL_LINKCLOSE					0x000101A5

//command_id

	#define SMPP_GENERIC_NACK						0x80000000

	#define SMPP_BIND_RECEIVER						0x00000001
	#define SMPP_BIND_RECEIVER_RESP	 				0x80000001

	#define SMPP_BIND_TRANSMITTER					0x00000002
	#define SMPP_BIND_TRANSMITTER_RESP				0x80000002

	#define SMPP_QUERY_SM							0x00000003
	#define SMPP_QUERY_SM_RESP						0x80000003

	#define SMPP_SUBMIT_SM							0x00000004
	#define SMPP_SUBMIT_SM_RESP						0x80000004

	#define SMPP_DELIVER_SM							0x00000005
	#define SMPP_DELIVER_SM_RESP					0x80000005

	#define SMPP_UNBIND								0x00000006
	#define SMPP_UNBIND_RESP						0x80000006

	#define SMPP_REPLACE_SM							0x00000007
    #define SMPP_REPLACE_SM_RESP					0x80000007

    #define SMPP_CANCEL_SM							0x00000008
    #define SMPP_CANCEL_SM_RESP						0x80000008

	#define SMPP_BIND_TRANSCEIVER					0x00000009
	#define SMPP_BIND_TRANSCEIVER_RESP				0x80000009

	#define SMPP_OUTBIND							0x0000000B

    #define SMPP_ENQUIRE_LINK						0x00000015
    #define SMPP_ENQUIRE_LINK_RESP					0x80000015

	#define SMPP_SUBMIT_MULTI						0x00000021
	#define SMPP_SUBMIT_MULTI_RESP					0x80000021

	#define SMPP_ALERT_NOTIFICATION					0x00000102

	#define SMPP_DATA_SM							0x00000103
	#define SMPP_DATA_SM_RESP						0x80000103


//data_coding

typedef enum
{
	CODING_DEFAULT				= 0x00,	// Default Alphabet
	CODING_ANSI_X3_4			= 0x01,	// IA5 (CCITT T.50)/ASCII (ANSI X3.4)
	CODING_OCTET1				= 0x02,	// Octet unspecified (8-bit binary)
	CODING_ISO8859_1			= 0x03,	// Latin 1 (ISO-8859-1)
	CODING_OCTET2				= 0x04,	// Octet unspecified (8-bit binary)
	CODING_JIS					= 0x05, //JIS (X 0208-1990)
	CODING_CYRLLIC				= 0x06,	//Cyrllic (ISO-8859-5)
	CODING_LATIN				= 0x07, //Latin/Hebrew (ISO-8859-8)
	CODING_UCS2					= 0x08, //UCS2 (ISO/IEC-10646)
	CODING_PICTOGRAM			= 0x09, //Pictogram Encoding
	CODING_ISO_2200_JP			= 0x0A	//ISO-2200-JP

} DATA_CODING;


//command_status

typedef enum
{
	ESME_ROK					= 0x00000000,	// No error
	ESME_RINVMSGLEN				= 0x00000001,	// Message length is invalid
	ESME_RINVCMDLEN				= 0x00000002,	// Command length is invalid
	ESME_RINVCMDID				= 0x00000003,	// Invalid command id
	ESME_RINVBNDSTS				= 0x00000004,	// Incorrect BIND status for given command
	ESME_RALYBND				= 0x00000005,	// ESME already in bound state
	ESME_RINVPRTFLG				= 0x00000006,	// Invalid priority flag
	ESME_RINVREGDLVFLG			= 0x00000007,	// Invalid registered delivery flag
	ESME_RSYSERR				= 0x00000008,	// System error
	ESME_RINVSRCADR				= 0x0000000A,	// Invalid source address
	ESME_RINVDSTADR				= 0x0000000B,	// Invalid destination address
	ESME_RINVMSGID				= 0x0000000C,	// Invalid message id
	ESME_RBINDFAIL				= 0x0000000D,	// Bind failed
	ESME_RINVPASWD				= 0x0000000E,	// Invalid password
	ESME_RINVSYSID				= 0x0000000F,	// Invalid system id
	ESME_RCANCELFAIL			= 0x00000011,	// Cancel SM failed
	ESME_RREPLACEFAIL			= 0x00000013,	// Replace SM failed
	ESME_RMSGQFUL				= 0x00000014,	// Message queue full
	ESME_RINVSERTYP				= 0x00000015,	// Invalid service type
	ESME_RINVNUMDESTS			= 0x00000033,	// Invalid number of destinations
	ESME_RINVDLNAME				= 0x00000034,	// Invalid distribution list name
	ESME_RINVDESTFLAG			= 0x00000040,	// Destination flag is invalid
	ESME_RINVSUBREP				= 0x00000042,	// Invalid 'submit_with_replace' request
	ESME_RINVESMCLASS			= 0x00000043,	// Invalid 'esm_class' field data
	ESME_RCNTSUBDL				= 0x00000044,	// Cannot submit to distribution list
	ESME_RSUBMITFAIL			= 0x00000045,	// 'submit_sm' or 'submit_multi' failed
	ESME_RINVSRCTON				= 0x00000048,	// Invalid source address TON
	ESME_RINVSRCNPI				= 0x00000049,	// Invalid source address NPI
	ESME_RINVDSTTON				= 0x00000050,	// Invalid destination address TON
	ESME_RINVDSTNPI				= 0x00000051,	// Invalid destination address NPI
	ESME_RINVSYSTYP				= 0x00000053,	// Invalid 'system_type' field
	ESME_RINVREPFLAG			= 0x00000054,	// Invalid 'replace_if_present' flag
	ESME_RINVNUMMSGS			= 0x00000055,	// Invalid number of messages
	ESME_RTHROTTLED				= 0x00000058,	// Throttling error
	ESME_RINVSCHED				= 0x00000061,	// Invalid Scheduled Delivery Time
	ESME_RINVEXPIRY				= 0x00000062,	// Invalid Message Validity Period (Expiry time)
	ESME_RINVDFTMSGID			= 0x00000063,	// Predefined Message Invalid or Not Found
	ESME_RX_T_APPN				= 0x00000064,	// ESME Receiver Temporary App Error Code
	ESME_RX_P_APPN				= 0x00000065,	// ESME Receiver Permanent App Error Code
	ESME_RX_R_APPN				= 0x00000066,	// ESME Receiver Reject Message Error Code
	ESME_RQUERYFAIL				= 0x00000067,	// 'query_sm' request failed
	ESME_RINVOPTPARSTREAM		= 0x000000C0,	// Error in the optional part of the PDU Body
	ESME_RINVPARLEN				= 0x000000C2,	// Invalid Parameter Length
	ESME_RMISSINGOPTPARAM		= 0x000000C3,	// Expected Optional Parameter missing
	ESME_ROPTPARNOTALLWD		= 0x000000C4,	// Invalid Optional Parameter Value
	ESME_RDELIVERYFAILURE		= 0x000000FE,	// Delivery Failure (used for 'data_sm_resp')
	ESME_RUNKNOWNERR			= 0x000000FF,	// Unknown Error

	ESME_RTRANSPORTERR			= 0x00000400,	// Transport Error
	ESME_RGATEWAYFAILURE		= 0x00000401,	// Gateway Failure (Unable to reach internal gateway)
	ESME_RPERMANENTFAILURE		= 0x00000402,	// Permanent Network Failure (To external gateway)
	ESME_RTEMPORARYFAILURE		= 0x00000403,	// Temporary Network Failure (To external gateway)
	ESME_RINVSUBSCRIBER			= 0x00000404,	// Invalid Subscriber
	ESME_RINVMSG				= 0x00000405,	// Invalid Message
	ESME_RPROTOCOLERR			= 0x00000406,	// Gateway Protocol Error
	ESME_RDUPLICATEDMSG			= 0x00000407,	// Duplicated Messages
	ESME_RBARREDBYUSER			= 0x00000408,	// Barred by User
	ESME_RCANCELLEDBYSYS		= 0x00000409,	// Cancelled by System
	ESME_REXPIRED				= 0x0000040A	// Message Expired

} CMD_STATUS_CODE;

typedef enum
{
	dest_addr_submit				= 0x0005,
	dest_network_type				= 0x0006,
	dest_bearer_type				= 0x0007,
	dest_telematics_id				= 0x0008,

	source_addr_submit				= 0x000D,
	source_network_type				= 0x000E,
	source_bearer_type				= 0x000F,
	source_telematics_id			= 0x0010,

	qos_time_to_live				= 0x0017,
	payload_type					= 0x0019,
	additional_status_info_text		= 0x001D,
	receipted_message_id			= 0x001E,
	ms_msg_wait_facilities			= 0x0030,
	privacy_indicator				= 0x0201,

	source_subaddress				= 0x0202,
	dest_subaddress					= 0x0203,

	user_message_reference			= 0x0204,
	user_response_code				= 0x0205,

	source_port						= 0x020A,
	destination_port				= 0x020B,

	sar_msg_ref_num					= 0x020C,
	language_indicator				= 0x020D,
	sar_total_segments				= 0x020E,
	sar_segment_seqnum				= 0x020F,

	SC_interface_version			= 0x0210,

	callback_num_pres_ind			= 0x0302,
	callback_num_atag				= 0x0303,
	number_of_messages				= 0x0304,
	callback_num					= 0x0381,

	dpf_result						= 0x0420,
	set_dpf							= 0x0421,
	ms_availability_status			= 0x0422,
	network_error_code				= 0x0423,
	message_payload					= 0x0424,

	ussd_service_op					= 0x0501,
	display_time					= 0x1201,
	sms_signal						= 0x1203,
	ms_validity						= 0x1204,

	alert_on_message_delivery		= 0x130C,
	its_reply_type					= 0x1380,
	its_session_info				= 0x1383

} OPTIONAL_PARAMETER;