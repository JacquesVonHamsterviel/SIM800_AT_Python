
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "stdafx.h"
#include "common.h"

//CSmppDate

class SMPPLIB_DECLSPEC CSmppDate
{
public:
	CSmppDate();
	virtual ~CSmppDate();

	void setDate(CString sd);
	void setDate(SYSTEMTIME sdt);

	CString toString();

	CSmppDate& operator=(CSmppDate &dt);

	int getLength();

	void setNull();

	bool isNull();

public:
	SYSTEMTIME m_time;

protected:
	bool m_null;
};

//CSmppDate end

//CSmppAddress

class SMPPLIB_DECLSPEC CSmppAddress  
{
public:
	CSmppAddress();
	CSmppAddress(uint32 adrton, uint32 adrnpi, CString addr);

	virtual ~CSmppAddress();

	CSmppAddress& operator=(CSmppAddress& addr);

	int getLength();

	void setAddrNpi(uint32 adrnpi);
	void setAddrTon(uint32 adrton);
	void setAddr(CString addr);

public:
	uint32 m_addr_ton;
	uint32 m_addr_npi;

	CString m_addr;
};

//CSmppAddress end