// SmppTransmitter.h: interface for the CSmppTransmitter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SMPPTRANSMITTER_H__37E518D9_ECB4_4F13_BBEF_967EEF27A957__INCLUDED_)
#define AFX_SMPPTRANSMITTER_H__37E518D9_ECB4_4F13_BBEF_967EEF27A957__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "SmppConnection.h"
#include "smpppacket.h"

class SMPPLIB_DECLSPEC CEsmeTransmitter : public CSmppConnection
{
public:
	CEsmeTransmitter();
	virtual ~CEsmeTransmitter();

	int bind(CString sysid, CString passwd, CString systype, CSmppAddress &srcrange);

	int submitMessage(CSubmitSM &pak);
	int submitMessage(CString msg, CString dst, uint32 ton, uint32 npi);
	int submitMessage(CString msg, CSmppAddress &dst);
	int submitMessage(PBYTE msg, uint32 msglen, uint32 enc, CSmppAddress &dst, uint32 esm = 0);

protected:
	void parse_packet(PBYTE pby, int nsz);

	#ifdef SMPPAPI_EVALUATION
		static uint32 m_eval_counter;
	#endif


};

#endif // !defined(AFX_SMPPTRANSMITTER_H__37E518D9_ECB4_4F13_BBEF_967EEF27A957__INCLUDED_)
