Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Button1 As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(168, 176)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(96, 24)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Run Testing"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(448, 262)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Button1})
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Dim WithEvents transceiver As SMPPCOMLib.EsmeTransceiverCom
    Dim WithEvents receiver As SMPPCOMLib.EsmeReceiverCom

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Dim ret As Boolean

        Dim srcRange As SMPPCOMLib.SmppAddressCom
        srcRange = New SMPPCOMLib.SmppAddressCom()

        Dim smsRecipent As SMPPCOMLib.SmppAddressCom
        smsRecipent = New SMPPCOMLib.SmppAddressCom()

        'bind to the SMSC
        Dim compTrans As SMPPCOMLib.EsmeTransmitterCom
        compTrans = New SMPPCOMLib.EsmeTransmitterCom()

        'set SMSC IP & port

        compTrans.init("127.0.0.1", 8152)

        srcRange.Address = "+85294224245"
        srcRange.NPI = 2
        srcRange.TON = 1

        'make connection to SMSC and login

        ret = compTrans.bind("myuid", "mypass", "SYSTYPE", srcRange)

        'send message to a recipent through the SMSC

        Dim compSSM As SMPPCOMLib.SubmitSMCom
        compSSM = New SMPPCOMLib.SubmitSMCom()

        smsRecipent.Address = "+85293847653"
        smsRecipent.NPI = 1
        smsRecipent.TON = 1

        compSSM.Source = srcRange
        compSSM.Destination = smsRecipent

        Dim schdt As SMPPCOMLib.SmppDateCom
        schdt = New SMPPCOMLib.SmppDateCom()

        'date should be set in YYMMDDhhmmsstTZ+ format
        'as specified in SMPP specification
        schdt.setDate("020919192349200+")

        compSSM.scheduledDelivery = schdt


        ' message can be set using an byte array and setMessage
        ' It is useful to set binary message, but remember
        ' to set the data coding appropriately,by default it's 0.

        '   Dim ba(2) As Byte

        '   ba(0) = 5
        '   ba(1) = 7
        '   ba(2) = 19

        '   compSSM.setMessage(ba)

        ' using getMessage to access the binary message directly

        '   Dim batest() As Byte
        '   batest = compSSM.getMessage()


        compSSM.Message = "ABCDEFGHIJKLMNO"

        'since automation client is using double-byes
        'we compact the message to single byte
        'it can only be done if and only if your message is ascii
        'for UNICODE message, SHOULD NOT compact
        compSSM.compactMessage()

        'flip the byte order to remedy byte order problem for double
        'byte language, and byte order representation for different system
        'compSSM.flipByteOrder()

        Dim msg_id As String
        ret = compTrans.submitMessage(compSSM, msg_id)

        'try enquire link here for demonstration
        ret = compTrans.enquireLink()

        'finished, so close
        ret = compTrans.unbind()

        compTrans.close()

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim myaddr As SMPPCOMLib.SmppAddressCom
        myaddr = New SMPPCOMLib.SmppAddressCom()
        myaddr.TON = 2
        myaddr.NPI = 3
        myaddr.Address = "+47295360366"

        transceiver = New SMPPCOMLib.EsmeTransceiverCom()
        transceiver.init("127.0.0.1", 8152)
        transceiver.bind("MYUIN", "MYPASS", "STYPE", myaddr)
        transceiver.enquireLink()

        receiver = New SMPPCOMLib.EsmeReceiverCom()
        receiver.init("127.0.0.1", 8152)
        receiver.bind("MYUIN", "MYPASS", "STYPE", myaddr)
        receiver.enquireLink()

    End Sub

    Private Sub transceiver_OnDeliverSM(ByVal dsm As SMPPCOMLib.DeliverSMCom) Handles transceiver.OnDeliverSM

        Dim dc As Integer
        Dim src As SMPPCOMLib.SmppAddressCom
        Dim dest As SMPPCOMLib.SmppAddressCom
        Dim msg As String

        MsgBox("Transceiver received DeliverSM event")

        dc = dsm.dataCoding()
        src = dsm.Source
        dest = dsm.Destination
        msg = dsm.Message

    End Sub

    Private Sub receiver_OnDeliverSM(ByVal dsm As SMPPCOMLib.DeliverSMCom) Handles receiver.OnDeliverSM
        Dim dc As Integer
        Dim src As SMPPCOMLib.SmppAddressCom
        Dim dest As SMPPCOMLib.SmppAddressCom
        Dim msg As String

        MsgBox("Receiver receivered DeliverSM event")

        dc = dsm.dataCoding()
        src = dsm.Source
        dest = dsm.Destination
        msg = dsm.Message
    End Sub

End Class
