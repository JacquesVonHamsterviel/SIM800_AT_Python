// SmppLibCliTest.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "SmppLibCliTest.h"

#include "winsock2.h"

#include "..\common.h"
#include "..\EsmeTransceiver.h"
#include "..\SmppUtil.h"
#include "..\smpppacket.h"
#include "..\smpp.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// The one and only application object

CWinApp theApp;

using namespace std;


class CSmppLibTest
{

protected:
	CEsmeTransceiver	trans;

public:

	//starting point of the testing
	void initialize(CString svrip, int svrport)
	{
		//set the ip, port of the server
		trans.init(svrip, svrport);

		//setup call back procedure for the transceiver
		trans.registerProcessPacket(processPacketProc, this);

		//my address (ton, npi, addr) to connect to SMSC
		CSmppAddress src_range(0, 0, "85292355321");

		//connects and sends bind transceiver to the server
		trans.bind("TESTACC", "kt43ls", "TEST", src_range);

		//okay, when we receive packets, it will be handled in
		//the callback function.
	}


	//registered callback to handle SMPP packets sent from SMSC
	//(must be static class method or global procedure)
	static void __stdcall processPacketProc(CPacketBase *pak, LPVOID param)
	{
		CSmppLibTest *pTest = (CSmppLibTest *) param;

		//route to instance method, so it can access instance attributes
		pTest->processPacket(pak);
	}


	//actuallly SMPP packets are in turns handled here 
	void processPacket(CPacketBase *pak)
	{

		switch (pak->getCommandId())
		{
			//Bind Trnasmitter Response
			case SMPP_BIND_TRANSMITTER_RESP:
			{
				CBindTransmitterResp *pPak;
				pPak = static_cast<CBindTransmitterResp *>(pak);

				TRACE("Packet is casted to CBindTransmitterResp\n");
				TRACE1("%s\n", pPak->getSystemId());

				TRACE("Sending a SMS out\n");
				trans.submitMessage("Hiya, this is my message", "85261210229", 2, 0);
			}
			break;

			//Bind Receiver Response
			case SMPP_BIND_RECEIVER_RESP:
			{
				CBindReceiverResp *pPak;
				pPak = static_cast<CBindReceiverResp *>(pak);

				TRACE("Packet is casted to CBindReceiverResp\n");
				TRACE1("%s\n", pPak->getSystemId());

				TRACE("Sending a SMS out\n");
				trans.submitMessage("Hiya, this is my message", "85261210229", 2, 0);
			}
			break;

			//Bind Transceiver Response
			case SMPP_BIND_TRANSCEIVER_RESP:
			{
				CBindTransceiverResp *pPak;
				pPak = static_cast<CBindTransceiverResp *>(pak);

				TRACE("Packet is casted to CBindTransceiverResp\n");
				TRACE1("%s\n", pPak->getSystemId());

				CSmppAddress dst(2,3, "942532535");

				TRACE("Sending a SMS out\n");
				trans.submitMessage("Hiya, good", dst);

			}
			break;

			//Deliver Short Message
			case SMPP_DELIVER_SM:
			{
				CDeliverSM *pPak;
				pPak = static_cast<CDeliverSM *>(pak);

				TRACE("Packet is casted to CDeliverSM\n\n");

			}
			break;

			//Submit Short Message Response
			case SMPP_SUBMIT_SM_RESP:
			{
				CSubmitSMResp *pPak;
				pPak = static_cast<CSubmitSMResp *>(pak);

				TRACE("Packet is casted to CSubmitSMResp\n");
				TRACE1("%s\n", pPak->getMessageId());

				trans.enquireLink();
			}
			break;

			//Unbind Response
			case SMPP_UNBIND_RESP:
			{
				CUnbindResp *pPak;
				pPak = static_cast<CUnbindResp *>(pak);

				TRACE("Packet is casted to CUnbindResp\n\n");

			}
			break;


			case SMPP_ENQUIRE_LINK:
			{
				CEnquireLink *pPak;
				pPak = static_cast<CEnquireLink *>(pak);

				TRACE("Packet is casted to CEnquireLink\n\n");

			}
			break;


			case SMPP_ENQUIRE_LINK_RESP:
			{
				CEnquireLinkResp *pPak;
				pPak = static_cast<CEnquireLinkResp *>(pak);

				TRACE("Packet is casted to CEnquireLinkResp\n\n");

				CQuerySM qsm;
				qsm.setMessageId("AACCDD1233");
				trans.sendPacket(qsm);

			}
			break;

			case SMPP_QUERY_SM:
			{
				CQuerySM *pPak;
				pPak = static_cast<CQuerySM *>(pak);

				TRACE("Packet is casted to CQuerySM\n\n");
			}
			break;

			case SMPP_QUERY_SM_RESP:
			{
				CQuerySMResp *pPak;
				pPak = static_cast<CQuerySMResp *>(pak);

				TRACE("Packet is casted to CQuerySMResp\n\n");

				TRACE1("MessageId: %s\n", pPak->getMessageId());
				TRACE1("ErrorCode: %d\n", pPak->getErrorCode());

				TRACE("Going to unbind\n");
				trans.unbind();

			}
			break;

			case SMPP_SPECIAL_LINKCLOSE:
			{
				TRACE("Link close is detected\n");
			}
			break;

			default:
			{
				TRACE("Unhandled packet received\n");
			}
			break;

		}		//switch case end

	}		//processPacket end

};	//class CSmppLibTest end

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;

	// initialize winsock2
	WSADATA wsaData;
	WSAStartup(MAKEWORD(2,2), &wsaData);

	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		// TODO: change error code to suit your needs
		cerr << _T("Fatal Error: MFC initialization failed") << endl;
		nRetCode = 1;
	}
	else
	{
		// TODO: code your application's behavior here.

		CSmppLibTest	smpplib_test;
		smpplib_test.initialize("127.0.0.1", 8152);

		//block the main thread
		while (getchar() != '\n')
		{
			Sleep(100);
		}

	}

	WSACleanup();

	return nRetCode;
}


