// SmppTransmitter.cpp: implementation of the CSmppTransmitter class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
//#include "SMPPAPI.h"
#include "EsmeTransmitter.h"
#include "smpppacket.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

#ifdef SMPPAPI_EVALUATION
	uint32 CEsmeTransmitter::m_eval_counter = 1;
#endif

CEsmeTransmitter::CEsmeTransmitter()
{
}

CEsmeTransmitter::~CEsmeTransmitter()
{

}

int CEsmeTransmitter::bind(CString sysid, CString passwd, CString systype, CSmppAddress &addrrange)
{
	bool ret = 1;

	m_system_id = sysid;
	m_password = passwd;
	m_system_type = systype;

	m_address_range = addrrange;

	if (open())
	{
		CBindTransmitter	pak;

		pak.setSystemId(sysid);
		pak.setPassword(passwd);
		pak.setSystemType(systype);

		pak.setSourceRange(addrrange);

		if(sendPacket(pak))
			ret = 0;
	}

	return ret;
}

int CEsmeTransmitter::submitMessage(CSubmitSM &pak)
{
	#ifdef SMPPAPI_EVALUATION
		m_eval_counter++;
		if (m_eval_counter > 200)
			return 1;
	#endif

	sendPacket(pak);

	return 0;
}

int CEsmeTransmitter::submitMessage(CString msg, CString dst, uint32 ton, uint32 npi)
{
	CSmppAddress dst_addr(ton, npi, dst);

	return submitMessage(msg, dst_addr);
}

int CEsmeTransmitter::submitMessage(CString msg, CSmppAddress &dst)
{
	CSubmitSM s;

	s.setMessage( (PBYTE) msg.GetBuffer(0), msg.GetLength());
	msg.ReleaseBuffer();

	s.setDestination(dst);
	s.setSource(m_address_range);

	return submitMessage(s);

}

int CEsmeTransmitter::submitMessage(PBYTE msg, uint32 msglen, uint32 enc, CSmppAddress &dst, uint32 esm)
{
		CSubmitSM s;

		s.setMessage(msg, msglen);
		s.setDestination(dst);
		s.setSource(m_address_range);
		s.setDataCoding(enc);
		s.setEsmClass(esm);

		return submitMessage(s);

}

void CEsmeTransmitter::parse_packet(PBYTE pby, int nsz)
{

	if (nsz < 16)
		return;

	uint32 cmdId = readInt(pby);

	TRACE1("CommandId is %x", cmdId);

	int cmdStatus = readInt(pby+4);
	int seqNum = readInt(pby+8);

	switch (cmdId)
	{
		case SMPP_GENERIC_NACK:
		{
			CGenericNack* ppak;
			ppak = new CGenericNack();
			ppak->loadPacket(pby, nsz);

			//call back
			if (m_pProcessPacket != NULL)
			{
				m_pProcessPacket(ppak, m_Param);
			}

			delete ppak;
		}
			break;

		case SMPP_SPECIAL_LINKCLOSE:
		{
			CLinkClose* ppak;
			ppak = new CLinkClose();
			ppak->loadPacket(pby, nsz);

			//call back
			if (m_pProcessPacket != NULL)
			{
				m_pProcessPacket(ppak, m_Param);
			}

			delete ppak;
		}
			break;

		case SMPP_BIND_TRANSMITTER_RESP:
		{
			CBindTransmitterResp* ppak;
			ppak = new CBindTransmitterResp();
			ppak->loadPacket(pby, nsz);

			//call back
			if (m_pProcessPacket != NULL)
			{
				m_pProcessPacket(ppak, m_Param);
			}

			delete ppak;
		}
			break;

		case SMPP_SUBMIT_SM_RESP:
		{
			CSubmitSMResp* ppak;
			ppak = new CSubmitSMResp();
			ppak->loadPacket(pby, nsz);

			//call back
			if (m_pProcessPacket != NULL)
			{
				m_pProcessPacket(ppak, m_Param);
			}

			delete ppak;
		}
			break;

		case SMPP_QUERY_SM_RESP:
		{
			CQuerySMResp* ppak;
			ppak = new CQuerySMResp();
			ppak->loadPacket(pby, nsz);

			//call back
			if (m_pProcessPacket != NULL)
			{
				m_pProcessPacket(ppak, m_Param);
			}

			delete ppak;
		}
			break;

		case SMPP_ENQUIRE_LINK:
		{
			CEnquireLink* ppak;
			ppak = new CEnquireLink();
			ppak->loadPacket(pby, nsz);

			//call back
			if (m_pProcessPacket != NULL)
			{
				m_pProcessPacket(ppak, m_Param);
			}

			delete ppak;
		}
			break;

		case SMPP_ENQUIRE_LINK_RESP:
		{
			CEnquireLinkResp* ppak;
			ppak = new CEnquireLinkResp();
			ppak->loadPacket(pby, nsz);

			//call back
			if (m_pProcessPacket != NULL)
			{
				m_pProcessPacket(ppak, m_Param);
			}

			delete ppak;
		}
			break;

		case SMPP_UNBIND_RESP:
		{
			CUnbindResp* ppak;
			ppak = new CUnbindResp();
			ppak->loadPacket(pby, nsz);

			//call back
			if (m_pProcessPacket != NULL)
			{
				m_pProcessPacket(ppak, m_Param);
			}

			delete ppak;
		}
			break;

		default:
			break;
	}
}
