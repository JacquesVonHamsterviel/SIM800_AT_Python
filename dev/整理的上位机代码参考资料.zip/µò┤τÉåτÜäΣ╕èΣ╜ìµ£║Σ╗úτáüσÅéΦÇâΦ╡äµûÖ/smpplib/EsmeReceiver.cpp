// EsmeReceiver.cpp: implementation of the CEsmeReceiver class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
//#include "SMPPAPI.h"
#include "EsmeReceiver.h"
#include "smpppacket.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

#ifdef SMPPAPI_EVALUATION
	uint32 CEsmeReceiver::m_eval_counter = 1;
#endif

CEsmeReceiver::CEsmeReceiver()
{
}

CEsmeReceiver::~CEsmeReceiver()
{

}

int CEsmeReceiver::bind(CString sysid, CString passwd, CString systype, CSmppAddress &addrrange)
{
	bool ret = 1;

	m_system_id = sysid;
	m_password = passwd;
	m_system_type = systype;

	m_address_range = addrrange;

	if (open())
	{
		CBindReceiver	pak;

		pak.setSystemId(sysid);
		pak.setPassword(passwd);
		pak.setSystemType(systype);

		pak.setSourceRange(addrrange);

		if (sendPacket(pak))
			ret = 0;
	}

	return ret;
}

void CEsmeReceiver::parse_packet(PBYTE pby, int nsz)
{
	#ifdef SMPPAPI_EVALUATION
		m_eval_counter++;
		if (m_eval_counter > 200)
			return;
	#endif

	if (nsz < 16)
		return;

	uint32 cmdId = readInt(pby);

	TRACE1("CommandId is %x", cmdId);

	int cmdStatus = readInt(pby+4);
	int seqNum = readInt(pby+8);

	switch (cmdId)
	{
		case SMPP_GENERIC_NACK:
		{
			CGenericNack* ppak;
			ppak = new CGenericNack();
			ppak->loadPacket(pby, nsz);

			//call back
			if (m_pProcessPacket != NULL)
			{
				m_pProcessPacket(ppak, m_Param);
			}

			delete ppak;
		}
			break;

		case SMPP_SPECIAL_LINKCLOSE:
		{
			CLinkClose* ppak;
			ppak = new CLinkClose();
			ppak->loadPacket(pby, nsz);

			//call back
			if (m_pProcessPacket != NULL)
			{
				m_pProcessPacket(ppak, m_Param);
			}

			delete ppak;
		}
			break;

		case SMPP_BIND_RECEIVER_RESP:
		{
			CBindReceiverResp* ppak;
			ppak = new CBindReceiverResp();
			ppak->loadPacket(pby, nsz);

			//call back
			if (m_pProcessPacket != NULL)
			{
				m_pProcessPacket(ppak, m_Param);
			}

			delete ppak;
		}
			break;

		case SMPP_ENQUIRE_LINK:
		{
			CEnquireLink* ppak;
			ppak = new CEnquireLink();
			ppak->loadPacket(pby, nsz);

			//call back
			if (m_pProcessPacket != NULL)
			{
				m_pProcessPacket(ppak, m_Param);
			}

			delete ppak;
		}
			break;

		case SMPP_ENQUIRE_LINK_RESP:
		{
			CEnquireLinkResp* ppak;
			ppak = new CEnquireLinkResp();
			ppak->loadPacket(pby, nsz);

			//call back
			if (m_pProcessPacket != NULL)
			{
				m_pProcessPacket(ppak, m_Param);
			}

			delete ppak;
		}
			break;

		case SMPP_UNBIND_RESP:
		{
			CUnbindResp* ppak;
			ppak = new CUnbindResp();
			ppak->loadPacket(pby, nsz);

			//call back
			if (m_pProcessPacket != NULL)
			{
				m_pProcessPacket(ppak, m_Param);
			}

			delete ppak;
		}
			break;

		case SMPP_DELIVER_SM:
		{
			CDeliverSM*	ppak;
			ppak = new CDeliverSM();
			ppak->loadPacket(pby, nsz);

			//call back
			if (m_pProcessPacket != NULL)
			{
				m_pProcessPacket(ppak, m_Param);
			}

			delete ppak;
		}
			break;

		default:
			break;
	}
}
