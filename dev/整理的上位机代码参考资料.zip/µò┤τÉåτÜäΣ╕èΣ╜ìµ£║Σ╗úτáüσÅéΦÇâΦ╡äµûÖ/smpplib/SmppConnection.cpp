// SmppConnection.cpp: implementation of the CSmppConnection class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
//#include "SMPPAPI.h"
#include "SmppConnection.h"
#include "smpppacket.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSmppConnection::CSmppConnection()
{
	m_system_id = "";
	m_password = "";
	m_system_type = "";
}

CSmppConnection::~CSmppConnection()
{

}

int CSmppConnection::bind(CString sysid, CString passwd, CString systype, CString addrrange)
{
	CSmppAddress adrrng;

	adrrng.setAddrTon(0);
	adrrng.setAddrNpi(0);
	adrrng.setAddr(addrrange);

	return bind(sysid, passwd, systype, adrrng);
}

int CSmppConnection::unbind()
{
	CUnbind pak;

	sendPacket(pak);

	return 0;
}

int CSmppConnection::enquireLink()
{
	CEnquireLink pak;

	sendPacket(pak);

	return 0;
}