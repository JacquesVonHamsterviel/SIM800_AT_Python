
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "common.h"
#include "buffer.h"
#include "smpputil.h"
#include "smpp.h"

#include <vector>
using namespace std;

#ifdef SMPPAPI_GOLD			//GOLD

template <class T>
class SMPPLIB_DECLSPEC COptionalParamList
{
public:

	vector<T*> m_list;

	COptionalParamList()
	{
	}

	~COptionalParamList()
	{
		clear();
	}

	uint32 getCount()	
	{
		return m_list.size();
	}

	void encodePacket(PBYTE &pby, int &nsz)
	{
		int pos = 0;
		PBYTE psub = pby;

		vector<T*>::iterator itr;
		for (itr = m_list.begin(); itr != m_list.end(); itr++)
		{
			psub = psub+pos;
			pos = ((T*) (*itr))->encodePacket(psub, nsz);
		}
	}

	bool loadPacket(PBYTE pby, int nsz)
	{
		int pos = 0;
		int pksz = 0;

		while (nsz > 0)
		{
			T* pContent = new T;
			pksz = pContent->loadPacket(pby+pos, nsz);
			nsz -= pksz;
			pos += pksz;

			m_list.push_back(pContent);
		}
		return true;
	}

	uint32 getPacketLength()
	{
		int len = 0;

		vector<T*>::iterator itr;
		for (itr = m_list.begin(); itr != m_list.end(); itr++)
		{
			len += ((T*) (*itr))->getPacketLength();
		}
		return len;
	}

	void add(T* pcon)
	{
		m_list.push_back(pcon);
	}

	void clear()
	{
		vector<T*>::iterator itr;
		for (itr = m_list.begin(); itr != m_list.end(); itr++)
		{
			delete (*itr);
		}
		m_list.clear();
	}

};

class SMPPLIB_DECLSPEC COptionalParameter
{
public:
	COptionalParameter();
	~COptionalParameter();

protected:
	OPTIONAL_PARAMETER m_parameter_tag;
	uint32 m_length;
	PBYTE m_value;

public:
	OPTIONAL_PARAMETER getParameterTag();

	uint32 getLength();
	void getValue(PBYTE &val, uint32 &nsz);

	void setParameterTag(OPTIONAL_PARAMETER pt);
	void setValue(PBYTE val, uint32 nsz);
	
	uint32 encodePacket(PBYTE &pby, int &nsz);
	uint32 loadPacket(PBYTE pby, int nsz);
};

#endif		//GOLD


class CPacketBase;			//forward declaration

//CPacketBaseInitializer
class SMPPLIB_DECLSPEC CPacketBaseInitializer
{
	friend CPacketBase;

public:
	CPacketBaseInitializer();
	~CPacketBaseInitializer();

protected:
	static uint32 m_seqnum_counter;
	static CRITICAL_SECTION m_cs_seqnum;

	static uint32 getNewSeqNum();
};


//CPacketBase

class SMPPLIB_DECLSPEC CPacketBase
{

public:
	CPacketBase();
	CPacketBase(uint32 seqnum);
	virtual ~CPacketBase();

protected:

	CBuffer m_buffer;

    uint32 m_command_length;
    uint32 m_command_id;

    uint32 m_command_status;
    uint32 m_sequence_number;

	uint32 getHeaderLength();

	static uint32 getNewSeqNum();

public:

#ifdef SMPPAPI_GOLD
	COptionalParamList<COptionalParameter>	m_optional_parameters;
#endif

public:

	//getter
	uint32 getCommandId();
	uint32 getCommandStatus();
	uint32 getSequenceNumber();

	//setter
	void setCommandId(uint32 cmid);
	void setCommandStatus(uint32 cmst);
	void setSequenceNumber(uint32 seqn);

	virtual void encodeBody(PBYTE &pby, int &nsz);
	virtual bool loadPacket(PBYTE pby, int nsz);
	virtual uint32 getCommandLength();

};

//CPacketBase end

//CBindPacketBase
class SMPPLIB_DECLSPEC CBindPacketBase : public CPacketBase
{
public:
	CBindPacketBase();
	virtual ~CBindPacketBase();

protected:

	CString m_system_id;
	CString m_password;
	CString m_system_type;

	uint32 m_interface_version;

	CSmppAddress m_address_range;

public:

	//getter
	CString getSystemId();
	CString getPassword();
	CString getSystemType();
	
	CSmppAddress& getSourceRange();

	//setter
	void setSystemId(CString sid);
	void setPassword(CString pwd);
	void setSystemType(CString stype);
	void setSourceRange(CSmppAddress &addr);

	void setInterfaceVersion(uint32 iver);

	virtual void encodeBody(PBYTE &pby, int &nsz);
	virtual bool loadPacket(PBYTE pby, int nsz);
	virtual uint32 getCommandLength();
};

//CBindPacketBase end

//CMessagePacketBase
class SMPPLIB_DECLSPEC CMessagePacketBase : public CPacketBase
{
public:
	CMessagePacketBase();
	virtual ~CMessagePacketBase();

protected:

	CString m_service_type;

	CSmppAddress m_source;
	CSmppAddress m_destination;

	uint32 m_esm_class;
	uint32 m_protocol_id;
	uint32 m_priority_flag;

	CSmppDate m_scheduled_delivery;
	CSmppDate m_validity_period;

	uint32 m_registered_delivery;
	uint32 m_replace_if_present;

	uint32 m_data_coding;
	uint32 m_sm_default_msg_id;

	uint32 m_sm_length;

	PBYTE m_message;

public:

	//getter
	CString getServiceType();
	CSmppAddress getSource();
	CSmppAddress getDestination();

	uint32 getEsmClass();
	uint32 getProtocolId();
	uint32 getPriorityFlag();

	CSmppDate getScheduledDelivery();
	CSmppDate getValidityPeriod();

	uint32 getRegisteredDelivery();
	uint32 getReplaceIfPresent();

	uint32 getSmDefaultMsgId();
	uint32 getDataCoding();

	uint32 getSmLength();

	void getMessage(PBYTE &msg, uint32 &nsz);

	//setter
	void setServiceType(CString stype);
	void setSource(CSmppAddress &src);
	void setDestination(CSmppAddress &dest);

	void setEsmClass(uint32 esm);
	void setProtocolId(uint32 pid);
	void setPriorityFlag(uint32 pflag);

	void setScheduledDelivery(CSmppDate &schdel);
	void setValidityPeriod(CSmppDate &valprd);

	void setRegisteredDelivery(uint32 reg);
	void setReplaceIfPresent(uint32 rip);
	void setDataCoding(uint32 enc);

	void setSmDefaultMsgId(uint32 mdefid);

	void setSmLength(uint32 smlen);
	void setMessage(PBYTE msg, uint32 nsz);

public:
	virtual void encodeBody(PBYTE &pby, int &nsz);
	virtual bool loadPacket(PBYTE pby, int nsz);
	virtual uint32 getCommandLength();
};

//CMessagePacketBase end


//CDataPacketBase
class SMPPLIB_DECLSPEC CDataPacketBase : public CPacketBase
{
public:
	CDataPacketBase();
	virtual ~CDataPacketBase();

protected:

	CString m_service_type;

	CSmppAddress m_source;
	CSmppAddress m_destination;

	uint32 m_esm_class;

	uint32 m_registered_delivery;

	uint32 m_data_coding;

public:

	//getter
	CString getServiceType();
	CSmppAddress getSource();
	CSmppAddress getDestination();

	uint32 getEsmClass();

	uint32 getRegisteredDelivery();

	uint32 getDataCoding();

	//setter
	void setServiceType(CString stype);
	void setSource(CSmppAddress &src);
	void setDestination(CSmppAddress &dest);

	void setEsmClass(uint32 esm);

	void setRegisteredDelivery(uint32 reg);

	void setDataCoding(uint32 enc);

public:
	virtual void encodeBody(PBYTE &pby, int &nsz);
	virtual bool loadPacket(PBYTE pby, int nsz);
	virtual uint32 getCommandLength();
};

//CDataPacketBase end

//CDataPacketRespBase
class SMPPLIB_DECLSPEC CDataPacketRespBase : public CPacketBase
{
public:
	CDataPacketRespBase();
	virtual ~CDataPacketRespBase();

protected:

	CString m_message_id;

public:

	//getter
	CString getMessageId();

	//setter
	void setMessageId(CString msgid);

public:
	virtual void encodeBody(PBYTE &pby, int &nsz);
	virtual bool loadPacket(PBYTE pby, int nsz);
	virtual uint32 getCommandLength();
};

//CDataPacketRespBase end

//CBindRespBase
class SMPPLIB_DECLSPEC CBindRespBase : public CPacketBase
{
public:
	CBindRespBase();
	~CBindRespBase();

protected:
	CString m_system_id;

public:
	void setSystemId(CString sid);

	CString getSystemId();

	virtual void encodeBody(PBYTE &pby, int &nsz);
	virtual bool loadPacket(PBYTE pby, int nsz);
	virtual uint32 getCommandLength();
};

//CBindRespBase end

//CMessageRespBase

class SMPPLIB_DECLSPEC CMessageRespBase : public CPacketBase
{
public:
	CMessageRespBase();
	~CMessageRespBase();

protected:
	CString m_message_id;

public:

	CString getMessageId();
	void setMessageId(CString msgid);

	virtual void encodeBody(PBYTE &pby, int &nsz);
	virtual bool loadPacket(PBYTE pby, int nsz);
	virtual uint32 getCommandLength();
};

//CMessageRespBase end