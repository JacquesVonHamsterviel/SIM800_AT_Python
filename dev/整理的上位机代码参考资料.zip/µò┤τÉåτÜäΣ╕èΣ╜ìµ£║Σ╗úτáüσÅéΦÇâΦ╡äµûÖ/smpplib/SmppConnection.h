// SmppConnection.h: interface for the CSmppConnection class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SMPPCONNECTION_H__9FD3F262_D5BF_404B_AEB6_5895317DCEE4__INCLUDED_)
#define AFX_SMPPCONNECTION_H__9FD3F262_D5BF_404B_AEB6_5895317DCEE4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ServerLink.h"

class SMPPLIB_DECLSPEC CSmppConnection : public CServerLink
{
public:
	CSmppConnection();
	virtual ~CSmppConnection();

	int bind(CString sysid, CString passwd, CString systype, CString addrrange);

	virtual int bind(CString sysid, CString passwd, CString systype, CSmppAddress &addrrange) = 0;

	int unbind();
	int enquireLink();

protected:
	CString m_system_id;
	CString m_password;
	CString m_system_type;

	CSmppAddress	m_address_range;
};

#endif // !defined(AFX_SMPPCONNECTION_H__9FD3F262_D5BF_404B_AEB6_5895317DCEE4__INCLUDED_)
