
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//#include "stdafx.h"
#include "common.h"
#include "packetbase.h"

//special packet for link close
class SMPPLIB_DECLSPEC CLinkClose : public CPacketBase
{
public:
	CLinkClose();
	~CLinkClose();

	void encodeBody(PBYTE &pby, int &nsz);
};

class SMPPLIB_DECLSPEC CBindTransmitter : public CBindPacketBase
{
public:
	CBindTransmitter();
	~CBindTransmitter();
};

class SMPPLIB_DECLSPEC CBindReceiver : public CBindPacketBase
{
public:
	CBindReceiver();
	~CBindReceiver();
};

class SMPPLIB_DECLSPEC CBindTransceiver : public CBindPacketBase
{
public:
	CBindTransceiver();
	~CBindTransceiver();
};

class SMPPLIB_DECLSPEC CQuerySM : public CPacketBase
{
public:
	CQuerySM();
	~CQuerySM();

	CString getMessageId();
	void setMessageId(CString msgid);

protected:
	CString m_message_id;
	CSmppAddress m_source;

public:
	void encodeBody(PBYTE &pby, int &nsz);
	bool loadPacket(PBYTE pby, int nsz);
	uint32 getCommandLength();

};

class SMPPLIB_DECLSPEC CUnbind : public CPacketBase
{
public:
	CUnbind();
	~CUnbind();

	void encodeBody(PBYTE &pby, int &nsz);
};

class SMPPLIB_DECLSPEC CSubmitSM : public CMessagePacketBase
{
public:
	CSubmitSM();
	~CSubmitSM();
};

class SMPPLIB_DECLSPEC CDeliverSM : public CMessagePacketBase
{
public:
	CDeliverSM();
	~CDeliverSM();
};

class SMPPLIB_DECLSPEC CDataSM : public CDataPacketBase
{
public:
	CDataSM();
	~CDataSM();
};

class SMPPLIB_DECLSPEC CBindTransmitterResp : public CBindRespBase
{
public:
	CBindTransmitterResp();
	CBindTransmitterResp(CBindTransmitter &pak);

	~CBindTransmitterResp();
};

class SMPPLIB_DECLSPEC CBindReceiverResp : public CBindRespBase
{
public:
	CBindReceiverResp();
	CBindReceiverResp(CBindReceiver &pak);

	~CBindReceiverResp();
};

class SMPPLIB_DECLSPEC CBindTransceiverResp : public CBindRespBase
{
public:
	CBindTransceiverResp();
	CBindTransceiverResp(CBindTransceiver &pak);

	~CBindTransceiverResp();
};

class SMPPLIB_DECLSPEC CQuerySMResp : public CPacketBase
{
public:
	CQuerySMResp();
	CQuerySMResp(CQuerySM &pak);

	~CQuerySMResp();

	CString getMessageId();
	void setMessageId(CString msgid);

	CSmppDate getFinalDate();
	void setFinalDate(CSmppDate &fldate);

	uint32 getMessageState();
	void setMessageState(uint32 msgst);

	uint32 getErrorCode();
	void setErrorCode(uint32 errcode);

protected:
	CString m_message_id;
	CSmppDate m_final_date;
	uint32 m_message_state;
	uint32 m_error_code;

public:
	void encodeBody(PBYTE &pby, int &nsz);
	bool loadPacket(PBYTE pby, int nsz);
	uint32 getCommandLength();

};

class SMPPLIB_DECLSPEC CSubmitSMResp : public CMessageRespBase
{
public:
	CSubmitSMResp();
	CSubmitSMResp(CSubmitSM &pak);

	~CSubmitSMResp();
};

class SMPPLIB_DECLSPEC CDeliverSMResp : public CMessageRespBase
{
public:
	CDeliverSMResp();
	CDeliverSMResp(CDeliverSM &pak);

	~CDeliverSMResp();
};

class SMPPLIB_DECLSPEC CUnbindResp : public CPacketBase
{
public:
	CUnbindResp();
	CUnbindResp(CUnbind &pak);

	~CUnbindResp();

	void encodeBody(PBYTE &pby, int &nsz);
};

class SMPPLIB_DECLSPEC CEnquireLink : public CPacketBase
{
public:
	CEnquireLink();
	~CEnquireLink();

	void encodeBody(PBYTE &pby, int &nsz);
};

class SMPPLIB_DECLSPEC CEnquireLinkResp : public CPacketBase
{
public:
	CEnquireLinkResp();
	CEnquireLinkResp(CEnquireLink &pak);

	~CEnquireLinkResp();

	void encodeBody(PBYTE &pby, int &nsz);
};

class SMPPLIB_DECLSPEC CDataSMResp : public CPacketBase
{
public:
	CDataSMResp();
	CDataSMResp(CDataSM &pak);

	~CDataSMResp();
};

class SMPPLIB_DECLSPEC CGenericNack : public CPacketBase
{
public:
	CGenericNack();
	~CGenericNack();

	void encodeBody(PBYTE &pby, int &nsz);
};

class SMPPLIB_DECLSPEC CAlertNotification : public CPacketBase
{
public:
	CAlertNotification();
	~CAlertNotification();

	CSmppAddress getSource();
	CSmppAddress getEsme();

	void setSource(CSmppAddress &src);
	void setEsme(CSmppAddress &esme);

protected:
	CSmppAddress m_source;
	CSmppAddress m_esme;

public:
	void encodeBody(PBYTE &pby, int &nsz);
	bool loadPacket(PBYTE pby, int nsz);
	uint32 getCommandLength();
};