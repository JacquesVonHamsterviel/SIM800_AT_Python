#include "stdafx.h"
#include "common.h"
#include "smpputil.h"

//CSmppDate

CSmppDate::CSmppDate()
{
	::GetSystemTime(&m_time);
	m_null = true;
}

CSmppDate::~CSmppDate()
{
}

void CSmppDate::setDate(CString sd)
{
	//YYMMDDhhmmsstnn+

	if (sd.IsEmpty())
	{
		m_null = true;
	}
	else
	{
		int milsec;
		int tz;
		int yr;

		sscanf(sd, "%02d%02d%02d%02d%02d%02d%1d%2d+",
			&yr,
			&m_time.wMonth,
			&m_time.wDay,
			&m_time.wHour,
			&m_time.wMinute,
			&m_time.wSecond,
			&milsec,
			&tz);

		m_time.wYear = yr + 2000;
		m_time.wMilliseconds = milsec * 100;

		m_null = false;
	}
}

void CSmppDate::setDate(SYSTEMTIME sdt)
{
	m_time = sdt;
	m_null = false;
}

CString CSmppDate::toString()
{
	CString s;

	TCHAR buf1[10];
	TCHAR buf2[10];
	TCHAR buf3[10];

	if (m_null)
		return "";
	else
	{
		sprintf(buf1, "%04d%02d%02d", m_time.wYear, m_time.wMonth, m_time.wDay);
		sprintf(buf2, "%02d%02d%02d", m_time.wHour, m_time.wMinute, m_time.wSecond);
		sprintf(buf3, "%3d", m_time.wMilliseconds);

		s = (buf1+2);
		s += buf2;
		s += buf3[0];
		s += "00+";
		TRACE(s);
	}

	return s;
}

CSmppDate& CSmppDate::operator=(CSmppDate &dt)
{
	m_time = dt.m_time;
	m_null = dt.m_null;

	return *this;
}

int CSmppDate::getLength()
{
	if (m_null)
		return 0;
	else
		return 16;
}

void CSmppDate::setNull()
{
	m_null = true;
}

bool CSmppDate::isNull()
{
	return m_null;
}

//CSmppDate end

//CSmppAddress

CSmppAddress::CSmppAddress()
{
	m_addr_ton = 0;
	m_addr_npi = 0;
	m_addr = "";
}

CSmppAddress::CSmppAddress(uint32 adrton, uint32 adrnpi, CString addr)
{
	setAddrTon(adrton);
	setAddrNpi(adrnpi);
	setAddr(addr);
}

CSmppAddress::~CSmppAddress()
{

}

CSmppAddress& CSmppAddress::operator=(CSmppAddress& addr)
{
	m_addr_npi = addr.m_addr_npi;
	m_addr_ton = addr.m_addr_ton;
	m_addr = addr.m_addr;

	return *this;
}

int CSmppAddress::getLength()
{
	return 3 + m_addr.GetLength();
}

void CSmppAddress::setAddrTon(uint32 adrton)
{
	m_addr_ton = adrton;
}

void CSmppAddress::setAddrNpi(uint32 adrnpi)
{
	m_addr_npi = adrnpi;
}

void CSmppAddress::setAddr(CString addr)
{
	m_addr = addr;
}
