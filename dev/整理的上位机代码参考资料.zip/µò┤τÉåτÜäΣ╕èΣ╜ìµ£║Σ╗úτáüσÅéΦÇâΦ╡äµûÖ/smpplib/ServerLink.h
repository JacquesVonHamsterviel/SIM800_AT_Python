// ServerLink.h: interface for the CServerLink class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SERVERLINK_H__10F3112D_CD2D_4245_BBE8_165E24B7B2DB__INCLUDED_)
#define AFX_SERVERLINK_H__10F3112D_CD2D_4245_BBE8_165E24B7B2DB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "common.h"
#include "winsock2.h"
#include "packetbase.h"

class SMPPLIB_DECLSPEC CServerLink  
{
public:
	CServerLink();
	CServerLink(CString svrip);
	CServerLink(CString svrip, int port);
	virtual ~CServerLink();

	bool open();
	void close();

	bool isConnected();
	CString getServerIP();
	int getServerPort();

	void init(CString svrip, int port);

	int send(PBYTE data, uint32 datalen);

	bool sendPacket(CPacketBase &pak);

protected:
	CString m_ServerIP;
	int m_ServerPort;

	SOCKET m_nSocket;
	
	bool m_bConnected;
	HANDLE m_hDisconnectEvent;

	CWinThread *m_pIOWinThread;
	unsigned m_dwThreadId;
	HANDLE m_hThread;
	WSAEVENT m_hEvent;

	static UINT IOThreadProc(LPVOID pParam);
	unsigned IOThreadRun();

	bool OnRead();
	bool OnClose();

	virtual void parse_packet(PBYTE pby, int nsz) = 0;

	CRITICAL_SECTION m_cs;

protected:
	HANDLE m_hKillEvent;

	void (__stdcall *m_pProcessPacket)(CPacketBase *pak, LPVOID param);
	LPVOID m_Param;

private:
	int m_nBlockSize;
	int	m_nTotalRead;
	BOOL m_bReadHeader;

public:
	void registerProcessPacket(void(__stdcall *start_address)(CPacketBase *pak, LPVOID param), LPVOID param);
};

#endif // !defined(AFX_SERVERLINK_H__10F3112D_CD2D_4245_BBE8_165E24B7B2DB__INCLUDED_)
