// EsmeTransmitterCom.h : Declaration of the CEsmeTransmitterCom

#pragma once
#include "resource.h"       // main symbols

#include "SMPPCOM.h"

#include "..\smpppacket.h"
#include "..\EsmeTransmitter.h"

// CEsmeTransmitterCom

class ATL_NO_VTABLE CEsmeTransmitterCom : public CEsmeTransmitter,
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CEsmeTransmitterCom, &CLSID_EsmeTransmitterCom>,
	public IDispatchImpl<IEsmeTransmitterCom, &IID_IEsmeTransmitterCom, &LIBID_SMPPCOMLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
public:
	CEsmeTransmitterCom()
	{
		m_last_msg_id = "";
		m_response_event = CreateEvent(NULL, TRUE, FALSE, NULL);
		InitializeCriticalSection(&m_cs);

		//register callback handle function to processing receiving packets
		registerProcessPacket(processPacketProc, this);
	}

	~CEsmeTransmitterCom()
	{
		CloseHandle(m_response_event);
		DeleteCriticalSection(&m_cs);
	}

DECLARE_REGISTRY_RESOURCEID(IDR_ESMETRANSMITTERCOM)

DECLARE_NOT_AGGREGATABLE(CEsmeTransmitterCom)

BEGIN_COM_MAP(CEsmeTransmitterCom)
	COM_INTERFACE_ENTRY(IEsmeTransmitterCom)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()


	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}
	
	void FinalRelease() 
	{
	}

public:

	STDMETHOD(bind)(BSTR sysid, BSTR passwd, BSTR systype, ISmppAddressCom* iaddr, VARIANT_BOOL* pret);
	STDMETHOD(unbind)(VARIANT_BOOL* pret);
	STDMETHOD(enquireLink)(VARIANT_BOOL* pret);
	STDMETHOD(init)(BSTR svrip, LONG port);
	STDMETHOD(close)(void);
	STDMETHOD(get_Connected)(VARIANT_BOOL* pVal);
	STDMETHOD(submitMessage)(ISubmitSMCom* isubmit, BSTR* pMsgid, VARIANT_BOOL* pret);


protected:
	static void __stdcall processPacketProc(CPacketBase *pak, LPVOID param);
	void processPacket(CPacketBase *pak);

protected:

	HANDLE m_response_event;		//set when a response is got

	CString m_last_msg_id;		//responsed msg id for last submit message

	bool m_last_error;			//last command has error

	CRITICAL_SECTION m_cs;
};

OBJECT_ENTRY_AUTO(__uuidof(EsmeTransmitterCom), CEsmeTransmitterCom)
