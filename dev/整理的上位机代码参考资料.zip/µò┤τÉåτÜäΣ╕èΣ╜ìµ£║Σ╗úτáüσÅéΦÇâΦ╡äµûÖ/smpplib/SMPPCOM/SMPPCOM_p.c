
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* this ALWAYS GENERATED file contains the proxy stub code */


 /* File created by MIDL compiler version 6.00.0347 */
/* at Tue Jul 30 12:52:05 2002
 */
/* Compiler settings for SMPPCOM.idl:
    Oicf, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#if !defined(_M_IA64) && !defined(_M_AMD64)
#define USE_STUBLESS_PROXY


/* verify that the <rpcproxy.h> version is high enough to compile this file*/
#ifndef __REDQ_RPCPROXY_H_VERSION__
#define __REQUIRED_RPCPROXY_H_VERSION__ 440
#endif


#include "rpcproxy.h"
#ifndef __RPCPROXY_H_VERSION__
#error this stub requires an updated version of <rpcproxy.h>
#endif // __RPCPROXY_H_VERSION__


#include "SMPPCOM.h"

#define TYPE_FORMAT_STRING_SIZE   1117                              
#define PROC_FORMAT_STRING_SIZE   1279                              
#define TRANSMIT_AS_TABLE_SIZE    0            
#define WIRE_MARSHAL_TABLE_SIZE   2            

typedef struct _MIDL_TYPE_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ TYPE_FORMAT_STRING_SIZE ];
    } MIDL_TYPE_FORMAT_STRING;

typedef struct _MIDL_PROC_FORMAT_STRING
    {
    short          Pad;
    unsigned char  Format[ PROC_FORMAT_STRING_SIZE ];
    } MIDL_PROC_FORMAT_STRING;


static RPC_SYNTAX_IDENTIFIER  _RpcTransferSyntax = 
{{0x8A885D04,0x1CEB,0x11C9,{0x9F,0xE8,0x08,0x00,0x2B,0x10,0x48,0x60}},{2,0}};


extern const MIDL_TYPE_FORMAT_STRING __MIDL_TypeFormatString;
extern const MIDL_PROC_FORMAT_STRING __MIDL_ProcFormatString;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO ISmppDateCom_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO ISmppDateCom_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO ISmppAddressCom_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO ISmppAddressCom_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO ISubmitSMCom_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO ISubmitSMCom_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO IEsmeTransmitterCom_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO IEsmeTransmitterCom_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO IDeliverSMCom_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO IDeliverSMCom_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO IEsmeTransceiverCom_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO IEsmeTransceiverCom_ProxyInfo;


extern const MIDL_STUB_DESC Object_StubDesc;


extern const MIDL_SERVER_INFO IEsmeReceiverCom_ServerInfo;
extern const MIDL_STUBLESS_PROXY_INFO IEsmeReceiverCom_ProxyInfo;


extern const USER_MARSHAL_ROUTINE_QUADRUPLE UserMarshalRoutines[ WIRE_MARSHAL_TABLE_SIZE ];

#if !defined(__RPC_WIN32__)
#error  Invalid build platform for this stub.
#endif

#if !(TARGET_IS_NT40_OR_LATER)
#error You need a Windows NT 4.0 or later to run this stub because it uses these features:
#error   -Oif or -Oicf, [wire_marshal] or [user_marshal] attribute.
#error However, your C/C++ compilation flags indicate you intend to run this app on earlier systems.
#error This app will die there with the RPC_X_WRONG_STUB_VERSION error.
#endif


static const MIDL_PROC_FORMAT_STRING __MIDL_ProcFormatString =
    {
        0,
        {

	/* Procedure get_TON */


	/* Procedure isNull */

			0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/*  2 */	NdrFcLong( 0x0 ),	/* 0 */
/*  6 */	NdrFcShort( 0x7 ),	/* 7 */
/*  8 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 10 */	NdrFcShort( 0x0 ),	/* 0 */
/* 12 */	NdrFcShort( 0x22 ),	/* 34 */
/* 14 */	0x4,		/* Oi2 Flags:  has return, */
			0x2,		/* 2 */

	/* Parameter pVal */


	/* Parameter valnull */

/* 16 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 18 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 20 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */

/* 22 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 24 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 26 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure setNull */

/* 28 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 30 */	NdrFcLong( 0x0 ),	/* 0 */
/* 34 */	NdrFcShort( 0x8 ),	/* 8 */
/* 36 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 38 */	NdrFcShort( 0x0 ),	/* 0 */
/* 40 */	NdrFcShort( 0x8 ),	/* 8 */
/* 42 */	0x4,		/* Oi2 Flags:  has return, */
			0x1,		/* 1 */

	/* Return value */

/* 44 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 46 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 48 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure toString */

/* 50 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 52 */	NdrFcLong( 0x0 ),	/* 0 */
/* 56 */	NdrFcShort( 0x9 ),	/* 9 */
/* 58 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 60 */	NdrFcShort( 0x0 ),	/* 0 */
/* 62 */	NdrFcShort( 0x8 ),	/* 8 */
/* 64 */	0x5,		/* Oi2 Flags:  srv must size, has return, */
			0x2,		/* 2 */

	/* Parameter strdate */

/* 66 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 68 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 70 */	NdrFcShort( 0x22 ),	/* Type Offset=34 */

	/* Return value */

/* 72 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 74 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 76 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure setDate */

/* 78 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 80 */	NdrFcLong( 0x0 ),	/* 0 */
/* 84 */	NdrFcShort( 0xa ),	/* 10 */
/* 86 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 88 */	NdrFcShort( 0x0 ),	/* 0 */
/* 90 */	NdrFcShort( 0x8 ),	/* 8 */
/* 92 */	0x6,		/* Oi2 Flags:  clt must size, has return, */
			0x2,		/* 2 */

	/* Parameter strdate */

/* 94 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 96 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 98 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Return value */

/* 100 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 102 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 104 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_TON */

/* 106 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 108 */	NdrFcLong( 0x0 ),	/* 0 */
/* 112 */	NdrFcShort( 0x8 ),	/* 8 */
/* 114 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 116 */	NdrFcShort( 0x6 ),	/* 6 */
/* 118 */	NdrFcShort( 0x8 ),	/* 8 */
/* 120 */	0x4,		/* Oi2 Flags:  has return, */
			0x2,		/* 2 */

	/* Parameter newVal */

/* 122 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 124 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 126 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */

/* 128 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 130 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 132 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure enquireLink */


	/* Procedure enquireLink */


	/* Procedure enquireLink */


	/* Procedure get_NPI */

/* 134 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 136 */	NdrFcLong( 0x0 ),	/* 0 */
/* 140 */	NdrFcShort( 0x9 ),	/* 9 */
/* 142 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 144 */	NdrFcShort( 0x0 ),	/* 0 */
/* 146 */	NdrFcShort( 0x22 ),	/* 34 */
/* 148 */	0x4,		/* Oi2 Flags:  has return, */
			0x2,		/* 2 */

	/* Parameter pret */


	/* Parameter pret */


	/* Parameter pret */


	/* Parameter pVal */

/* 150 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 152 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 154 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */


	/* Return value */


	/* Return value */

/* 156 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 158 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 160 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_NPI */

/* 162 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 164 */	NdrFcLong( 0x0 ),	/* 0 */
/* 168 */	NdrFcShort( 0xa ),	/* 10 */
/* 170 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 172 */	NdrFcShort( 0x6 ),	/* 6 */
/* 174 */	NdrFcShort( 0x8 ),	/* 8 */
/* 176 */	0x4,		/* Oi2 Flags:  has return, */
			0x2,		/* 2 */

	/* Parameter newVal */

/* 178 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 180 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 182 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */

/* 184 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 186 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 188 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Address */

/* 190 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 192 */	NdrFcLong( 0x0 ),	/* 0 */
/* 196 */	NdrFcShort( 0xb ),	/* 11 */
/* 198 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 200 */	NdrFcShort( 0x0 ),	/* 0 */
/* 202 */	NdrFcShort( 0x8 ),	/* 8 */
/* 204 */	0x5,		/* Oi2 Flags:  srv must size, has return, */
			0x2,		/* 2 */

	/* Parameter pVal */

/* 206 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 208 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 210 */	NdrFcShort( 0x22 ),	/* Type Offset=34 */

	/* Return value */

/* 212 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 214 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 216 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Address */

/* 218 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 220 */	NdrFcLong( 0x0 ),	/* 0 */
/* 224 */	NdrFcShort( 0xc ),	/* 12 */
/* 226 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 228 */	NdrFcShort( 0x0 ),	/* 0 */
/* 230 */	NdrFcShort( 0x8 ),	/* 8 */
/* 232 */	0x6,		/* Oi2 Flags:  clt must size, has return, */
			0x2,		/* 2 */

	/* Parameter newVal */

/* 234 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 236 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 238 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Return value */

/* 240 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 242 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 244 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_ServiceType */


	/* Procedure get_ServiceType */

/* 246 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 248 */	NdrFcLong( 0x0 ),	/* 0 */
/* 252 */	NdrFcShort( 0x7 ),	/* 7 */
/* 254 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 256 */	NdrFcShort( 0x0 ),	/* 0 */
/* 258 */	NdrFcShort( 0x8 ),	/* 8 */
/* 260 */	0x5,		/* Oi2 Flags:  srv must size, has return, */
			0x2,		/* 2 */

	/* Parameter pVal */


	/* Parameter pVal */

/* 262 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 264 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 266 */	NdrFcShort( 0x22 ),	/* Type Offset=34 */

	/* Return value */


	/* Return value */

/* 268 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 270 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 272 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_ServiceType */


	/* Procedure put_ServiceType */

/* 274 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 276 */	NdrFcLong( 0x0 ),	/* 0 */
/* 280 */	NdrFcShort( 0x8 ),	/* 8 */
/* 282 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 284 */	NdrFcShort( 0x0 ),	/* 0 */
/* 286 */	NdrFcShort( 0x8 ),	/* 8 */
/* 288 */	0x6,		/* Oi2 Flags:  clt must size, has return, */
			0x2,		/* 2 */

	/* Parameter newVal */


	/* Parameter newVal */

/* 290 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 292 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 294 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Return value */


	/* Return value */

/* 296 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 298 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 300 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Source */


	/* Procedure get_Source */

/* 302 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 304 */	NdrFcLong( 0x0 ),	/* 0 */
/* 308 */	NdrFcShort( 0x9 ),	/* 9 */
/* 310 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 312 */	NdrFcShort( 0x0 ),	/* 0 */
/* 314 */	NdrFcShort( 0x8 ),	/* 8 */
/* 316 */	0x5,		/* Oi2 Flags:  srv must size, has return, */
			0x2,		/* 2 */

	/* Parameter pVal */


	/* Parameter pVal */

/* 318 */	NdrFcShort( 0x13 ),	/* Flags:  must size, must free, out, */
/* 320 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 322 */	NdrFcShort( 0x3a ),	/* Type Offset=58 */

	/* Return value */


	/* Return value */

/* 324 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 326 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 328 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Source */


	/* Procedure put_Source */

/* 330 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 332 */	NdrFcLong( 0x0 ),	/* 0 */
/* 336 */	NdrFcShort( 0xa ),	/* 10 */
/* 338 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 340 */	NdrFcShort( 0x0 ),	/* 0 */
/* 342 */	NdrFcShort( 0x8 ),	/* 8 */
/* 344 */	0x6,		/* Oi2 Flags:  clt must size, has return, */
			0x2,		/* 2 */

	/* Parameter newVal */


	/* Parameter newVal */

/* 346 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 348 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 350 */	NdrFcShort( 0x3e ),	/* Type Offset=62 */

	/* Return value */


	/* Return value */

/* 352 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 354 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 356 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Destination */


	/* Procedure get_Destination */

/* 358 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 360 */	NdrFcLong( 0x0 ),	/* 0 */
/* 364 */	NdrFcShort( 0xb ),	/* 11 */
/* 366 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 368 */	NdrFcShort( 0x0 ),	/* 0 */
/* 370 */	NdrFcShort( 0x8 ),	/* 8 */
/* 372 */	0x5,		/* Oi2 Flags:  srv must size, has return, */
			0x2,		/* 2 */

	/* Parameter pVal */


	/* Parameter pVal */

/* 374 */	NdrFcShort( 0x13 ),	/* Flags:  must size, must free, out, */
/* 376 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 378 */	NdrFcShort( 0x3a ),	/* Type Offset=58 */

	/* Return value */


	/* Return value */

/* 380 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 382 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 384 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Destination */


	/* Procedure put_Destination */

/* 386 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 388 */	NdrFcLong( 0x0 ),	/* 0 */
/* 392 */	NdrFcShort( 0xc ),	/* 12 */
/* 394 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 396 */	NdrFcShort( 0x0 ),	/* 0 */
/* 398 */	NdrFcShort( 0x8 ),	/* 8 */
/* 400 */	0x6,		/* Oi2 Flags:  clt must size, has return, */
			0x2,		/* 2 */

	/* Parameter newVal */


	/* Parameter newVal */

/* 402 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 404 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 406 */	NdrFcShort( 0x3e ),	/* Type Offset=62 */

	/* Return value */


	/* Return value */

/* 408 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 410 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 412 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_esmClass */


	/* Procedure get_esmClass */

/* 414 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 416 */	NdrFcLong( 0x0 ),	/* 0 */
/* 420 */	NdrFcShort( 0xd ),	/* 13 */
/* 422 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 424 */	NdrFcShort( 0x0 ),	/* 0 */
/* 426 */	NdrFcShort( 0x22 ),	/* 34 */
/* 428 */	0x4,		/* Oi2 Flags:  has return, */
			0x2,		/* 2 */

	/* Parameter pVal */


	/* Parameter pVal */

/* 430 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 432 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 434 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */

/* 436 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 438 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 440 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_esmClass */


	/* Procedure put_esmClass */

/* 442 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 444 */	NdrFcLong( 0x0 ),	/* 0 */
/* 448 */	NdrFcShort( 0xe ),	/* 14 */
/* 450 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 452 */	NdrFcShort( 0x6 ),	/* 6 */
/* 454 */	NdrFcShort( 0x8 ),	/* 8 */
/* 456 */	0x4,		/* Oi2 Flags:  has return, */
			0x2,		/* 2 */

	/* Parameter newVal */


	/* Parameter newVal */

/* 458 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 460 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 462 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */

/* 464 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 466 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 468 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_dataCoding */


	/* Procedure get_dataCoding */

/* 470 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 472 */	NdrFcLong( 0x0 ),	/* 0 */
/* 476 */	NdrFcShort( 0xf ),	/* 15 */
/* 478 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 480 */	NdrFcShort( 0x0 ),	/* 0 */
/* 482 */	NdrFcShort( 0x22 ),	/* 34 */
/* 484 */	0x4,		/* Oi2 Flags:  has return, */
			0x2,		/* 2 */

	/* Parameter pVal */


	/* Parameter pVal */

/* 486 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 488 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 490 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */

/* 492 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 494 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 496 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_dataCoding */


	/* Procedure put_dataCoding */

/* 498 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 500 */	NdrFcLong( 0x0 ),	/* 0 */
/* 504 */	NdrFcShort( 0x10 ),	/* 16 */
/* 506 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 508 */	NdrFcShort( 0x6 ),	/* 6 */
/* 510 */	NdrFcShort( 0x8 ),	/* 8 */
/* 512 */	0x4,		/* Oi2 Flags:  has return, */
			0x2,		/* 2 */

	/* Parameter newVal */


	/* Parameter newVal */

/* 514 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 516 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 518 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */

/* 520 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 522 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 524 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_protocolID */


	/* Procedure get_protocolID */

/* 526 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 528 */	NdrFcLong( 0x0 ),	/* 0 */
/* 532 */	NdrFcShort( 0x11 ),	/* 17 */
/* 534 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 536 */	NdrFcShort( 0x0 ),	/* 0 */
/* 538 */	NdrFcShort( 0x22 ),	/* 34 */
/* 540 */	0x4,		/* Oi2 Flags:  has return, */
			0x2,		/* 2 */

	/* Parameter pVal */


	/* Parameter pVal */

/* 542 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 544 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 546 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */

/* 548 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 550 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 552 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_protocolID */


	/* Procedure put_protocolID */

/* 554 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 556 */	NdrFcLong( 0x0 ),	/* 0 */
/* 560 */	NdrFcShort( 0x12 ),	/* 18 */
/* 562 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 564 */	NdrFcShort( 0x6 ),	/* 6 */
/* 566 */	NdrFcShort( 0x8 ),	/* 8 */
/* 568 */	0x4,		/* Oi2 Flags:  has return, */
			0x2,		/* 2 */

	/* Parameter newVal */


	/* Parameter newVal */

/* 570 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 572 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 574 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */

/* 576 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 578 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 580 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_priorityFlag */


	/* Procedure get_priorityFlag */

/* 582 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 584 */	NdrFcLong( 0x0 ),	/* 0 */
/* 588 */	NdrFcShort( 0x13 ),	/* 19 */
/* 590 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 592 */	NdrFcShort( 0x0 ),	/* 0 */
/* 594 */	NdrFcShort( 0x22 ),	/* 34 */
/* 596 */	0x4,		/* Oi2 Flags:  has return, */
			0x2,		/* 2 */

	/* Parameter pVal */


	/* Parameter pVal */

/* 598 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 600 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 602 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */

/* 604 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 606 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 608 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_priorityFlag */


	/* Procedure put_priorityFlag */

/* 610 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 612 */	NdrFcLong( 0x0 ),	/* 0 */
/* 616 */	NdrFcShort( 0x14 ),	/* 20 */
/* 618 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 620 */	NdrFcShort( 0x6 ),	/* 6 */
/* 622 */	NdrFcShort( 0x8 ),	/* 8 */
/* 624 */	0x4,		/* Oi2 Flags:  has return, */
			0x2,		/* 2 */

	/* Parameter newVal */


	/* Parameter newVal */

/* 626 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 628 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 630 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */

/* 632 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 634 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 636 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_scheduledDelivery */


	/* Procedure get_scheduledDelivery */

/* 638 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 640 */	NdrFcLong( 0x0 ),	/* 0 */
/* 644 */	NdrFcShort( 0x15 ),	/* 21 */
/* 646 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 648 */	NdrFcShort( 0x0 ),	/* 0 */
/* 650 */	NdrFcShort( 0x8 ),	/* 8 */
/* 652 */	0x5,		/* Oi2 Flags:  srv must size, has return, */
			0x2,		/* 2 */

	/* Parameter pVal */


	/* Parameter pVal */

/* 654 */	NdrFcShort( 0x13 ),	/* Flags:  must size, must free, out, */
/* 656 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 658 */	NdrFcShort( 0x50 ),	/* Type Offset=80 */

	/* Return value */


	/* Return value */

/* 660 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 662 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 664 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_scheduledDelivery */


	/* Procedure put_scheduledDelivery */

/* 666 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 668 */	NdrFcLong( 0x0 ),	/* 0 */
/* 672 */	NdrFcShort( 0x16 ),	/* 22 */
/* 674 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 676 */	NdrFcShort( 0x0 ),	/* 0 */
/* 678 */	NdrFcShort( 0x8 ),	/* 8 */
/* 680 */	0x6,		/* Oi2 Flags:  clt must size, has return, */
			0x2,		/* 2 */

	/* Parameter newVal */


	/* Parameter newVal */

/* 682 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 684 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 686 */	NdrFcShort( 0x54 ),	/* Type Offset=84 */

	/* Return value */


	/* Return value */

/* 688 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 690 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 692 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_validityPeriod */


	/* Procedure get_validityPeriod */

/* 694 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 696 */	NdrFcLong( 0x0 ),	/* 0 */
/* 700 */	NdrFcShort( 0x17 ),	/* 23 */
/* 702 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 704 */	NdrFcShort( 0x0 ),	/* 0 */
/* 706 */	NdrFcShort( 0x8 ),	/* 8 */
/* 708 */	0x5,		/* Oi2 Flags:  srv must size, has return, */
			0x2,		/* 2 */

	/* Parameter pVal */


	/* Parameter pVal */

/* 710 */	NdrFcShort( 0x13 ),	/* Flags:  must size, must free, out, */
/* 712 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 714 */	NdrFcShort( 0x50 ),	/* Type Offset=80 */

	/* Return value */


	/* Return value */

/* 716 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 718 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 720 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_validityPeriod */


	/* Procedure put_validityPeriod */

/* 722 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 724 */	NdrFcLong( 0x0 ),	/* 0 */
/* 728 */	NdrFcShort( 0x18 ),	/* 24 */
/* 730 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 732 */	NdrFcShort( 0x0 ),	/* 0 */
/* 734 */	NdrFcShort( 0x8 ),	/* 8 */
/* 736 */	0x6,		/* Oi2 Flags:  clt must size, has return, */
			0x2,		/* 2 */

	/* Parameter newVal */


	/* Parameter newVal */

/* 738 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 740 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 742 */	NdrFcShort( 0x54 ),	/* Type Offset=84 */

	/* Return value */


	/* Return value */

/* 744 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 746 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 748 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_registeredDelivery */


	/* Procedure get_registeredDelivery */

/* 750 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 752 */	NdrFcLong( 0x0 ),	/* 0 */
/* 756 */	NdrFcShort( 0x19 ),	/* 25 */
/* 758 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 760 */	NdrFcShort( 0x0 ),	/* 0 */
/* 762 */	NdrFcShort( 0x22 ),	/* 34 */
/* 764 */	0x4,		/* Oi2 Flags:  has return, */
			0x2,		/* 2 */

	/* Parameter pVal */


	/* Parameter pVal */

/* 766 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 768 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 770 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */

/* 772 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 774 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 776 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_registeredDelivery */


	/* Procedure put_registeredDelivery */

/* 778 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 780 */	NdrFcLong( 0x0 ),	/* 0 */
/* 784 */	NdrFcShort( 0x1a ),	/* 26 */
/* 786 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 788 */	NdrFcShort( 0x6 ),	/* 6 */
/* 790 */	NdrFcShort( 0x8 ),	/* 8 */
/* 792 */	0x4,		/* Oi2 Flags:  has return, */
			0x2,		/* 2 */

	/* Parameter newVal */


	/* Parameter newVal */

/* 794 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 796 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 798 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */

/* 800 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 802 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 804 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_replaceIfPresent */


	/* Procedure get_replaceIfPresent */

/* 806 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 808 */	NdrFcLong( 0x0 ),	/* 0 */
/* 812 */	NdrFcShort( 0x1b ),	/* 27 */
/* 814 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 816 */	NdrFcShort( 0x0 ),	/* 0 */
/* 818 */	NdrFcShort( 0x22 ),	/* 34 */
/* 820 */	0x4,		/* Oi2 Flags:  has return, */
			0x2,		/* 2 */

	/* Parameter pVal */


	/* Parameter pVal */

/* 822 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 824 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 826 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */

/* 828 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 830 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 832 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_replaceIfPresent */


	/* Procedure put_replaceIfPresent */

/* 834 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 836 */	NdrFcLong( 0x0 ),	/* 0 */
/* 840 */	NdrFcShort( 0x1c ),	/* 28 */
/* 842 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 844 */	NdrFcShort( 0x6 ),	/* 6 */
/* 846 */	NdrFcShort( 0x8 ),	/* 8 */
/* 848 */	0x4,		/* Oi2 Flags:  has return, */
			0x2,		/* 2 */

	/* Parameter newVal */


	/* Parameter newVal */

/* 850 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 852 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 854 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */

/* 856 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 858 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 860 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_smDefaultMsgId */


	/* Procedure get_smDefaultMsgId */

/* 862 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 864 */	NdrFcLong( 0x0 ),	/* 0 */
/* 868 */	NdrFcShort( 0x1d ),	/* 29 */
/* 870 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 872 */	NdrFcShort( 0x0 ),	/* 0 */
/* 874 */	NdrFcShort( 0x22 ),	/* 34 */
/* 876 */	0x4,		/* Oi2 Flags:  has return, */
			0x2,		/* 2 */

	/* Parameter pVal */


	/* Parameter pVal */

/* 878 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 880 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 882 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */

/* 884 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 886 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 888 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_smDefaultMsgId */


	/* Procedure put_smDefaultMsgId */

/* 890 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 892 */	NdrFcLong( 0x0 ),	/* 0 */
/* 896 */	NdrFcShort( 0x1e ),	/* 30 */
/* 898 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 900 */	NdrFcShort( 0x6 ),	/* 6 */
/* 902 */	NdrFcShort( 0x8 ),	/* 8 */
/* 904 */	0x4,		/* Oi2 Flags:  has return, */
			0x2,		/* 2 */

	/* Parameter newVal */


	/* Parameter newVal */

/* 906 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 908 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 910 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */

/* 912 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 914 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 916 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Message */


	/* Procedure get_Message */

/* 918 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 920 */	NdrFcLong( 0x0 ),	/* 0 */
/* 924 */	NdrFcShort( 0x1f ),	/* 31 */
/* 926 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 928 */	NdrFcShort( 0x0 ),	/* 0 */
/* 930 */	NdrFcShort( 0x8 ),	/* 8 */
/* 932 */	0x5,		/* Oi2 Flags:  srv must size, has return, */
			0x2,		/* 2 */

	/* Parameter pVal */


	/* Parameter pVal */

/* 934 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 936 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 938 */	NdrFcShort( 0x22 ),	/* Type Offset=34 */

	/* Return value */


	/* Return value */

/* 940 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 942 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 944 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure put_Message */


	/* Procedure put_Message */

/* 946 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 948 */	NdrFcLong( 0x0 ),	/* 0 */
/* 952 */	NdrFcShort( 0x20 ),	/* 32 */
/* 954 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 956 */	NdrFcShort( 0x0 ),	/* 0 */
/* 958 */	NdrFcShort( 0x8 ),	/* 8 */
/* 960 */	0x6,		/* Oi2 Flags:  clt must size, has return, */
			0x2,		/* 2 */

	/* Parameter newVal */


	/* Parameter newVal */

/* 962 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 964 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 966 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Return value */


	/* Return value */

/* 968 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 970 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 972 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure compactMessage */


	/* Procedure compactMessage */

/* 974 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 976 */	NdrFcLong( 0x0 ),	/* 0 */
/* 980 */	NdrFcShort( 0x21 ),	/* 33 */
/* 982 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 984 */	NdrFcShort( 0x0 ),	/* 0 */
/* 986 */	NdrFcShort( 0x8 ),	/* 8 */
/* 988 */	0x4,		/* Oi2 Flags:  has return, */
			0x1,		/* 1 */

	/* Return value */


	/* Return value */

/* 990 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 992 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 994 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure flipByteOrder */


	/* Procedure flipByteOrder */

/* 996 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 998 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1002 */	NdrFcShort( 0x22 ),	/* 34 */
/* 1004 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1006 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1008 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1010 */	0x4,		/* Oi2 Flags:  has return, */
			0x1,		/* 1 */

	/* Return value */


	/* Return value */

/* 1012 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1014 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1016 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure setMessage */


	/* Procedure setMessage */

/* 1018 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1020 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1024 */	NdrFcShort( 0x23 ),	/* 35 */
/* 1026 */	NdrFcShort( 0x18 ),	/* x86 Stack size/offset = 24 */
/* 1028 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1030 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1032 */	0x6,		/* Oi2 Flags:  clt must size, has return, */
			0x2,		/* 2 */

	/* Parameter msgdata */


	/* Parameter msgdata */

/* 1034 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1036 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1038 */	NdrFcShort( 0x42e ),	/* Type Offset=1070 */

	/* Return value */


	/* Return value */

/* 1040 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1042 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 1044 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure getMessage */


	/* Procedure getMessage */

/* 1046 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1048 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1052 */	NdrFcShort( 0x24 ),	/* 36 */
/* 1054 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1056 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1058 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1060 */	0x5,		/* Oi2 Flags:  srv must size, has return, */
			0x2,		/* 2 */

	/* Parameter pmsgdata */


	/* Parameter pmsgdata */

/* 1062 */	NdrFcShort( 0x4113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=16 */
/* 1064 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1066 */	NdrFcShort( 0x440 ),	/* Type Offset=1088 */

	/* Return value */


	/* Return value */

/* 1068 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1070 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1072 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure bind */


	/* Procedure bind */


	/* Procedure bind */

/* 1074 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1076 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1080 */	NdrFcShort( 0x7 ),	/* 7 */
/* 1082 */	NdrFcShort( 0x1c ),	/* x86 Stack size/offset = 28 */
/* 1084 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1086 */	NdrFcShort( 0x22 ),	/* 34 */
/* 1088 */	0x6,		/* Oi2 Flags:  clt must size, has return, */
			0x6,		/* 6 */

	/* Parameter sysid */


	/* Parameter sysid */


	/* Parameter sysid */

/* 1090 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1092 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1094 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter passwd */


	/* Parameter passwd */


	/* Parameter passwd */

/* 1096 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1098 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1100 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter systype */


	/* Parameter systype */


	/* Parameter systype */

/* 1102 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1104 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1106 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter iaddr */


	/* Parameter iaddr */


	/* Parameter iaddr */

/* 1108 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 1110 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 1112 */	NdrFcShort( 0x3e ),	/* Type Offset=62 */

	/* Parameter pret */


	/* Parameter pret */


	/* Parameter pret */

/* 1114 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 1116 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 1118 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */


	/* Return value */

/* 1120 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1122 */	NdrFcShort( 0x18 ),	/* x86 Stack size/offset = 24 */
/* 1124 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure unbind */


	/* Procedure unbind */


	/* Procedure unbind */

/* 1126 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1128 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1132 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1134 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1136 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1138 */	NdrFcShort( 0x22 ),	/* 34 */
/* 1140 */	0x4,		/* Oi2 Flags:  has return, */
			0x2,		/* 2 */

	/* Parameter pret */


	/* Parameter pret */


	/* Parameter pret */

/* 1142 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 1144 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1146 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */


	/* Return value */

/* 1148 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1150 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1152 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure init */


	/* Procedure init */


	/* Procedure init */

/* 1154 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1156 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1160 */	NdrFcShort( 0xa ),	/* 10 */
/* 1162 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 1164 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1166 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1168 */	0x6,		/* Oi2 Flags:  clt must size, has return, */
			0x3,		/* 3 */

	/* Parameter svrip */


	/* Parameter svrip */


	/* Parameter svrip */

/* 1170 */	NdrFcShort( 0x8b ),	/* Flags:  must size, must free, in, by val, */
/* 1172 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1174 */	NdrFcShort( 0x30 ),	/* Type Offset=48 */

	/* Parameter port */


	/* Parameter port */


	/* Parameter port */

/* 1176 */	NdrFcShort( 0x48 ),	/* Flags:  in, base type, */
/* 1178 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1180 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */


	/* Return value */

/* 1182 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1184 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1186 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure close */


	/* Procedure close */


	/* Procedure close */

/* 1188 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1190 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1194 */	NdrFcShort( 0xb ),	/* 11 */
/* 1196 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1198 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1200 */	NdrFcShort( 0x8 ),	/* 8 */
/* 1202 */	0x4,		/* Oi2 Flags:  has return, */
			0x1,		/* 1 */

	/* Return value */


	/* Return value */


	/* Return value */

/* 1204 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1206 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1208 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure get_Connected */


	/* Procedure get_Connected */


	/* Procedure get_Connected */

/* 1210 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1212 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1216 */	NdrFcShort( 0xc ),	/* 12 */
/* 1218 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1220 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1222 */	NdrFcShort( 0x22 ),	/* 34 */
/* 1224 */	0x4,		/* Oi2 Flags:  has return, */
			0x2,		/* 2 */

	/* Parameter pVal */


	/* Parameter pVal */


	/* Parameter pVal */

/* 1226 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 1228 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1230 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */


	/* Return value */

/* 1232 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1234 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1236 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

	/* Procedure submitMessage */


	/* Procedure submitMessage */

/* 1238 */	0x33,		/* FC_AUTO_HANDLE */
			0x6c,		/* Old Flags:  object, Oi2 */
/* 1240 */	NdrFcLong( 0x0 ),	/* 0 */
/* 1244 */	NdrFcShort( 0xd ),	/* 13 */
/* 1246 */	NdrFcShort( 0x14 ),	/* x86 Stack size/offset = 20 */
/* 1248 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1250 */	NdrFcShort( 0x22 ),	/* 34 */
/* 1252 */	0x7,		/* Oi2 Flags:  srv must size, clt must size, has return, */
			0x4,		/* 4 */

	/* Parameter isubmit */


	/* Parameter isubmit */

/* 1254 */	NdrFcShort( 0xb ),	/* Flags:  must size, must free, in, */
/* 1256 */	NdrFcShort( 0x4 ),	/* x86 Stack size/offset = 4 */
/* 1258 */	NdrFcShort( 0x44a ),	/* Type Offset=1098 */

	/* Parameter pMsgid */


	/* Parameter pMsgid */

/* 1260 */	NdrFcShort( 0x2113 ),	/* Flags:  must size, must free, out, simple ref, srv alloc size=8 */
/* 1262 */	NdrFcShort( 0x8 ),	/* x86 Stack size/offset = 8 */
/* 1264 */	NdrFcShort( 0x22 ),	/* Type Offset=34 */

	/* Parameter pret */


	/* Parameter pret */

/* 1266 */	NdrFcShort( 0x2150 ),	/* Flags:  out, base type, simple ref, srv alloc size=8 */
/* 1268 */	NdrFcShort( 0xc ),	/* x86 Stack size/offset = 12 */
/* 1270 */	0x6,		/* FC_SHORT */
			0x0,		/* 0 */

	/* Return value */


	/* Return value */

/* 1272 */	NdrFcShort( 0x70 ),	/* Flags:  out, return, base type, */
/* 1274 */	NdrFcShort( 0x10 ),	/* x86 Stack size/offset = 16 */
/* 1276 */	0x8,		/* FC_LONG */
			0x0,		/* 0 */

			0x0
        }
    };

static const MIDL_TYPE_FORMAT_STRING __MIDL_TypeFormatString =
    {
        0,
        {
			NdrFcShort( 0x0 ),	/* 0 */
/*  2 */	
			0x11, 0xc,	/* FC_RP [alloced_on_stack] [simple_pointer] */
/*  4 */	0x6,		/* FC_SHORT */
			0x5c,		/* FC_PAD */
/*  6 */	
			0x11, 0x4,	/* FC_RP [alloced_on_stack] */
/*  8 */	NdrFcShort( 0x1a ),	/* Offset= 26 (34) */
/* 10 */	
			0x13, 0x0,	/* FC_OP */
/* 12 */	NdrFcShort( 0xc ),	/* Offset= 12 (24) */
/* 14 */	
			0x1b,		/* FC_CARRAY */
			0x1,		/* 1 */
/* 16 */	NdrFcShort( 0x2 ),	/* 2 */
/* 18 */	0x9,		/* Corr desc: FC_ULONG */
			0x0,		/*  */
/* 20 */	NdrFcShort( 0xfffc ),	/* -4 */
/* 22 */	0x6,		/* FC_SHORT */
			0x5b,		/* FC_END */
/* 24 */	
			0x17,		/* FC_CSTRUCT */
			0x3,		/* 3 */
/* 26 */	NdrFcShort( 0x8 ),	/* 8 */
/* 28 */	NdrFcShort( 0xfffffff2 ),	/* Offset= -14 (14) */
/* 30 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 32 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 34 */	0xb4,		/* FC_USER_MARSHAL */
			0x83,		/* 131 */
/* 36 */	NdrFcShort( 0x0 ),	/* 0 */
/* 38 */	NdrFcShort( 0x4 ),	/* 4 */
/* 40 */	NdrFcShort( 0x0 ),	/* 0 */
/* 42 */	NdrFcShort( 0xffffffe0 ),	/* Offset= -32 (10) */
/* 44 */	
			0x12, 0x0,	/* FC_UP */
/* 46 */	NdrFcShort( 0xffffffea ),	/* Offset= -22 (24) */
/* 48 */	0xb4,		/* FC_USER_MARSHAL */
			0x83,		/* 131 */
/* 50 */	NdrFcShort( 0x0 ),	/* 0 */
/* 52 */	NdrFcShort( 0x4 ),	/* 4 */
/* 54 */	NdrFcShort( 0x0 ),	/* 0 */
/* 56 */	NdrFcShort( 0xfffffff4 ),	/* Offset= -12 (44) */
/* 58 */	
			0x11, 0x10,	/* FC_RP [pointer_deref] */
/* 60 */	NdrFcShort( 0x2 ),	/* Offset= 2 (62) */
/* 62 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 64 */	NdrFcLong( 0x2cb72805 ),	/* 750200837 */
/* 68 */	NdrFcShort( 0x62f8 ),	/* 25336 */
/* 70 */	NdrFcShort( 0x470f ),	/* 18191 */
/* 72 */	0xb2,		/* 178 */
			0x8e,		/* 142 */
/* 74 */	0x85,		/* 133 */
			0x15,		/* 21 */
/* 76 */	0x95,		/* 149 */
			0x72,		/* 114 */
/* 78 */	0xdf,		/* 223 */
			0x87,		/* 135 */
/* 80 */	
			0x11, 0x10,	/* FC_RP [pointer_deref] */
/* 82 */	NdrFcShort( 0x2 ),	/* Offset= 2 (84) */
/* 84 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 86 */	NdrFcLong( 0xdf4bde09 ),	/* -548676087 */
/* 90 */	NdrFcShort( 0x633a ),	/* 25402 */
/* 92 */	NdrFcShort( 0x4514 ),	/* 17684 */
/* 94 */	0xb7,		/* 183 */
			0x2d,		/* 45 */
/* 96 */	0x34,		/* 52 */
			0x22,		/* 34 */
/* 98 */	0x71,		/* 113 */
			0xd6,		/* 214 */
/* 100 */	0x14,		/* 20 */
			0x63,		/* 99 */
/* 102 */	
			0x12, 0x0,	/* FC_UP */
/* 104 */	NdrFcShort( 0x3b2 ),	/* Offset= 946 (1050) */
/* 106 */	
			0x2b,		/* FC_NON_ENCAPSULATED_UNION */
			0x9,		/* FC_ULONG */
/* 108 */	0x7,		/* Corr desc: FC_USHORT */
			0x0,		/*  */
/* 110 */	NdrFcShort( 0xfff8 ),	/* -8 */
/* 112 */	NdrFcShort( 0x2 ),	/* Offset= 2 (114) */
/* 114 */	NdrFcShort( 0x10 ),	/* 16 */
/* 116 */	NdrFcShort( 0x2f ),	/* 47 */
/* 118 */	NdrFcLong( 0x14 ),	/* 20 */
/* 122 */	NdrFcShort( 0x800b ),	/* Simple arm type: FC_HYPER */
/* 124 */	NdrFcLong( 0x3 ),	/* 3 */
/* 128 */	NdrFcShort( 0x8008 ),	/* Simple arm type: FC_LONG */
/* 130 */	NdrFcLong( 0x11 ),	/* 17 */
/* 134 */	NdrFcShort( 0x8001 ),	/* Simple arm type: FC_BYTE */
/* 136 */	NdrFcLong( 0x2 ),	/* 2 */
/* 140 */	NdrFcShort( 0x8006 ),	/* Simple arm type: FC_SHORT */
/* 142 */	NdrFcLong( 0x4 ),	/* 4 */
/* 146 */	NdrFcShort( 0x800a ),	/* Simple arm type: FC_FLOAT */
/* 148 */	NdrFcLong( 0x5 ),	/* 5 */
/* 152 */	NdrFcShort( 0x800c ),	/* Simple arm type: FC_DOUBLE */
/* 154 */	NdrFcLong( 0xb ),	/* 11 */
/* 158 */	NdrFcShort( 0x8006 ),	/* Simple arm type: FC_SHORT */
/* 160 */	NdrFcLong( 0xa ),	/* 10 */
/* 164 */	NdrFcShort( 0x8008 ),	/* Simple arm type: FC_LONG */
/* 166 */	NdrFcLong( 0x6 ),	/* 6 */
/* 170 */	NdrFcShort( 0xe8 ),	/* Offset= 232 (402) */
/* 172 */	NdrFcLong( 0x7 ),	/* 7 */
/* 176 */	NdrFcShort( 0x800c ),	/* Simple arm type: FC_DOUBLE */
/* 178 */	NdrFcLong( 0x8 ),	/* 8 */
/* 182 */	NdrFcShort( 0xffffff76 ),	/* Offset= -138 (44) */
/* 184 */	NdrFcLong( 0xd ),	/* 13 */
/* 188 */	NdrFcShort( 0xdc ),	/* Offset= 220 (408) */
/* 190 */	NdrFcLong( 0x9 ),	/* 9 */
/* 194 */	NdrFcShort( 0xe8 ),	/* Offset= 232 (426) */
/* 196 */	NdrFcLong( 0x2000 ),	/* 8192 */
/* 200 */	NdrFcShort( 0xf4 ),	/* Offset= 244 (444) */
/* 202 */	NdrFcLong( 0x24 ),	/* 36 */
/* 206 */	NdrFcShort( 0x302 ),	/* Offset= 770 (976) */
/* 208 */	NdrFcLong( 0x4024 ),	/* 16420 */
/* 212 */	NdrFcShort( 0x2fc ),	/* Offset= 764 (976) */
/* 214 */	NdrFcLong( 0x4011 ),	/* 16401 */
/* 218 */	NdrFcShort( 0x2fa ),	/* Offset= 762 (980) */
/* 220 */	NdrFcLong( 0x4002 ),	/* 16386 */
/* 224 */	NdrFcShort( 0x2f8 ),	/* Offset= 760 (984) */
/* 226 */	NdrFcLong( 0x4003 ),	/* 16387 */
/* 230 */	NdrFcShort( 0x2f6 ),	/* Offset= 758 (988) */
/* 232 */	NdrFcLong( 0x4014 ),	/* 16404 */
/* 236 */	NdrFcShort( 0x2f4 ),	/* Offset= 756 (992) */
/* 238 */	NdrFcLong( 0x4004 ),	/* 16388 */
/* 242 */	NdrFcShort( 0x2f2 ),	/* Offset= 754 (996) */
/* 244 */	NdrFcLong( 0x4005 ),	/* 16389 */
/* 248 */	NdrFcShort( 0x2f0 ),	/* Offset= 752 (1000) */
/* 250 */	NdrFcLong( 0x400b ),	/* 16395 */
/* 254 */	NdrFcShort( 0x2da ),	/* Offset= 730 (984) */
/* 256 */	NdrFcLong( 0x400a ),	/* 16394 */
/* 260 */	NdrFcShort( 0x2d8 ),	/* Offset= 728 (988) */
/* 262 */	NdrFcLong( 0x4006 ),	/* 16390 */
/* 266 */	NdrFcShort( 0x2e2 ),	/* Offset= 738 (1004) */
/* 268 */	NdrFcLong( 0x4007 ),	/* 16391 */
/* 272 */	NdrFcShort( 0x2d8 ),	/* Offset= 728 (1000) */
/* 274 */	NdrFcLong( 0x4008 ),	/* 16392 */
/* 278 */	NdrFcShort( 0x2da ),	/* Offset= 730 (1008) */
/* 280 */	NdrFcLong( 0x400d ),	/* 16397 */
/* 284 */	NdrFcShort( 0x2d8 ),	/* Offset= 728 (1012) */
/* 286 */	NdrFcLong( 0x4009 ),	/* 16393 */
/* 290 */	NdrFcShort( 0x2d6 ),	/* Offset= 726 (1016) */
/* 292 */	NdrFcLong( 0x6000 ),	/* 24576 */
/* 296 */	NdrFcShort( 0x2d4 ),	/* Offset= 724 (1020) */
/* 298 */	NdrFcLong( 0x400c ),	/* 16396 */
/* 302 */	NdrFcShort( 0x2d2 ),	/* Offset= 722 (1024) */
/* 304 */	NdrFcLong( 0x10 ),	/* 16 */
/* 308 */	NdrFcShort( 0x8002 ),	/* Simple arm type: FC_CHAR */
/* 310 */	NdrFcLong( 0x12 ),	/* 18 */
/* 314 */	NdrFcShort( 0x8006 ),	/* Simple arm type: FC_SHORT */
/* 316 */	NdrFcLong( 0x13 ),	/* 19 */
/* 320 */	NdrFcShort( 0x8008 ),	/* Simple arm type: FC_LONG */
/* 322 */	NdrFcLong( 0x15 ),	/* 21 */
/* 326 */	NdrFcShort( 0x800b ),	/* Simple arm type: FC_HYPER */
/* 328 */	NdrFcLong( 0x16 ),	/* 22 */
/* 332 */	NdrFcShort( 0x8008 ),	/* Simple arm type: FC_LONG */
/* 334 */	NdrFcLong( 0x17 ),	/* 23 */
/* 338 */	NdrFcShort( 0x8008 ),	/* Simple arm type: FC_LONG */
/* 340 */	NdrFcLong( 0xe ),	/* 14 */
/* 344 */	NdrFcShort( 0x2b0 ),	/* Offset= 688 (1032) */
/* 346 */	NdrFcLong( 0x400e ),	/* 16398 */
/* 350 */	NdrFcShort( 0x2b4 ),	/* Offset= 692 (1042) */
/* 352 */	NdrFcLong( 0x4010 ),	/* 16400 */
/* 356 */	NdrFcShort( 0x2b2 ),	/* Offset= 690 (1046) */
/* 358 */	NdrFcLong( 0x4012 ),	/* 16402 */
/* 362 */	NdrFcShort( 0x26e ),	/* Offset= 622 (984) */
/* 364 */	NdrFcLong( 0x4013 ),	/* 16403 */
/* 368 */	NdrFcShort( 0x26c ),	/* Offset= 620 (988) */
/* 370 */	NdrFcLong( 0x4015 ),	/* 16405 */
/* 374 */	NdrFcShort( 0x26a ),	/* Offset= 618 (992) */
/* 376 */	NdrFcLong( 0x4016 ),	/* 16406 */
/* 380 */	NdrFcShort( 0x260 ),	/* Offset= 608 (988) */
/* 382 */	NdrFcLong( 0x4017 ),	/* 16407 */
/* 386 */	NdrFcShort( 0x25a ),	/* Offset= 602 (988) */
/* 388 */	NdrFcLong( 0x0 ),	/* 0 */
/* 392 */	NdrFcShort( 0x0 ),	/* Offset= 0 (392) */
/* 394 */	NdrFcLong( 0x1 ),	/* 1 */
/* 398 */	NdrFcShort( 0x0 ),	/* Offset= 0 (398) */
/* 400 */	NdrFcShort( 0xffffffff ),	/* Offset= -1 (399) */
/* 402 */	
			0x15,		/* FC_STRUCT */
			0x7,		/* 7 */
/* 404 */	NdrFcShort( 0x8 ),	/* 8 */
/* 406 */	0xb,		/* FC_HYPER */
			0x5b,		/* FC_END */
/* 408 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 410 */	NdrFcLong( 0x0 ),	/* 0 */
/* 414 */	NdrFcShort( 0x0 ),	/* 0 */
/* 416 */	NdrFcShort( 0x0 ),	/* 0 */
/* 418 */	0xc0,		/* 192 */
			0x0,		/* 0 */
/* 420 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 422 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 424 */	0x0,		/* 0 */
			0x46,		/* 70 */
/* 426 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 428 */	NdrFcLong( 0x20400 ),	/* 132096 */
/* 432 */	NdrFcShort( 0x0 ),	/* 0 */
/* 434 */	NdrFcShort( 0x0 ),	/* 0 */
/* 436 */	0xc0,		/* 192 */
			0x0,		/* 0 */
/* 438 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 440 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 442 */	0x0,		/* 0 */
			0x46,		/* 70 */
/* 444 */	
			0x12, 0x10,	/* FC_UP [pointer_deref] */
/* 446 */	NdrFcShort( 0x2 ),	/* Offset= 2 (448) */
/* 448 */	
			0x12, 0x0,	/* FC_UP */
/* 450 */	NdrFcShort( 0x1fc ),	/* Offset= 508 (958) */
/* 452 */	
			0x2a,		/* FC_ENCAPSULATED_UNION */
			0x49,		/* 73 */
/* 454 */	NdrFcShort( 0x18 ),	/* 24 */
/* 456 */	NdrFcShort( 0xa ),	/* 10 */
/* 458 */	NdrFcLong( 0x8 ),	/* 8 */
/* 462 */	NdrFcShort( 0x58 ),	/* Offset= 88 (550) */
/* 464 */	NdrFcLong( 0xd ),	/* 13 */
/* 468 */	NdrFcShort( 0x78 ),	/* Offset= 120 (588) */
/* 470 */	NdrFcLong( 0x9 ),	/* 9 */
/* 474 */	NdrFcShort( 0x94 ),	/* Offset= 148 (622) */
/* 476 */	NdrFcLong( 0xc ),	/* 12 */
/* 480 */	NdrFcShort( 0xbc ),	/* Offset= 188 (668) */
/* 482 */	NdrFcLong( 0x24 ),	/* 36 */
/* 486 */	NdrFcShort( 0x114 ),	/* Offset= 276 (762) */
/* 488 */	NdrFcLong( 0x800d ),	/* 32781 */
/* 492 */	NdrFcShort( 0x130 ),	/* Offset= 304 (796) */
/* 494 */	NdrFcLong( 0x10 ),	/* 16 */
/* 498 */	NdrFcShort( 0x148 ),	/* Offset= 328 (826) */
/* 500 */	NdrFcLong( 0x2 ),	/* 2 */
/* 504 */	NdrFcShort( 0x160 ),	/* Offset= 352 (856) */
/* 506 */	NdrFcLong( 0x3 ),	/* 3 */
/* 510 */	NdrFcShort( 0x178 ),	/* Offset= 376 (886) */
/* 512 */	NdrFcLong( 0x14 ),	/* 20 */
/* 516 */	NdrFcShort( 0x190 ),	/* Offset= 400 (916) */
/* 518 */	NdrFcShort( 0xffffffff ),	/* Offset= -1 (517) */
/* 520 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 522 */	NdrFcShort( 0x4 ),	/* 4 */
/* 524 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 526 */	NdrFcShort( 0x0 ),	/* 0 */
/* 528 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 530 */	
			0x48,		/* FC_VARIABLE_REPEAT */
			0x49,		/* FC_FIXED_OFFSET */
/* 532 */	NdrFcShort( 0x4 ),	/* 4 */
/* 534 */	NdrFcShort( 0x0 ),	/* 0 */
/* 536 */	NdrFcShort( 0x1 ),	/* 1 */
/* 538 */	NdrFcShort( 0x0 ),	/* 0 */
/* 540 */	NdrFcShort( 0x0 ),	/* 0 */
/* 542 */	0x12, 0x0,	/* FC_UP */
/* 544 */	NdrFcShort( 0xfffffdf8 ),	/* Offset= -520 (24) */
/* 546 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 548 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 550 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 552 */	NdrFcShort( 0x8 ),	/* 8 */
/* 554 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 556 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 558 */	NdrFcShort( 0x4 ),	/* 4 */
/* 560 */	NdrFcShort( 0x4 ),	/* 4 */
/* 562 */	0x11, 0x0,	/* FC_RP */
/* 564 */	NdrFcShort( 0xffffffd4 ),	/* Offset= -44 (520) */
/* 566 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 568 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 570 */	
			0x21,		/* FC_BOGUS_ARRAY */
			0x3,		/* 3 */
/* 572 */	NdrFcShort( 0x0 ),	/* 0 */
/* 574 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 576 */	NdrFcShort( 0x0 ),	/* 0 */
/* 578 */	NdrFcLong( 0xffffffff ),	/* -1 */
/* 582 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 584 */	NdrFcShort( 0xffffff50 ),	/* Offset= -176 (408) */
/* 586 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 588 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 590 */	NdrFcShort( 0x8 ),	/* 8 */
/* 592 */	NdrFcShort( 0x0 ),	/* 0 */
/* 594 */	NdrFcShort( 0x6 ),	/* Offset= 6 (600) */
/* 596 */	0x8,		/* FC_LONG */
			0x36,		/* FC_POINTER */
/* 598 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 600 */	
			0x11, 0x0,	/* FC_RP */
/* 602 */	NdrFcShort( 0xffffffe0 ),	/* Offset= -32 (570) */
/* 604 */	
			0x21,		/* FC_BOGUS_ARRAY */
			0x3,		/* 3 */
/* 606 */	NdrFcShort( 0x0 ),	/* 0 */
/* 608 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 610 */	NdrFcShort( 0x0 ),	/* 0 */
/* 612 */	NdrFcLong( 0xffffffff ),	/* -1 */
/* 616 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 618 */	NdrFcShort( 0xffffff40 ),	/* Offset= -192 (426) */
/* 620 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 622 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 624 */	NdrFcShort( 0x8 ),	/* 8 */
/* 626 */	NdrFcShort( 0x0 ),	/* 0 */
/* 628 */	NdrFcShort( 0x6 ),	/* Offset= 6 (634) */
/* 630 */	0x8,		/* FC_LONG */
			0x36,		/* FC_POINTER */
/* 632 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 634 */	
			0x11, 0x0,	/* FC_RP */
/* 636 */	NdrFcShort( 0xffffffe0 ),	/* Offset= -32 (604) */
/* 638 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 640 */	NdrFcShort( 0x4 ),	/* 4 */
/* 642 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 644 */	NdrFcShort( 0x0 ),	/* 0 */
/* 646 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 648 */	
			0x48,		/* FC_VARIABLE_REPEAT */
			0x49,		/* FC_FIXED_OFFSET */
/* 650 */	NdrFcShort( 0x4 ),	/* 4 */
/* 652 */	NdrFcShort( 0x0 ),	/* 0 */
/* 654 */	NdrFcShort( 0x1 ),	/* 1 */
/* 656 */	NdrFcShort( 0x0 ),	/* 0 */
/* 658 */	NdrFcShort( 0x0 ),	/* 0 */
/* 660 */	0x12, 0x0,	/* FC_UP */
/* 662 */	NdrFcShort( 0x184 ),	/* Offset= 388 (1050) */
/* 664 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 666 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 668 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 670 */	NdrFcShort( 0x8 ),	/* 8 */
/* 672 */	NdrFcShort( 0x0 ),	/* 0 */
/* 674 */	NdrFcShort( 0x6 ),	/* Offset= 6 (680) */
/* 676 */	0x8,		/* FC_LONG */
			0x36,		/* FC_POINTER */
/* 678 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 680 */	
			0x11, 0x0,	/* FC_RP */
/* 682 */	NdrFcShort( 0xffffffd4 ),	/* Offset= -44 (638) */
/* 684 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 686 */	NdrFcLong( 0x2f ),	/* 47 */
/* 690 */	NdrFcShort( 0x0 ),	/* 0 */
/* 692 */	NdrFcShort( 0x0 ),	/* 0 */
/* 694 */	0xc0,		/* 192 */
			0x0,		/* 0 */
/* 696 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 698 */	0x0,		/* 0 */
			0x0,		/* 0 */
/* 700 */	0x0,		/* 0 */
			0x46,		/* 70 */
/* 702 */	
			0x1b,		/* FC_CARRAY */
			0x0,		/* 0 */
/* 704 */	NdrFcShort( 0x1 ),	/* 1 */
/* 706 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 708 */	NdrFcShort( 0x4 ),	/* 4 */
/* 710 */	0x1,		/* FC_BYTE */
			0x5b,		/* FC_END */
/* 712 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 714 */	NdrFcShort( 0x10 ),	/* 16 */
/* 716 */	NdrFcShort( 0x0 ),	/* 0 */
/* 718 */	NdrFcShort( 0xa ),	/* Offset= 10 (728) */
/* 720 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 722 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 724 */	NdrFcShort( 0xffffffd8 ),	/* Offset= -40 (684) */
/* 726 */	0x36,		/* FC_POINTER */
			0x5b,		/* FC_END */
/* 728 */	
			0x12, 0x0,	/* FC_UP */
/* 730 */	NdrFcShort( 0xffffffe4 ),	/* Offset= -28 (702) */
/* 732 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 734 */	NdrFcShort( 0x4 ),	/* 4 */
/* 736 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 738 */	NdrFcShort( 0x0 ),	/* 0 */
/* 740 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 742 */	
			0x48,		/* FC_VARIABLE_REPEAT */
			0x49,		/* FC_FIXED_OFFSET */
/* 744 */	NdrFcShort( 0x4 ),	/* 4 */
/* 746 */	NdrFcShort( 0x0 ),	/* 0 */
/* 748 */	NdrFcShort( 0x1 ),	/* 1 */
/* 750 */	NdrFcShort( 0x0 ),	/* 0 */
/* 752 */	NdrFcShort( 0x0 ),	/* 0 */
/* 754 */	0x12, 0x0,	/* FC_UP */
/* 756 */	NdrFcShort( 0xffffffd4 ),	/* Offset= -44 (712) */
/* 758 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 760 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 762 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 764 */	NdrFcShort( 0x8 ),	/* 8 */
/* 766 */	NdrFcShort( 0x0 ),	/* 0 */
/* 768 */	NdrFcShort( 0x6 ),	/* Offset= 6 (774) */
/* 770 */	0x8,		/* FC_LONG */
			0x36,		/* FC_POINTER */
/* 772 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 774 */	
			0x11, 0x0,	/* FC_RP */
/* 776 */	NdrFcShort( 0xffffffd4 ),	/* Offset= -44 (732) */
/* 778 */	
			0x1d,		/* FC_SMFARRAY */
			0x0,		/* 0 */
/* 780 */	NdrFcShort( 0x8 ),	/* 8 */
/* 782 */	0x1,		/* FC_BYTE */
			0x5b,		/* FC_END */
/* 784 */	
			0x15,		/* FC_STRUCT */
			0x3,		/* 3 */
/* 786 */	NdrFcShort( 0x10 ),	/* 16 */
/* 788 */	0x8,		/* FC_LONG */
			0x6,		/* FC_SHORT */
/* 790 */	0x6,		/* FC_SHORT */
			0x4c,		/* FC_EMBEDDED_COMPLEX */
/* 792 */	0x0,		/* 0 */
			NdrFcShort( 0xfffffff1 ),	/* Offset= -15 (778) */
			0x5b,		/* FC_END */
/* 796 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 798 */	NdrFcShort( 0x18 ),	/* 24 */
/* 800 */	NdrFcShort( 0x0 ),	/* 0 */
/* 802 */	NdrFcShort( 0xa ),	/* Offset= 10 (812) */
/* 804 */	0x8,		/* FC_LONG */
			0x36,		/* FC_POINTER */
/* 806 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 808 */	NdrFcShort( 0xffffffe8 ),	/* Offset= -24 (784) */
/* 810 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 812 */	
			0x11, 0x0,	/* FC_RP */
/* 814 */	NdrFcShort( 0xffffff0c ),	/* Offset= -244 (570) */
/* 816 */	
			0x1b,		/* FC_CARRAY */
			0x0,		/* 0 */
/* 818 */	NdrFcShort( 0x1 ),	/* 1 */
/* 820 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 822 */	NdrFcShort( 0x0 ),	/* 0 */
/* 824 */	0x1,		/* FC_BYTE */
			0x5b,		/* FC_END */
/* 826 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 828 */	NdrFcShort( 0x8 ),	/* 8 */
/* 830 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 832 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 834 */	NdrFcShort( 0x4 ),	/* 4 */
/* 836 */	NdrFcShort( 0x4 ),	/* 4 */
/* 838 */	0x12, 0x0,	/* FC_UP */
/* 840 */	NdrFcShort( 0xffffffe8 ),	/* Offset= -24 (816) */
/* 842 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 844 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 846 */	
			0x1b,		/* FC_CARRAY */
			0x1,		/* 1 */
/* 848 */	NdrFcShort( 0x2 ),	/* 2 */
/* 850 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 852 */	NdrFcShort( 0x0 ),	/* 0 */
/* 854 */	0x6,		/* FC_SHORT */
			0x5b,		/* FC_END */
/* 856 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 858 */	NdrFcShort( 0x8 ),	/* 8 */
/* 860 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 862 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 864 */	NdrFcShort( 0x4 ),	/* 4 */
/* 866 */	NdrFcShort( 0x4 ),	/* 4 */
/* 868 */	0x12, 0x0,	/* FC_UP */
/* 870 */	NdrFcShort( 0xffffffe8 ),	/* Offset= -24 (846) */
/* 872 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 874 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 876 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 878 */	NdrFcShort( 0x4 ),	/* 4 */
/* 880 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 882 */	NdrFcShort( 0x0 ),	/* 0 */
/* 884 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 886 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 888 */	NdrFcShort( 0x8 ),	/* 8 */
/* 890 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 892 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 894 */	NdrFcShort( 0x4 ),	/* 4 */
/* 896 */	NdrFcShort( 0x4 ),	/* 4 */
/* 898 */	0x12, 0x0,	/* FC_UP */
/* 900 */	NdrFcShort( 0xffffffe8 ),	/* Offset= -24 (876) */
/* 902 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 904 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 906 */	
			0x1b,		/* FC_CARRAY */
			0x7,		/* 7 */
/* 908 */	NdrFcShort( 0x8 ),	/* 8 */
/* 910 */	0x19,		/* Corr desc:  field pointer, FC_ULONG */
			0x0,		/*  */
/* 912 */	NdrFcShort( 0x0 ),	/* 0 */
/* 914 */	0xb,		/* FC_HYPER */
			0x5b,		/* FC_END */
/* 916 */	
			0x16,		/* FC_PSTRUCT */
			0x3,		/* 3 */
/* 918 */	NdrFcShort( 0x8 ),	/* 8 */
/* 920 */	
			0x4b,		/* FC_PP */
			0x5c,		/* FC_PAD */
/* 922 */	
			0x46,		/* FC_NO_REPEAT */
			0x5c,		/* FC_PAD */
/* 924 */	NdrFcShort( 0x4 ),	/* 4 */
/* 926 */	NdrFcShort( 0x4 ),	/* 4 */
/* 928 */	0x12, 0x0,	/* FC_UP */
/* 930 */	NdrFcShort( 0xffffffe8 ),	/* Offset= -24 (906) */
/* 932 */	
			0x5b,		/* FC_END */

			0x8,		/* FC_LONG */
/* 934 */	0x8,		/* FC_LONG */
			0x5b,		/* FC_END */
/* 936 */	
			0x15,		/* FC_STRUCT */
			0x3,		/* 3 */
/* 938 */	NdrFcShort( 0x8 ),	/* 8 */
/* 940 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 942 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 944 */	
			0x1b,		/* FC_CARRAY */
			0x3,		/* 3 */
/* 946 */	NdrFcShort( 0x8 ),	/* 8 */
/* 948 */	0x7,		/* Corr desc: FC_USHORT */
			0x0,		/*  */
/* 950 */	NdrFcShort( 0xffd8 ),	/* -40 */
/* 952 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 954 */	NdrFcShort( 0xffffffee ),	/* Offset= -18 (936) */
/* 956 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 958 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x3,		/* 3 */
/* 960 */	NdrFcShort( 0x28 ),	/* 40 */
/* 962 */	NdrFcShort( 0xffffffee ),	/* Offset= -18 (944) */
/* 964 */	NdrFcShort( 0x0 ),	/* Offset= 0 (964) */
/* 966 */	0x6,		/* FC_SHORT */
			0x6,		/* FC_SHORT */
/* 968 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 970 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 972 */	NdrFcShort( 0xfffffdf8 ),	/* Offset= -520 (452) */
/* 974 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 976 */	
			0x12, 0x0,	/* FC_UP */
/* 978 */	NdrFcShort( 0xfffffef6 ),	/* Offset= -266 (712) */
/* 980 */	
			0x12, 0x8,	/* FC_UP [simple_pointer] */
/* 982 */	0x1,		/* FC_BYTE */
			0x5c,		/* FC_PAD */
/* 984 */	
			0x12, 0x8,	/* FC_UP [simple_pointer] */
/* 986 */	0x6,		/* FC_SHORT */
			0x5c,		/* FC_PAD */
/* 988 */	
			0x12, 0x8,	/* FC_UP [simple_pointer] */
/* 990 */	0x8,		/* FC_LONG */
			0x5c,		/* FC_PAD */
/* 992 */	
			0x12, 0x8,	/* FC_UP [simple_pointer] */
/* 994 */	0xb,		/* FC_HYPER */
			0x5c,		/* FC_PAD */
/* 996 */	
			0x12, 0x8,	/* FC_UP [simple_pointer] */
/* 998 */	0xa,		/* FC_FLOAT */
			0x5c,		/* FC_PAD */
/* 1000 */	
			0x12, 0x8,	/* FC_UP [simple_pointer] */
/* 1002 */	0xc,		/* FC_DOUBLE */
			0x5c,		/* FC_PAD */
/* 1004 */	
			0x12, 0x0,	/* FC_UP */
/* 1006 */	NdrFcShort( 0xfffffda4 ),	/* Offset= -604 (402) */
/* 1008 */	
			0x12, 0x10,	/* FC_UP [pointer_deref] */
/* 1010 */	NdrFcShort( 0xfffffc3a ),	/* Offset= -966 (44) */
/* 1012 */	
			0x12, 0x10,	/* FC_UP [pointer_deref] */
/* 1014 */	NdrFcShort( 0xfffffda2 ),	/* Offset= -606 (408) */
/* 1016 */	
			0x12, 0x10,	/* FC_UP [pointer_deref] */
/* 1018 */	NdrFcShort( 0xfffffdb0 ),	/* Offset= -592 (426) */
/* 1020 */	
			0x12, 0x10,	/* FC_UP [pointer_deref] */
/* 1022 */	NdrFcShort( 0xfffffdbe ),	/* Offset= -578 (444) */
/* 1024 */	
			0x12, 0x10,	/* FC_UP [pointer_deref] */
/* 1026 */	NdrFcShort( 0x2 ),	/* Offset= 2 (1028) */
/* 1028 */	
			0x12, 0x0,	/* FC_UP */
/* 1030 */	NdrFcShort( 0x14 ),	/* Offset= 20 (1050) */
/* 1032 */	
			0x15,		/* FC_STRUCT */
			0x7,		/* 7 */
/* 1034 */	NdrFcShort( 0x10 ),	/* 16 */
/* 1036 */	0x6,		/* FC_SHORT */
			0x1,		/* FC_BYTE */
/* 1038 */	0x1,		/* FC_BYTE */
			0x8,		/* FC_LONG */
/* 1040 */	0xb,		/* FC_HYPER */
			0x5b,		/* FC_END */
/* 1042 */	
			0x12, 0x0,	/* FC_UP */
/* 1044 */	NdrFcShort( 0xfffffff4 ),	/* Offset= -12 (1032) */
/* 1046 */	
			0x12, 0x8,	/* FC_UP [simple_pointer] */
/* 1048 */	0x2,		/* FC_CHAR */
			0x5c,		/* FC_PAD */
/* 1050 */	
			0x1a,		/* FC_BOGUS_STRUCT */
			0x7,		/* 7 */
/* 1052 */	NdrFcShort( 0x20 ),	/* 32 */
/* 1054 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1056 */	NdrFcShort( 0x0 ),	/* Offset= 0 (1056) */
/* 1058 */	0x8,		/* FC_LONG */
			0x8,		/* FC_LONG */
/* 1060 */	0x6,		/* FC_SHORT */
			0x6,		/* FC_SHORT */
/* 1062 */	0x6,		/* FC_SHORT */
			0x6,		/* FC_SHORT */
/* 1064 */	0x4c,		/* FC_EMBEDDED_COMPLEX */
			0x0,		/* 0 */
/* 1066 */	NdrFcShort( 0xfffffc40 ),	/* Offset= -960 (106) */
/* 1068 */	0x5c,		/* FC_PAD */
			0x5b,		/* FC_END */
/* 1070 */	0xb4,		/* FC_USER_MARSHAL */
			0x83,		/* 131 */
/* 1072 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1074 */	NdrFcShort( 0x10 ),	/* 16 */
/* 1076 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1078 */	NdrFcShort( 0xfffffc30 ),	/* Offset= -976 (102) */
/* 1080 */	
			0x11, 0x4,	/* FC_RP [alloced_on_stack] */
/* 1082 */	NdrFcShort( 0x6 ),	/* Offset= 6 (1088) */
/* 1084 */	
			0x13, 0x0,	/* FC_OP */
/* 1086 */	NdrFcShort( 0xffffffdc ),	/* Offset= -36 (1050) */
/* 1088 */	0xb4,		/* FC_USER_MARSHAL */
			0x83,		/* 131 */
/* 1090 */	NdrFcShort( 0x1 ),	/* 1 */
/* 1092 */	NdrFcShort( 0x10 ),	/* 16 */
/* 1094 */	NdrFcShort( 0x0 ),	/* 0 */
/* 1096 */	NdrFcShort( 0xfffffff4 ),	/* Offset= -12 (1084) */
/* 1098 */	
			0x2f,		/* FC_IP */
			0x5a,		/* FC_CONSTANT_IID */
/* 1100 */	NdrFcLong( 0xc464074b ),	/* -1000077493 */
/* 1104 */	NdrFcShort( 0x85cf ),	/* -31281 */
/* 1106 */	NdrFcShort( 0x42b7 ),	/* 17079 */
/* 1108 */	0xab,		/* 171 */
			0x92,		/* 146 */
/* 1110 */	0xe7,		/* 231 */
			0x99,		/* 153 */
/* 1112 */	0x8f,		/* 143 */
			0xba,		/* 186 */
/* 1114 */	0xfa,		/* 250 */
			0x74,		/* 116 */

			0x0
        }
    };

static const USER_MARSHAL_ROUTINE_QUADRUPLE UserMarshalRoutines[ WIRE_MARSHAL_TABLE_SIZE ] = 
        {
            
            {
            BSTR_UserSize
            ,BSTR_UserMarshal
            ,BSTR_UserUnmarshal
            ,BSTR_UserFree
            },
            {
            VARIANT_UserSize
            ,VARIANT_UserMarshal
            ,VARIANT_UserUnmarshal
            ,VARIANT_UserFree
            }

        };



/* Object interface: IUnknown, ver. 0.0,
   GUID={0x00000000,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}} */


/* Object interface: IDispatch, ver. 0.0,
   GUID={0x00020400,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}} */


/* Object interface: ISmppDateCom, ver. 0.0,
   GUID={0xDF4BDE09,0x633A,0x4514,{0xB7,0x2D,0x34,0x22,0x71,0xD6,0x14,0x63}} */

#pragma code_seg(".orpc")
static const unsigned short ISmppDateCom_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    0,
    28,
    50,
    78
    };

static const MIDL_STUBLESS_PROXY_INFO ISmppDateCom_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &ISmppDateCom_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO ISmppDateCom_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &ISmppDateCom_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(11) _ISmppDateComProxyVtbl = 
{
    &ISmppDateCom_ProxyInfo,
    &IID_ISmppDateCom,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *) (INT_PTR) -1 /* ISmppDateCom::isNull */ ,
    (void *) (INT_PTR) -1 /* ISmppDateCom::setNull */ ,
    (void *) (INT_PTR) -1 /* ISmppDateCom::toString */ ,
    (void *) (INT_PTR) -1 /* ISmppDateCom::setDate */
};


static const PRPC_STUB_FUNCTION ISmppDateCom_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _ISmppDateComStubVtbl =
{
    &IID_ISmppDateCom,
    &ISmppDateCom_ServerInfo,
    11,
    &ISmppDateCom_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: ISmppAddressCom, ver. 0.0,
   GUID={0x2CB72805,0x62F8,0x470F,{0xB2,0x8E,0x85,0x15,0x95,0x72,0xDF,0x87}} */

#pragma code_seg(".orpc")
static const unsigned short ISmppAddressCom_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    0,
    106,
    134,
    162,
    190,
    218
    };

static const MIDL_STUBLESS_PROXY_INFO ISmppAddressCom_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &ISmppAddressCom_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO ISmppAddressCom_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &ISmppAddressCom_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(13) _ISmppAddressComProxyVtbl = 
{
    &ISmppAddressCom_ProxyInfo,
    &IID_ISmppAddressCom,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *) (INT_PTR) -1 /* ISmppAddressCom::get_TON */ ,
    (void *) (INT_PTR) -1 /* ISmppAddressCom::put_TON */ ,
    (void *) (INT_PTR) -1 /* ISmppAddressCom::get_NPI */ ,
    (void *) (INT_PTR) -1 /* ISmppAddressCom::put_NPI */ ,
    (void *) (INT_PTR) -1 /* ISmppAddressCom::get_Address */ ,
    (void *) (INT_PTR) -1 /* ISmppAddressCom::put_Address */
};


static const PRPC_STUB_FUNCTION ISmppAddressCom_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _ISmppAddressComStubVtbl =
{
    &IID_ISmppAddressCom,
    &ISmppAddressCom_ServerInfo,
    13,
    &ISmppAddressCom_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: ISubmitSMCom, ver. 0.0,
   GUID={0xC464074B,0x85CF,0x42B7,{0xAB,0x92,0xE7,0x99,0x8F,0xBA,0xFA,0x74}} */

#pragma code_seg(".orpc")
static const unsigned short ISubmitSMCom_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    246,
    274,
    302,
    330,
    358,
    386,
    414,
    442,
    470,
    498,
    526,
    554,
    582,
    610,
    638,
    666,
    694,
    722,
    750,
    778,
    806,
    834,
    862,
    890,
    918,
    946,
    974,
    996,
    1018,
    1046
    };

static const MIDL_STUBLESS_PROXY_INFO ISubmitSMCom_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &ISubmitSMCom_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO ISubmitSMCom_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &ISubmitSMCom_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(37) _ISubmitSMComProxyVtbl = 
{
    &ISubmitSMCom_ProxyInfo,
    &IID_ISubmitSMCom,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *) (INT_PTR) -1 /* ISubmitSMCom::get_ServiceType */ ,
    (void *) (INT_PTR) -1 /* ISubmitSMCom::put_ServiceType */ ,
    (void *) (INT_PTR) -1 /* ISubmitSMCom::get_Source */ ,
    (void *) (INT_PTR) -1 /* ISubmitSMCom::put_Source */ ,
    (void *) (INT_PTR) -1 /* ISubmitSMCom::get_Destination */ ,
    (void *) (INT_PTR) -1 /* ISubmitSMCom::put_Destination */ ,
    (void *) (INT_PTR) -1 /* ISubmitSMCom::get_esmClass */ ,
    (void *) (INT_PTR) -1 /* ISubmitSMCom::put_esmClass */ ,
    (void *) (INT_PTR) -1 /* ISubmitSMCom::get_dataCoding */ ,
    (void *) (INT_PTR) -1 /* ISubmitSMCom::put_dataCoding */ ,
    (void *) (INT_PTR) -1 /* ISubmitSMCom::get_protocolID */ ,
    (void *) (INT_PTR) -1 /* ISubmitSMCom::put_protocolID */ ,
    (void *) (INT_PTR) -1 /* ISubmitSMCom::get_priorityFlag */ ,
    (void *) (INT_PTR) -1 /* ISubmitSMCom::put_priorityFlag */ ,
    (void *) (INT_PTR) -1 /* ISubmitSMCom::get_scheduledDelivery */ ,
    (void *) (INT_PTR) -1 /* ISubmitSMCom::put_scheduledDelivery */ ,
    (void *) (INT_PTR) -1 /* ISubmitSMCom::get_validityPeriod */ ,
    (void *) (INT_PTR) -1 /* ISubmitSMCom::put_validityPeriod */ ,
    (void *) (INT_PTR) -1 /* ISubmitSMCom::get_registeredDelivery */ ,
    (void *) (INT_PTR) -1 /* ISubmitSMCom::put_registeredDelivery */ ,
    (void *) (INT_PTR) -1 /* ISubmitSMCom::get_replaceIfPresent */ ,
    (void *) (INT_PTR) -1 /* ISubmitSMCom::put_replaceIfPresent */ ,
    (void *) (INT_PTR) -1 /* ISubmitSMCom::get_smDefaultMsgId */ ,
    (void *) (INT_PTR) -1 /* ISubmitSMCom::put_smDefaultMsgId */ ,
    (void *) (INT_PTR) -1 /* ISubmitSMCom::get_Message */ ,
    (void *) (INT_PTR) -1 /* ISubmitSMCom::put_Message */ ,
    (void *) (INT_PTR) -1 /* ISubmitSMCom::compactMessage */ ,
    (void *) (INT_PTR) -1 /* ISubmitSMCom::flipByteOrder */ ,
    (void *) (INT_PTR) -1 /* ISubmitSMCom::setMessage */ ,
    (void *) (INT_PTR) -1 /* ISubmitSMCom::getMessage */
};


static const PRPC_STUB_FUNCTION ISubmitSMCom_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _ISubmitSMComStubVtbl =
{
    &IID_ISubmitSMCom,
    &ISubmitSMCom_ServerInfo,
    37,
    &ISubmitSMCom_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: IEsmeTransmitterCom, ver. 0.0,
   GUID={0x3C9111B7,0xD010,0x48E6,{0x9A,0xA6,0x33,0x59,0x99,0x87,0x48,0x1F}} */

#pragma code_seg(".orpc")
static const unsigned short IEsmeTransmitterCom_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    1074,
    1126,
    134,
    1154,
    1188,
    1210,
    1238
    };

static const MIDL_STUBLESS_PROXY_INFO IEsmeTransmitterCom_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &IEsmeTransmitterCom_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO IEsmeTransmitterCom_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &IEsmeTransmitterCom_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(14) _IEsmeTransmitterComProxyVtbl = 
{
    &IEsmeTransmitterCom_ProxyInfo,
    &IID_IEsmeTransmitterCom,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *) (INT_PTR) -1 /* IEsmeTransmitterCom::bind */ ,
    (void *) (INT_PTR) -1 /* IEsmeTransmitterCom::unbind */ ,
    (void *) (INT_PTR) -1 /* IEsmeTransmitterCom::enquireLink */ ,
    (void *) (INT_PTR) -1 /* IEsmeTransmitterCom::init */ ,
    (void *) (INT_PTR) -1 /* IEsmeTransmitterCom::close */ ,
    (void *) (INT_PTR) -1 /* IEsmeTransmitterCom::get_Connected */ ,
    (void *) (INT_PTR) -1 /* IEsmeTransmitterCom::submitMessage */
};


static const PRPC_STUB_FUNCTION IEsmeTransmitterCom_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _IEsmeTransmitterComStubVtbl =
{
    &IID_IEsmeTransmitterCom,
    &IEsmeTransmitterCom_ServerInfo,
    14,
    &IEsmeTransmitterCom_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: IDeliverSMCom, ver. 0.0,
   GUID={0x2DB76F63,0x43CA,0x4610,{0xBF,0xD0,0x3C,0xE8,0x85,0xD6,0x07,0x8B}} */

#pragma code_seg(".orpc")
static const unsigned short IDeliverSMCom_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    246,
    274,
    302,
    330,
    358,
    386,
    414,
    442,
    470,
    498,
    526,
    554,
    582,
    610,
    638,
    666,
    694,
    722,
    750,
    778,
    806,
    834,
    862,
    890,
    918,
    946,
    974,
    996,
    1018,
    1046
    };

static const MIDL_STUBLESS_PROXY_INFO IDeliverSMCom_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &IDeliverSMCom_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO IDeliverSMCom_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &IDeliverSMCom_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(37) _IDeliverSMComProxyVtbl = 
{
    &IDeliverSMCom_ProxyInfo,
    &IID_IDeliverSMCom,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *) (INT_PTR) -1 /* IDeliverSMCom::get_ServiceType */ ,
    (void *) (INT_PTR) -1 /* IDeliverSMCom::put_ServiceType */ ,
    (void *) (INT_PTR) -1 /* IDeliverSMCom::get_Source */ ,
    (void *) (INT_PTR) -1 /* IDeliverSMCom::put_Source */ ,
    (void *) (INT_PTR) -1 /* IDeliverSMCom::get_Destination */ ,
    (void *) (INT_PTR) -1 /* IDeliverSMCom::put_Destination */ ,
    (void *) (INT_PTR) -1 /* IDeliverSMCom::get_esmClass */ ,
    (void *) (INT_PTR) -1 /* IDeliverSMCom::put_esmClass */ ,
    (void *) (INT_PTR) -1 /* IDeliverSMCom::get_dataCoding */ ,
    (void *) (INT_PTR) -1 /* IDeliverSMCom::put_dataCoding */ ,
    (void *) (INT_PTR) -1 /* IDeliverSMCom::get_protocolID */ ,
    (void *) (INT_PTR) -1 /* IDeliverSMCom::put_protocolID */ ,
    (void *) (INT_PTR) -1 /* IDeliverSMCom::get_priorityFlag */ ,
    (void *) (INT_PTR) -1 /* IDeliverSMCom::put_priorityFlag */ ,
    (void *) (INT_PTR) -1 /* IDeliverSMCom::get_scheduledDelivery */ ,
    (void *) (INT_PTR) -1 /* IDeliverSMCom::put_scheduledDelivery */ ,
    (void *) (INT_PTR) -1 /* IDeliverSMCom::get_validityPeriod */ ,
    (void *) (INT_PTR) -1 /* IDeliverSMCom::put_validityPeriod */ ,
    (void *) (INT_PTR) -1 /* IDeliverSMCom::get_registeredDelivery */ ,
    (void *) (INT_PTR) -1 /* IDeliverSMCom::put_registeredDelivery */ ,
    (void *) (INT_PTR) -1 /* IDeliverSMCom::get_replaceIfPresent */ ,
    (void *) (INT_PTR) -1 /* IDeliverSMCom::put_replaceIfPresent */ ,
    (void *) (INT_PTR) -1 /* IDeliverSMCom::get_smDefaultMsgId */ ,
    (void *) (INT_PTR) -1 /* IDeliverSMCom::put_smDefaultMsgId */ ,
    (void *) (INT_PTR) -1 /* IDeliverSMCom::get_Message */ ,
    (void *) (INT_PTR) -1 /* IDeliverSMCom::put_Message */ ,
    (void *) (INT_PTR) -1 /* IDeliverSMCom::compactMessage */ ,
    (void *) (INT_PTR) -1 /* IDeliverSMCom::flipByteOrder */ ,
    (void *) (INT_PTR) -1 /* IDeliverSMCom::setMessage */ ,
    (void *) (INT_PTR) -1 /* IDeliverSMCom::getMessage */
};


static const PRPC_STUB_FUNCTION IDeliverSMCom_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _IDeliverSMComStubVtbl =
{
    &IID_IDeliverSMCom,
    &IDeliverSMCom_ServerInfo,
    37,
    &IDeliverSMCom_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: IEsmeTransceiverCom, ver. 0.0,
   GUID={0xC258AF14,0x8CEF,0x404F,{0xBE,0x03,0x62,0xB6,0xC5,0x7F,0x60,0x26}} */

#pragma code_seg(".orpc")
static const unsigned short IEsmeTransceiverCom_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    1074,
    1126,
    134,
    1154,
    1188,
    1210,
    1238
    };

static const MIDL_STUBLESS_PROXY_INFO IEsmeTransceiverCom_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &IEsmeTransceiverCom_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO IEsmeTransceiverCom_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &IEsmeTransceiverCom_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(14) _IEsmeTransceiverComProxyVtbl = 
{
    &IEsmeTransceiverCom_ProxyInfo,
    &IID_IEsmeTransceiverCom,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *) (INT_PTR) -1 /* IEsmeTransceiverCom::bind */ ,
    (void *) (INT_PTR) -1 /* IEsmeTransceiverCom::unbind */ ,
    (void *) (INT_PTR) -1 /* IEsmeTransceiverCom::enquireLink */ ,
    (void *) (INT_PTR) -1 /* IEsmeTransceiverCom::init */ ,
    (void *) (INT_PTR) -1 /* IEsmeTransceiverCom::close */ ,
    (void *) (INT_PTR) -1 /* IEsmeTransceiverCom::get_Connected */ ,
    (void *) (INT_PTR) -1 /* IEsmeTransceiverCom::submitMessage */
};


static const PRPC_STUB_FUNCTION IEsmeTransceiverCom_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _IEsmeTransceiverComStubVtbl =
{
    &IID_IEsmeTransceiverCom,
    &IEsmeTransceiverCom_ServerInfo,
    14,
    &IEsmeTransceiverCom_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};


/* Object interface: IEsmeReceiverCom, ver. 0.0,
   GUID={0x57E38123,0x98A1,0x4219,{0x8C,0xB6,0xEF,0x45,0xA5,0x42,0x82,0x38}} */

#pragma code_seg(".orpc")
static const unsigned short IEsmeReceiverCom_FormatStringOffsetTable[] =
    {
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    (unsigned short) -1,
    1074,
    1126,
    134,
    1154,
    1188,
    1210
    };

static const MIDL_STUBLESS_PROXY_INFO IEsmeReceiverCom_ProxyInfo =
    {
    &Object_StubDesc,
    __MIDL_ProcFormatString.Format,
    &IEsmeReceiverCom_FormatStringOffsetTable[-3],
    0,
    0,
    0
    };


static const MIDL_SERVER_INFO IEsmeReceiverCom_ServerInfo = 
    {
    &Object_StubDesc,
    0,
    __MIDL_ProcFormatString.Format,
    &IEsmeReceiverCom_FormatStringOffsetTable[-3],
    0,
    0,
    0,
    0};
CINTERFACE_PROXY_VTABLE(13) _IEsmeReceiverComProxyVtbl = 
{
    &IEsmeReceiverCom_ProxyInfo,
    &IID_IEsmeReceiverCom,
    IUnknown_QueryInterface_Proxy,
    IUnknown_AddRef_Proxy,
    IUnknown_Release_Proxy ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfoCount */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetTypeInfo */ ,
    0 /* (void *) (INT_PTR) -1 /* IDispatch::GetIDsOfNames */ ,
    0 /* IDispatch_Invoke_Proxy */ ,
    (void *) (INT_PTR) -1 /* IEsmeReceiverCom::bind */ ,
    (void *) (INT_PTR) -1 /* IEsmeReceiverCom::unbind */ ,
    (void *) (INT_PTR) -1 /* IEsmeReceiverCom::enquireLink */ ,
    (void *) (INT_PTR) -1 /* IEsmeReceiverCom::init */ ,
    (void *) (INT_PTR) -1 /* IEsmeReceiverCom::close */ ,
    (void *) (INT_PTR) -1 /* IEsmeReceiverCom::get_Connected */
};


static const PRPC_STUB_FUNCTION IEsmeReceiverCom_table[] =
{
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    STUB_FORWARDING_FUNCTION,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2,
    NdrStubCall2
};

CInterfaceStubVtbl _IEsmeReceiverComStubVtbl =
{
    &IID_IEsmeReceiverCom,
    &IEsmeReceiverCom_ServerInfo,
    13,
    &IEsmeReceiverCom_table[-3],
    CStdStubBuffer_DELEGATING_METHODS
};

static const MIDL_STUB_DESC Object_StubDesc = 
    {
    0,
    NdrOleAllocate,
    NdrOleFree,
    0,
    0,
    0,
    0,
    0,
    __MIDL_TypeFormatString.Format,
    1, /* -error bounds_check flag */
    0x20000, /* Ndr library version */
    0,
    0x600015b, /* MIDL Version 6.0.347 */
    0,
    UserMarshalRoutines,
    0,  /* notify & notify_flag routine table */
    0x1, /* MIDL flag */
    0, /* cs routines */
    0,   /* proxy/server info */
    0   /* Reserved5 */
    };

const CInterfaceProxyVtbl * _SMPPCOM_ProxyVtblList[] = 
{
    ( CInterfaceProxyVtbl *) &_ISmppAddressComProxyVtbl,
    ( CInterfaceProxyVtbl *) &_ISmppDateComProxyVtbl,
    ( CInterfaceProxyVtbl *) &_IEsmeTransceiverComProxyVtbl,
    ( CInterfaceProxyVtbl *) &_IEsmeReceiverComProxyVtbl,
    ( CInterfaceProxyVtbl *) &_ISubmitSMComProxyVtbl,
    ( CInterfaceProxyVtbl *) &_IDeliverSMComProxyVtbl,
    ( CInterfaceProxyVtbl *) &_IEsmeTransmitterComProxyVtbl,
    0
};

const CInterfaceStubVtbl * _SMPPCOM_StubVtblList[] = 
{
    ( CInterfaceStubVtbl *) &_ISmppAddressComStubVtbl,
    ( CInterfaceStubVtbl *) &_ISmppDateComStubVtbl,
    ( CInterfaceStubVtbl *) &_IEsmeTransceiverComStubVtbl,
    ( CInterfaceStubVtbl *) &_IEsmeReceiverComStubVtbl,
    ( CInterfaceStubVtbl *) &_ISubmitSMComStubVtbl,
    ( CInterfaceStubVtbl *) &_IDeliverSMComStubVtbl,
    ( CInterfaceStubVtbl *) &_IEsmeTransmitterComStubVtbl,
    0
};

PCInterfaceName const _SMPPCOM_InterfaceNamesList[] = 
{
    "ISmppAddressCom",
    "ISmppDateCom",
    "IEsmeTransceiverCom",
    "IEsmeReceiverCom",
    "ISubmitSMCom",
    "IDeliverSMCom",
    "IEsmeTransmitterCom",
    0
};

const IID *  _SMPPCOM_BaseIIDList[] = 
{
    &IID_IDispatch,
    &IID_IDispatch,
    &IID_IDispatch,
    &IID_IDispatch,
    &IID_IDispatch,
    &IID_IDispatch,
    &IID_IDispatch,
    0
};


#define _SMPPCOM_CHECK_IID(n)	IID_GENERIC_CHECK_IID( _SMPPCOM, pIID, n)

int __stdcall _SMPPCOM_IID_Lookup( const IID * pIID, int * pIndex )
{
    IID_BS_LOOKUP_SETUP

    IID_BS_LOOKUP_INITIAL_TEST( _SMPPCOM, 7, 4 )
    IID_BS_LOOKUP_NEXT_TEST( _SMPPCOM, 2 )
    IID_BS_LOOKUP_NEXT_TEST( _SMPPCOM, 1 )
    IID_BS_LOOKUP_RETURN_RESULT( _SMPPCOM, 7, *pIndex )
    
}

const ExtendedProxyFileInfo SMPPCOM_ProxyFileInfo = 
{
    (PCInterfaceProxyVtblList *) & _SMPPCOM_ProxyVtblList,
    (PCInterfaceStubVtblList *) & _SMPPCOM_StubVtblList,
    (const PCInterfaceName * ) & _SMPPCOM_InterfaceNamesList,
    (const IID ** ) & _SMPPCOM_BaseIIDList,
    & _SMPPCOM_IID_Lookup, 
    7,
    2,
    0, /* table of [async_uuid] interfaces */
    0, /* Filler1 */
    0, /* Filler2 */
    0  /* Filler3 */
};


#endif /* !defined(_M_IA64) && !defined(_M_AMD64)*/

