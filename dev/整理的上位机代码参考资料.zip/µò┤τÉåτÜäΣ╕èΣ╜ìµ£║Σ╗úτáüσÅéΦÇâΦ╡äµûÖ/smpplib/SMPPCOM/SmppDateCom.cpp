// SmppDateCom.cpp : Implementation of CSmppDateCom

#include "stdafx.h"
#include "SmppDateCom.h"

#include "comutil.h"

// CSmppDateCom


STDMETHODIMP CSmppDateCom::isNull(VARIANT_BOOL *valnull)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here
	*valnull = CSmppDate::isNull();

	return S_OK;
}

STDMETHODIMP CSmppDateCom::setNull(void)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here
	CSmppDate::setNull();

	return S_OK;
}

STDMETHODIMP CSmppDateCom::toString(BSTR *strdate)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here
   try
   {
		*strdate = CSmppDate::toString().AllocSysString();
   }
   catch (...)
   {
	   return E_OUTOFMEMORY;
   }

	return S_OK;
}

STDMETHODIMP CSmppDateCom::setDate(BSTR strdate)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	USES_CONVERSION;

	LPSTR sdt = OLE2A(strdate);
	CSmppDate::setDate(sdt);

	return S_OK;
}
