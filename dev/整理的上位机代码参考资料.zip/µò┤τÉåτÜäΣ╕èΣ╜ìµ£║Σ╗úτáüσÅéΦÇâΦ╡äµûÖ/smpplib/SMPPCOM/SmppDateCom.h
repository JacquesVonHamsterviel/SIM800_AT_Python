// SmppDateCom.h : Declaration of the CSmppDateCom

#pragma once
#include "resource.h"       // main symbols

#include "SMPPCOM.h"

#include "..\smpppacket.h"

// CSmppDateCom

class ATL_NO_VTABLE CSmppDateCom : public CSmppDate,
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CSmppDateCom, &CLSID_SmppDateCom>,
	public IDispatchImpl<ISmppDateCom, &IID_ISmppDateCom, &LIBID_SMPPCOMLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
public:
	CSmppDateCom()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_SMPPDATECOM)

DECLARE_NOT_AGGREGATABLE(CSmppDateCom)

BEGIN_COM_MAP(CSmppDateCom)
	COM_INTERFACE_ENTRY(ISmppDateCom)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()


	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}
	
	void FinalRelease() 
	{
	}

public:

	STDMETHOD(isNull)(VARIANT_BOOL *valnull);
	STDMETHOD(setNull)(void);
	STDMETHOD(toString)(BSTR *strdate);

	STDMETHOD(setDate)(BSTR strdate);

};

OBJECT_ENTRY_AUTO(__uuidof(SmppDateCom), CSmppDateCom)
