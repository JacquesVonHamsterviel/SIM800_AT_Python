// EsmeReceiverCom.h : Declaration of the CEsmeReceiverCom

#pragma once
#include "resource.h"       // main symbols

#include "SMPPCOM.h"
#include "_IEsmeReceiverComEvents_CP.h"

#include "..\smpppacket.h"
#include "..\EsmeReceiver.h"

// CEsmeReceiverCom

class ATL_NO_VTABLE CEsmeReceiverCom : public CEsmeReceiver,
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CEsmeReceiverCom, &CLSID_EsmeReceiverCom>,
	public IConnectionPointContainerImpl<CEsmeReceiverCom>,
	public CProxy_IEsmeReceiverComEvents<CEsmeReceiverCom>, 
	public IDispatchImpl<IEsmeReceiverCom, &IID_IEsmeReceiverCom, &LIBID_SMPPCOMLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
public:
	CEsmeReceiverCom()
	{
		m_response_event = CreateEvent(NULL, TRUE, FALSE, NULL);
		InitializeCriticalSection(&m_cs);

		//register callback handle function to processing receiving packets
		registerProcessPacket(processPacketProc, this);
	}

	~CEsmeReceiverCom()
	{
		CloseHandle(m_response_event);
		DeleteCriticalSection(&m_cs);
	}

DECLARE_REGISTRY_RESOURCEID(IDR_ESMERECEIVERCOM)

DECLARE_NOT_AGGREGATABLE(CEsmeReceiverCom)

BEGIN_COM_MAP(CEsmeReceiverCom)
	COM_INTERFACE_ENTRY(IEsmeReceiverCom)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IConnectionPointContainer)
END_COM_MAP()

BEGIN_CONNECTION_POINT_MAP(CEsmeReceiverCom)
	CONNECTION_POINT_ENTRY(__uuidof(_IEsmeReceiverComEvents))
END_CONNECTION_POINT_MAP()

	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}
	
	void FinalRelease() 
	{
	}

public:

	STDMETHOD(bind)(BSTR sysid, BSTR passwd, BSTR systype, ISmppAddressCom* iaddr, VARIANT_BOOL* pret);
	STDMETHOD(unbind)(VARIANT_BOOL* pret);
	STDMETHOD(enquireLink)(VARIANT_BOOL* pret);
	STDMETHOD(init)(BSTR svrip, LONG port);
	STDMETHOD(close)(void);
	STDMETHOD(get_Connected)(VARIANT_BOOL* pVal);

protected:
	static void __stdcall processPacketProc(CPacketBase *pak, LPVOID param);
	void processPacket(CPacketBase *pak);
	void NotifyClientDeliverSM(CDeliverSM *pak);

protected:

	HANDLE m_response_event;		//set when a response is got

	bool m_last_error;			//last command has error

	CRITICAL_SECTION m_cs;

};

OBJECT_ENTRY_AUTO(__uuidof(EsmeReceiverCom), CEsmeReceiverCom)
