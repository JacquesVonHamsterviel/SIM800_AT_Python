// SmppAddressCom.h : Declaration of the CSmppAddressCom

#pragma once
#include "resource.h"       // main symbols

#include "SMPPCOM.h"

#include "..\smpppacket.h"

// CSmppAddressCom

class ATL_NO_VTABLE CSmppAddressCom : public CSmppAddress,
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CSmppAddressCom, &CLSID_SmppAddressCom>,
	public IDispatchImpl<ISmppAddressCom, &IID_ISmppAddressCom, &LIBID_SMPPCOMLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
public:
	CSmppAddressCom()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_SMPPADDRESSCOM)

DECLARE_NOT_AGGREGATABLE(CSmppAddressCom)

BEGIN_COM_MAP(CSmppAddressCom)
	COM_INTERFACE_ENTRY(ISmppAddressCom)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()


	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}
	
	void FinalRelease() 
	{
	}

public:

	STDMETHOD(get_TON)(SHORT* pVal);
	STDMETHOD(put_TON)(SHORT newVal);
	STDMETHOD(get_NPI)(SHORT* pVal);
	STDMETHOD(put_NPI)(SHORT newVal);
	STDMETHOD(get_Address)(BSTR* pVal);
	STDMETHOD(put_Address)(BSTR newVal);
};

OBJECT_ENTRY_AUTO(__uuidof(SmppAddressCom), CSmppAddressCom)
