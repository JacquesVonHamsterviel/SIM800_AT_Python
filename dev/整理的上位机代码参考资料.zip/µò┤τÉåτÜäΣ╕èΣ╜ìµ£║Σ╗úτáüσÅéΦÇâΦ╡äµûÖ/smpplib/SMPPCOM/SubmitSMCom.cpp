// SubmitSMCom.cpp : Implementation of CSubmitSMCom

#include "stdafx.h"
#include "SubmitSMCom.h"

// CSubmitSMCom


STDMETHODIMP CSubmitSMCom::get_ServiceType(BSTR* pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here
	try
	{
		*pVal = m_service_type.AllocSysString();
	}
	catch (...)
	{
		return E_OUTOFMEMORY;
	}

	return S_OK;
}

STDMETHODIMP CSubmitSMCom::put_ServiceType(BSTR newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	USES_CONVERSION;

	LPSTR stype = OLE2A(newVal);
	m_service_type = stype;

	return S_OK;
}

STDMETHODIMP CSubmitSMCom::get_Source(ISmppAddressCom** pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here
	
	//create an CSmppAddressCom instance to return
	CoCreateInstance(	CLSID_SmppAddressCom,
						NULL,
						CLSCTX_ALL,
						IID_ISmppAddressCom,
						(void **) pVal);

	//sets the values
	(*pVal)->put_TON(m_source.m_addr_ton);
	(*pVal)->put_NPI(m_source.m_addr_npi);
	(*pVal)->put_Address(m_source.m_addr.AllocSysString());

	return S_OK;
}

STDMETHODIMP CSubmitSMCom::put_Source(ISmppAddressCom* newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here
	SHORT npi;
	SHORT ton;
	BSTR addr;

	newVal->get_NPI(&npi);
	newVal->get_TON(&ton);
	newVal->get_Address(&addr);

	m_source.m_addr_ton = ton;
	m_source.m_addr_npi = npi;

	USES_CONVERSION;

	LPSTR paddr = OLE2A(addr);
	m_source.m_addr = paddr;

	//clearing up
	SysFreeString(addr);

	return S_OK;
}

STDMETHODIMP CSubmitSMCom::get_Destination(ISmppAddressCom** pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	//create an CSmppAddressCom instance to return
	CoCreateInstance(	CLSID_SmppAddressCom,
						NULL,
						CLSCTX_ALL,
						IID_ISmppAddressCom,
						(void **) pVal);

	//sets the values
	(*pVal)->put_TON(m_destination.m_addr_ton);
	(*pVal)->put_NPI(m_destination.m_addr_npi);
	(*pVal)->put_Address(m_destination.m_addr.AllocSysString());

	return S_OK;
}

STDMETHODIMP CSubmitSMCom::put_Destination(ISmppAddressCom* newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here
	SHORT npi;
	SHORT ton;
	BSTR addr;

	newVal->get_NPI(&npi);
	newVal->get_TON(&ton);
	newVal->get_Address(&addr);

	m_destination.m_addr_ton = ton;
	m_destination.m_addr_npi = npi;

	USES_CONVERSION;

	LPSTR paddr = OLE2A(addr);
	m_destination.m_addr = paddr;

	//clearing up
	SysFreeString(addr);

	return S_OK;
}

STDMETHODIMP CSubmitSMCom::get_esmClass(SHORT* pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	*pVal = m_esm_class;

	return S_OK;
}

STDMETHODIMP CSubmitSMCom::put_esmClass(SHORT newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	m_esm_class = newVal;

	return S_OK;
}

STDMETHODIMP CSubmitSMCom::get_dataCoding(SHORT* pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	*pVal = m_data_coding;

	return S_OK;
}

STDMETHODIMP CSubmitSMCom::put_dataCoding(SHORT newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	m_data_coding = newVal;

	return S_OK;
}

STDMETHODIMP CSubmitSMCom::get_protocolID(SHORT* pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	*pVal = m_protocol_id;

	return S_OK;
}

STDMETHODIMP CSubmitSMCom::put_protocolID(SHORT newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	m_protocol_id = newVal;

	return S_OK;
}

STDMETHODIMP CSubmitSMCom::get_priorityFlag(SHORT* pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	*pVal = m_priority_flag;

	return S_OK;
}

STDMETHODIMP CSubmitSMCom::put_priorityFlag(SHORT newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	m_priority_flag = newVal;

	return S_OK;
}

STDMETHODIMP CSubmitSMCom::get_scheduledDelivery(ISmppDateCom** pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	//create an CSmppDateCom instance to return
	CoCreateInstance(	CLSID_SmppDateCom,
						NULL,
						CLSCTX_ALL,
						IID_ISmppDateCom,
						(void **) pVal);

	//sets the values
	BSTR bstrdt = m_scheduled_delivery.toString().AllocSysString();
	(*pVal)->setDate(bstrdt);
	SysFreeString(bstrdt);

	return S_OK;
}

STDMETHODIMP CSubmitSMCom::put_scheduledDelivery(ISmppDateCom* newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	BSTR strdt;

	newVal->toString(&strdt);

	USES_CONVERSION;
	LPSTR sdt = OLE2A(strdt);
	m_scheduled_delivery.setDate(sdt);

	//cleaning
	SysFreeString(strdt);

	return S_OK;
}

STDMETHODIMP CSubmitSMCom::get_validityPeriod(ISmppDateCom** pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	//create an CSmppDateCom instance to return
	CoCreateInstance(	CLSID_SmppDateCom,
						NULL,
						CLSCTX_ALL,
						IID_ISmppDateCom,
						(void **) pVal);

	//sets the values
	BSTR bstrdt = m_validity_period.toString().AllocSysString();
	(*pVal)->setDate(bstrdt);
	SysFreeString(bstrdt);

	return S_OK;
}

STDMETHODIMP CSubmitSMCom::put_validityPeriod(ISmppDateCom* newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	BSTR strdt;

	newVal->toString(&strdt);

	USES_CONVERSION;
	LPSTR sdt = OLE2A(strdt);
	m_validity_period.setDate(sdt);

	//cleaning
	SysFreeString(strdt);

	return S_OK;
}

STDMETHODIMP CSubmitSMCom::get_registeredDelivery(SHORT* pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	*pVal = m_registered_delivery;

	return S_OK;
}

STDMETHODIMP CSubmitSMCom::put_registeredDelivery(SHORT newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	m_registered_delivery = newVal;

	return S_OK;
}

STDMETHODIMP CSubmitSMCom::get_replaceIfPresent(SHORT* pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	*pVal = m_replace_if_present;

	return S_OK;
}

STDMETHODIMP CSubmitSMCom::put_replaceIfPresent(SHORT newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	m_replace_if_present = newVal;

	return S_OK;
}

STDMETHODIMP CSubmitSMCom::get_smDefaultMsgId(SHORT* pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	*pVal = m_sm_default_msg_id;

	return S_OK;
}

STDMETHODIMP CSubmitSMCom::put_smDefaultMsgId(SHORT newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	m_sm_default_msg_id = newVal;

	return S_OK;
}


STDMETHODIMP CSubmitSMCom::get_Message(BSTR* pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	UINT char_len;

	if (m_msg_double_byte)
	{
		char_len = m_sm_length/2;

		*pVal = SysAllocStringLen((OLECHAR *) m_message, char_len);
	}
	else
	{
		USES_CONVERSION;

		char_len = m_sm_length;
		*pVal = SysAllocStringLen(A2W((LPCSTR) m_message), char_len);
	}
	return S_OK;
}

STDMETHODIMP CSubmitSMCom::put_Message(BSTR newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	//double byte characters
	m_sm_length = SysStringLen(newVal) * 2;
	m_msg_double_byte = true;

	CSubmitSM::setMessage((PBYTE) newVal, m_sm_length);

	return S_OK;
}
STDMETHODIMP CSubmitSMCom::compactMessage(void)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	if (m_msg_double_byte)
	{
		USES_CONVERSION;

		LPCSTR pstr = W2A((OLECHAR *) m_message);
		UINT len = m_sm_length/2;

		CSubmitSM::setMessage((PBYTE) pstr, len);
		m_msg_double_byte = false;
	}

	return S_OK;
}

STDMETHODIMP CSubmitSMCom::flipByteOrder(void)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	int i = 2;
	BYTE tmpby;
	while (i <= m_sm_length)
	{
		tmpby = m_message[i-2];
		m_message[i-2] = m_message[i-1];
		m_message[i-1] = tmpby;

		i+=2;
	}

	return S_OK;
}

STDMETHODIMP CSubmitSMCom::setMessage(VARIANT msgdata)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	if ((msgdata.vt & VT_ARRAY) == 0)
		return E_INVALIDARG;
	if ((msgdata.vt & VT_UI1) == 0)
		return E_INVALIDARG;

	SAFEARRAY *psa = msgdata.parray;
	BYTE *padata;

	SafeArrayAccessData(psa, (void **) &padata);

	//only one directly, no of element is the data length
	int nsize = psa->rgsabound->cElements;
	CSubmitSM::setMessage(padata, nsize);

	SafeArrayUnaccessData(psa);

	return S_OK;
}

STDMETHODIMP CSubmitSMCom::getMessage(VARIANT* pmsgdata)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	VariantInit(pmsgdata);
	pmsgdata->vt = VT_ARRAY | VT_UI1;
	SAFEARRAY *psa;
	SAFEARRAYBOUND bounds = {m_sm_length, 0};
	psa = SafeArrayCreate(VT_UI1, 1, &bounds);
	BYTE *padata;
	SafeArrayAccessData(psa, (void **) &padata);
	memcpy(padata, m_message, m_sm_length);
	SafeArrayUnaccessData(psa);
	pmsgdata->parray = psa;

	return S_OK;
}
