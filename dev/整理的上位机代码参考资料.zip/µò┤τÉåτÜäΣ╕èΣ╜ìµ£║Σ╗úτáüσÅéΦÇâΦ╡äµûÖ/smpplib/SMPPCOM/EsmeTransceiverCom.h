// EsmeTransceiverCom.h : Declaration of the CEsmeTransceiverCom

#pragma once
#include "resource.h"       // main symbols

#include "SMPPCOM.h"
#include "_IEsmeTransceiverComEvents_CP.h"

#include "..\smpppacket.h"
#include "..\EsmeTransceiver.h"

// CEsmeTransceiverCom

class ATL_NO_VTABLE CEsmeTransceiverCom : public CEsmeTransceiver,
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CEsmeTransceiverCom, &CLSID_EsmeTransceiverCom>,
	public IConnectionPointContainerImpl<CEsmeTransceiverCom>,
	public CProxy_IEsmeTransceiverComEvents<CEsmeTransceiverCom>, 
	public IDispatchImpl<IEsmeTransceiverCom, &IID_IEsmeTransceiverCom, &LIBID_SMPPCOMLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
public:
	CEsmeTransceiverCom()
	{
		m_last_msg_id = "";
		m_response_event = CreateEvent(NULL, TRUE, FALSE, NULL);
		InitializeCriticalSection(&m_cs);

		//register callback handle function to processing receiving packets
		registerProcessPacket(processPacketProc, this);
	}

	~CEsmeTransceiverCom()
	{
		CloseHandle(m_response_event);
		DeleteCriticalSection(&m_cs);
	}

DECLARE_REGISTRY_RESOURCEID(IDR_ESMETRANSCEIVERCOM)

DECLARE_NOT_AGGREGATABLE(CEsmeTransceiverCom)

BEGIN_COM_MAP(CEsmeTransceiverCom)
	COM_INTERFACE_ENTRY(IEsmeTransceiverCom)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IConnectionPointContainer)
END_COM_MAP()

BEGIN_CONNECTION_POINT_MAP(CEsmeTransceiverCom)
	CONNECTION_POINT_ENTRY(__uuidof(_IEsmeTransceiverComEvents))
END_CONNECTION_POINT_MAP()

	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}
	
	void FinalRelease() 
	{
	}

public:

	STDMETHOD(bind)(BSTR sysid, BSTR passwd, BSTR systype, ISmppAddressCom* iaddr, VARIANT_BOOL* pret);
	STDMETHOD(unbind)(VARIANT_BOOL* pret);
	STDMETHOD(enquireLink)(VARIANT_BOOL* pret);
	STDMETHOD(init)(BSTR svrip, LONG port);
	STDMETHOD(close)(void);
	STDMETHOD(get_Connected)(VARIANT_BOOL* pVal);
	STDMETHOD(submitMessage)(ISubmitSMCom* isubmit, BSTR* pMsgid, VARIANT_BOOL* pret);


protected:
	static void __stdcall processPacketProc(CPacketBase *pak, LPVOID param);
	void processPacket(CPacketBase *pak);
	void NotifyClientDeliverSM(CDeliverSM *pak);

protected:

	HANDLE m_response_event;		//set when a response is got

	CString m_last_msg_id;		//responsed msg id for last submit message

	bool m_last_error;			//last command has error

	CRITICAL_SECTION m_cs;

};

OBJECT_ENTRY_AUTO(__uuidof(EsmeTransceiverCom), CEsmeTransceiverCom)
