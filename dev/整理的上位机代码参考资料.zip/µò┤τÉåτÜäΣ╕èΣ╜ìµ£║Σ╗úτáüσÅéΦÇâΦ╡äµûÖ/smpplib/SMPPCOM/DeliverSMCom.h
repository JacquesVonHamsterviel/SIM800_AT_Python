// DeliverSMCom.h : Declaration of the CDeliverSMCom

#pragma once
#include "resource.h"       // main symbols

#include "SMPPCOM.h"

#include "..\smpppacket.h"

// CDeliverSMCom

class ATL_NO_VTABLE CDeliverSMCom : public CDeliverSM,
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CDeliverSMCom, &CLSID_DeliverSMCom>,
	public IDispatchImpl<IDeliverSMCom, &IID_IDeliverSMCom, &LIBID_SMPPCOMLib, /*wMajor =*/ 1, /*wMinor =*/ 0>
{
public:
	CDeliverSMCom()
	{
		m_msg_double_byte = false;
	}

DECLARE_REGISTRY_RESOURCEID(IDR_DELIVERSMCOM)

DECLARE_NOT_AGGREGATABLE(CDeliverSMCom)

BEGIN_COM_MAP(CDeliverSMCom)
	COM_INTERFACE_ENTRY(IDeliverSMCom)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()


	DECLARE_PROTECT_FINAL_CONSTRUCT()

	HRESULT FinalConstruct()
	{
		return S_OK;
	}
	
	void FinalRelease() 
	{
	}

public:

protected:
	bool m_msg_double_byte;
public:
	STDMETHOD(get_ServiceType)(BSTR* pVal);
	STDMETHOD(put_ServiceType)(BSTR newVal);
	STDMETHOD(get_Source)(ISmppAddressCom** pVal);
	STDMETHOD(put_Source)(ISmppAddressCom* newVal);
	STDMETHOD(get_Destination)(ISmppAddressCom** pVal);
	STDMETHOD(put_Destination)(ISmppAddressCom* newVal);
	STDMETHOD(get_esmClass)(SHORT* pVal);
	STDMETHOD(put_esmClass)(SHORT newVal);
	STDMETHOD(get_dataCoding)(SHORT* pVal);
	STDMETHOD(put_dataCoding)(SHORT newVal);
	STDMETHOD(get_protocolID)(SHORT* pVal);
	STDMETHOD(put_protocolID)(SHORT newVal);
	STDMETHOD(get_priorityFlag)(SHORT* pVal);
	STDMETHOD(put_priorityFlag)(SHORT newVal);
	STDMETHOD(get_scheduledDelivery)(ISmppDateCom** pVal);
	STDMETHOD(put_scheduledDelivery)(ISmppDateCom* newVal);
	STDMETHOD(get_validityPeriod)(ISmppDateCom** pVal);
	STDMETHOD(put_validityPeriod)(ISmppDateCom* newVal);
	STDMETHOD(get_registeredDelivery)(SHORT* pVal);
	STDMETHOD(put_registeredDelivery)(SHORT newVal);
	STDMETHOD(get_replaceIfPresent)(SHORT* pVal);
	STDMETHOD(put_replaceIfPresent)(SHORT newVal);
	STDMETHOD(get_smDefaultMsgId)(SHORT* pVal);
	STDMETHOD(put_smDefaultMsgId)(SHORT newVal);
	STDMETHOD(get_Message)(BSTR* pVal);
	STDMETHOD(put_Message)(BSTR newVal);
	STDMETHOD(compactMessage)(void);
	STDMETHOD(flipByteOrder)(void);
	STDMETHOD(setMessage)(VARIANT msgdata);
	STDMETHOD(getMessage)(VARIANT* pmsgdata);

};

OBJECT_ENTRY_AUTO(__uuidof(DeliverSMCom), CDeliverSMCom)
