// SmppAddressCom.cpp : Implementation of CSmppAddressCom

#include "stdafx.h"
#include "SmppAddressCom.h"


// CSmppAddressCom


STDMETHODIMP CSmppAddressCom::get_TON(SHORT* pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here
	*pVal = m_addr_ton;

	return S_OK;
}

STDMETHODIMP CSmppAddressCom::put_TON(SHORT newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here
	m_addr_ton = newVal;

	return S_OK;
}

STDMETHODIMP CSmppAddressCom::get_NPI(SHORT* pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here
	*pVal = m_addr_npi;

	return S_OK;
}

STDMETHODIMP CSmppAddressCom::put_NPI(SHORT newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here
	m_addr_npi = newVal;

	return S_OK;
}

STDMETHODIMP CSmppAddressCom::get_Address(BSTR* pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here
   try
   {
		*pVal = m_addr.AllocSysString();
   }
   catch (...)
   {
	   return E_OUTOFMEMORY;
   }


	return S_OK;
}

STDMETHODIMP CSmppAddressCom::put_Address(BSTR newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	USES_CONVERSION;

	LPSTR paddr = OLE2A(newVal);

	m_addr = paddr;

	return S_OK;
}
