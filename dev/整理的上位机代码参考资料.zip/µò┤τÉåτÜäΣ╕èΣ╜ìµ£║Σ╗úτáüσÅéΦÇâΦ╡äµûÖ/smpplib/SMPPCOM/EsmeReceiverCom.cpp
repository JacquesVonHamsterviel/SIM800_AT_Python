// EsmeReceiverCom.cpp : Implementation of CEsmeReceiverCom

#include "stdafx.h"
#include "EsmeReceiverCom.h"


// CEsmeReceiverCom

STDMETHODIMP CEsmeReceiverCom::bind(BSTR sysid, BSTR passwd, BSTR systype, ISmppAddressCom* iaddr, VARIANT_BOOL* pret)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here
	USES_CONVERSION;

	LPSTR sid, pwd, stype;

	sid = OLE2A(sysid);
	pwd = OLE2A(passwd);
	stype = OLE2A(systype);

	SHORT npi;
	SHORT ton;
	BSTR addr;

	iaddr->get_NPI(&npi);
	iaddr->get_TON(&ton);
	iaddr->get_Address(&addr);

	LPSTR paddr = OLE2A(addr);
	CSmppAddress srange(ton, npi, paddr);

	SysFreeString(addr);

	//setting finished, going to bind to SMSC

	EnterCriticalSection(&m_cs);				//enter m_cs

	ResetEvent(m_response_event);
	CEsmeReceiver::bind(sid, pwd, stype, srange);

	HANDLE hwait[] = {m_response_event, m_hDisconnectEvent, m_hKillEvent};

	DWORD ret = WaitForMultipleObjects(3, hwait, FALSE, 30000);

	if (ret == WAIT_OBJECT_0)
	{
		if (m_last_error)
			*pret = VARIANT_FALSE;
		else
			*pret = VARIANT_TRUE;
	}
	else
		*pret = VARIANT_FALSE;

	ResetEvent(m_response_event);

	LeaveCriticalSection(&m_cs);				//leave m_cs

	return S_OK;
}

STDMETHODIMP CEsmeReceiverCom::unbind(VARIANT_BOOL* pret)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	EnterCriticalSection(&m_cs);				//enter m_cs

	ResetEvent(m_response_event);
	CEsmeReceiver::unbind();

	HANDLE hwait[] = {m_response_event, m_hDisconnectEvent, m_hKillEvent};

	DWORD ret = WaitForMultipleObjects(3, hwait, FALSE, 30000);

	if (ret == WAIT_OBJECT_0)
	{
		if (m_last_error)
			*pret = VARIANT_FALSE;
		else
			*pret = VARIANT_TRUE;
	}
	else
		*pret = VARIANT_FALSE;

	ResetEvent(m_response_event);

	LeaveCriticalSection(&m_cs);				//leave m_cs

	return S_OK;
}

STDMETHODIMP CEsmeReceiverCom::enquireLink(VARIANT_BOOL* pret)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	EnterCriticalSection(&m_cs);				//enter m_cs

	ResetEvent(m_response_event);
	CEsmeReceiver::enquireLink();

	HANDLE hwait[] = {m_response_event, m_hDisconnectEvent, m_hKillEvent};

	DWORD ret = WaitForMultipleObjects(3, hwait, FALSE, 30000);

	if (ret == WAIT_OBJECT_0)
	{
		if (m_last_error)
			*pret = VARIANT_FALSE;
		else
			*pret = VARIANT_TRUE;
	}
	else
		*pret = VARIANT_FALSE;

	ResetEvent(m_response_event);

	LeaveCriticalSection(&m_cs);				//leave m_cs

	return S_OK;
}

STDMETHODIMP CEsmeReceiverCom::init(BSTR svrip, LONG port)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	USES_CONVERSION;

	LPSTR sip = OLE2A(svrip);

	CEsmeReceiver::init(sip, port);

	return S_OK;
}

STDMETHODIMP CEsmeReceiverCom::close(void)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here
	CEsmeReceiver::close();

	return S_OK;
}

STDMETHODIMP CEsmeReceiverCom::get_Connected(VARIANT_BOOL* pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	// TODO: Add your implementation code here

	if (CEsmeReceiver::isConnected())
	{
		*pVal = VARIANT_TRUE;
	}
	else
	{
		*pVal = VARIANT_FALSE;
	}

	return S_OK;
}


//registered callback to handle SMPP packets sent from SMSC
//(must be static class method or global procedure)
void __stdcall CEsmeReceiverCom::processPacketProc(CPacketBase *pak, LPVOID param)
{
	CEsmeReceiverCom *pRecv = (CEsmeReceiverCom *) param;

	//route to instance method, so it can access instance attributes
	pRecv->processPacket(pak);
}


//actuallly SMPP packets are in turns handled here 
void CEsmeReceiverCom::processPacket(CPacketBase *pak)
{

		switch (pak->getCommandId())
		{


			case SMPP_ENQUIRE_LINK:
			{
				//SMSC requested us to send querylink response

				CEnquireLink *pPak;
				pPak = static_cast<CEnquireLink *>(pak);

				//automatic reponse for enquery link
				CEnquireLinkResp elresp(*pPak);
				sendPacket(elresp);
				
			}
			break;

			case SMPP_DELIVER_SM:
			{
				//got a deliver SM
				CDeliverSM *pPak;
				pPak = static_cast<CDeliverSM *>(pak);

				//automatic response deliversm reponse
				CDeliverSMResp dresp (*pPak);
				sendPacket(dresp);

				//notify client for the deliver SM
				NotifyClientDeliverSM(pPak);
			}
			break;

			case SMPP_BIND_RECEIVER_RESP:
			{
				//bind receiver response

				CBindReceiverResp *pPak;
				pPak = static_cast<CBindReceiverResp *>(pak);

				if (pPak->getCommandStatus() == 0)
				{
					m_last_error = false;
				}
				else
				{
					m_last_error = true;
				}
				SetEvent(m_response_event);
			}
			break;

			
			case SMPP_UNBIND_RESP:
			{
				//unbind response

				CUnbindResp *pPak;
				pPak = static_cast<CUnbindResp *>(pak);

				if (pPak->getCommandStatus() == 0)
				{
					m_last_error = false;
				}
				else
				{
					m_last_error = true;
				}
				SetEvent(m_response_event);
			}
			break;


			case SMPP_ENQUIRE_LINK_RESP:
			{
				//Previous EnquireLink is responsed

				CEnquireLinkResp *pPak;
				pPak = static_cast<CEnquireLinkResp *>(pak);

				if (pPak->getCommandStatus() == 0)
				{
					m_last_error = false;
					SetEvent(m_response_event);
				}
				else
				{
					m_last_error = true;
				}
				SetEvent(m_response_event);
			}
			break;


			default:
				break;
		}
}

void CEsmeReceiverCom::NotifyClientDeliverSM(CDeliverSM *pak)
{
	IDeliverSMCom *pVal;

	//create an CDeliverSMCom instance to return
	CoCreateInstance(	CLSID_DeliverSMCom,
						NULL,
						CLSCTX_ALL,
						IID_IDeliverSMCom,
						(void **) &pVal);

	USES_CONVERSION;

	pVal->put_dataCoding(pak->getDataCoding());
	pVal->put_esmClass(pak->getEsmClass());
	pVal->put_replaceIfPresent(pak->getReplaceIfPresent());
	pVal->put_priorityFlag(pak->getPriorityFlag());
	pVal->put_protocolID(pak->getProtocolId());
	pVal->put_smDefaultMsgId(pak->getSmDefaultMsgId());
	pVal->put_registeredDelivery(pak->getRegisteredDelivery());


	//create an CSmppAddressCom for setting addresses
	ISmppAddressCom *iaddr;
	CoCreateInstance(	CLSID_SmppAddressCom,
						NULL,
						CLSCTX_ALL,
						IID_ISmppAddressCom,
						(void **) &iaddr);

	BSTR addrstr;

	//Setting source
	CSmppAddress source = pak->getSource();
	iaddr->put_TON(source.m_addr_ton);
	iaddr->put_NPI(source.m_addr_npi);
	addrstr = source.m_addr.AllocSysString();
	iaddr->put_Address(addrstr);
	SysFreeString(addrstr);

	pVal->put_Source(iaddr);

	//Setting Destination
	CSmppAddress destination = pak->getDestination();
	iaddr->put_TON(destination.m_addr_ton);
	iaddr->put_NPI(destination.m_addr_npi);
	addrstr = destination.m_addr.AllocSysString();
	iaddr->put_Address(addrstr);
	SysFreeString(addrstr);

	pVal->put_Destination(iaddr);

	iaddr->Release();


	//create an CSmppDate for setting dates
	ISmppDateCom *idate;
	CoCreateInstance(	CLSID_SmppDateCom,
						NULL,
						CLSCTX_ALL,
						IID_ISmppDateCom,
						(void **) &idate);
	
	BSTR strdate;

	//setting scheduleddelivery
	CSmppDate schdate = pak->getScheduledDelivery();
	strdate = schdate.toString().AllocSysString();
	idate->setDate(strdate);
	pVal->put_scheduledDelivery(idate);
	SysFreeString(strdate);

	//setting validityperiod
	CSmppDate vldprd = pak->getValidityPeriod();
	strdate = vldprd.toString().AllocSysString();
	idate->setDate(strdate);
	pVal->put_validityPeriod(idate);
	SysFreeString(strdate);

	idate->Release();

	//setting message
	PBYTE pdata;
	uint32 nsize;
	pak->getMessage(pdata, nsize);

	VARIANT var;

	VariantInit(&var);
	var.vt = VT_ARRAY | VT_UI1;
	SAFEARRAY *psa;
	SAFEARRAYBOUND bounds = {nsize, 0};
	psa = SafeArrayCreate(VT_UI1, 1, &bounds);
	BYTE *padata;
	SafeArrayAccessData(psa, (void **) &padata);
	memcpy(padata, pdata, nsize);
	SafeArrayUnaccessData(psa);
	var.parray = psa;

	pVal->setMessage(var);

	//fire notification event
	Fire_OnDeliverSM(pVal);

}