
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 6.00.0347 */
/* at Tue Jul 30 12:52:05 2002
 */
/* Compiler settings for SMPPCOM.idl:
    Oicf, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __SMPPCOM_h__
#define __SMPPCOM_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __ISmppDateCom_FWD_DEFINED__
#define __ISmppDateCom_FWD_DEFINED__
typedef interface ISmppDateCom ISmppDateCom;
#endif 	/* __ISmppDateCom_FWD_DEFINED__ */


#ifndef __ISmppAddressCom_FWD_DEFINED__
#define __ISmppAddressCom_FWD_DEFINED__
typedef interface ISmppAddressCom ISmppAddressCom;
#endif 	/* __ISmppAddressCom_FWD_DEFINED__ */


#ifndef __ISubmitSMCom_FWD_DEFINED__
#define __ISubmitSMCom_FWD_DEFINED__
typedef interface ISubmitSMCom ISubmitSMCom;
#endif 	/* __ISubmitSMCom_FWD_DEFINED__ */


#ifndef __IEsmeTransmitterCom_FWD_DEFINED__
#define __IEsmeTransmitterCom_FWD_DEFINED__
typedef interface IEsmeTransmitterCom IEsmeTransmitterCom;
#endif 	/* __IEsmeTransmitterCom_FWD_DEFINED__ */


#ifndef __IDeliverSMCom_FWD_DEFINED__
#define __IDeliverSMCom_FWD_DEFINED__
typedef interface IDeliverSMCom IDeliverSMCom;
#endif 	/* __IDeliverSMCom_FWD_DEFINED__ */


#ifndef __IEsmeTransceiverCom_FWD_DEFINED__
#define __IEsmeTransceiverCom_FWD_DEFINED__
typedef interface IEsmeTransceiverCom IEsmeTransceiverCom;
#endif 	/* __IEsmeTransceiverCom_FWD_DEFINED__ */


#ifndef __IEsmeReceiverCom_FWD_DEFINED__
#define __IEsmeReceiverCom_FWD_DEFINED__
typedef interface IEsmeReceiverCom IEsmeReceiverCom;
#endif 	/* __IEsmeReceiverCom_FWD_DEFINED__ */


#ifndef __SubmitSMCom_FWD_DEFINED__
#define __SubmitSMCom_FWD_DEFINED__

#ifdef __cplusplus
typedef class SubmitSMCom SubmitSMCom;
#else
typedef struct SubmitSMCom SubmitSMCom;
#endif /* __cplusplus */

#endif 	/* __SubmitSMCom_FWD_DEFINED__ */


#ifndef __DeliverSMCom_FWD_DEFINED__
#define __DeliverSMCom_FWD_DEFINED__

#ifdef __cplusplus
typedef class DeliverSMCom DeliverSMCom;
#else
typedef struct DeliverSMCom DeliverSMCom;
#endif /* __cplusplus */

#endif 	/* __DeliverSMCom_FWD_DEFINED__ */


#ifndef __SmppDateCom_FWD_DEFINED__
#define __SmppDateCom_FWD_DEFINED__

#ifdef __cplusplus
typedef class SmppDateCom SmppDateCom;
#else
typedef struct SmppDateCom SmppDateCom;
#endif /* __cplusplus */

#endif 	/* __SmppDateCom_FWD_DEFINED__ */


#ifndef __SmppAddressCom_FWD_DEFINED__
#define __SmppAddressCom_FWD_DEFINED__

#ifdef __cplusplus
typedef class SmppAddressCom SmppAddressCom;
#else
typedef struct SmppAddressCom SmppAddressCom;
#endif /* __cplusplus */

#endif 	/* __SmppAddressCom_FWD_DEFINED__ */


#ifndef __EsmeTransmitterCom_FWD_DEFINED__
#define __EsmeTransmitterCom_FWD_DEFINED__

#ifdef __cplusplus
typedef class EsmeTransmitterCom EsmeTransmitterCom;
#else
typedef struct EsmeTransmitterCom EsmeTransmitterCom;
#endif /* __cplusplus */

#endif 	/* __EsmeTransmitterCom_FWD_DEFINED__ */


#ifndef ___IEsmeTransceiverComEvents_FWD_DEFINED__
#define ___IEsmeTransceiverComEvents_FWD_DEFINED__
typedef interface _IEsmeTransceiverComEvents _IEsmeTransceiverComEvents;
#endif 	/* ___IEsmeTransceiverComEvents_FWD_DEFINED__ */


#ifndef __EsmeTransceiverCom_FWD_DEFINED__
#define __EsmeTransceiverCom_FWD_DEFINED__

#ifdef __cplusplus
typedef class EsmeTransceiverCom EsmeTransceiverCom;
#else
typedef struct EsmeTransceiverCom EsmeTransceiverCom;
#endif /* __cplusplus */

#endif 	/* __EsmeTransceiverCom_FWD_DEFINED__ */


#ifndef ___IEsmeReceiverComEvents_FWD_DEFINED__
#define ___IEsmeReceiverComEvents_FWD_DEFINED__
typedef interface _IEsmeReceiverComEvents _IEsmeReceiverComEvents;
#endif 	/* ___IEsmeReceiverComEvents_FWD_DEFINED__ */


#ifndef __EsmeReceiverCom_FWD_DEFINED__
#define __EsmeReceiverCom_FWD_DEFINED__

#ifdef __cplusplus
typedef class EsmeReceiverCom EsmeReceiverCom;
#else
typedef struct EsmeReceiverCom EsmeReceiverCom;
#endif /* __cplusplus */

#endif 	/* __EsmeReceiverCom_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 

void * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void * ); 

#ifndef __ISmppDateCom_INTERFACE_DEFINED__
#define __ISmppDateCom_INTERFACE_DEFINED__

/* interface ISmppDateCom */
/* [unique][helpstring][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_ISmppDateCom;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("DF4BDE09-633A-4514-B72D-342271D61463")
    ISmppDateCom : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE isNull( 
            /* [retval][out] */ VARIANT_BOOL *valnull) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE setNull( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE toString( 
            /* [retval][out] */ BSTR *strdate) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE setDate( 
            /* [in] */ BSTR strdate) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISmppDateComVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISmppDateCom * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISmppDateCom * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISmppDateCom * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISmppDateCom * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISmppDateCom * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISmppDateCom * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISmppDateCom * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *isNull )( 
            ISmppDateCom * This,
            /* [retval][out] */ VARIANT_BOOL *valnull);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *setNull )( 
            ISmppDateCom * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *toString )( 
            ISmppDateCom * This,
            /* [retval][out] */ BSTR *strdate);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *setDate )( 
            ISmppDateCom * This,
            /* [in] */ BSTR strdate);
        
        END_INTERFACE
    } ISmppDateComVtbl;

    interface ISmppDateCom
    {
        CONST_VTBL struct ISmppDateComVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISmppDateCom_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISmppDateCom_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISmppDateCom_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISmppDateCom_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISmppDateCom_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISmppDateCom_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISmppDateCom_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISmppDateCom_isNull(This,valnull)	\
    (This)->lpVtbl -> isNull(This,valnull)

#define ISmppDateCom_setNull(This)	\
    (This)->lpVtbl -> setNull(This)

#define ISmppDateCom_toString(This,strdate)	\
    (This)->lpVtbl -> toString(This,strdate)

#define ISmppDateCom_setDate(This,strdate)	\
    (This)->lpVtbl -> setDate(This,strdate)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISmppDateCom_isNull_Proxy( 
    ISmppDateCom * This,
    /* [retval][out] */ VARIANT_BOOL *valnull);


void __RPC_STUB ISmppDateCom_isNull_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISmppDateCom_setNull_Proxy( 
    ISmppDateCom * This);


void __RPC_STUB ISmppDateCom_setNull_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISmppDateCom_toString_Proxy( 
    ISmppDateCom * This,
    /* [retval][out] */ BSTR *strdate);


void __RPC_STUB ISmppDateCom_toString_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISmppDateCom_setDate_Proxy( 
    ISmppDateCom * This,
    /* [in] */ BSTR strdate);


void __RPC_STUB ISmppDateCom_setDate_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISmppDateCom_INTERFACE_DEFINED__ */


#ifndef __ISmppAddressCom_INTERFACE_DEFINED__
#define __ISmppAddressCom_INTERFACE_DEFINED__

/* interface ISmppAddressCom */
/* [unique][helpstring][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_ISmppAddressCom;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("2CB72805-62F8-470F-B28E-85159572DF87")
    ISmppAddressCom : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_TON( 
            /* [retval][out] */ SHORT *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_TON( 
            /* [in] */ SHORT newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_NPI( 
            /* [retval][out] */ SHORT *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_NPI( 
            /* [in] */ SHORT newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Address( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Address( 
            /* [in] */ BSTR newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISmppAddressComVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISmppAddressCom * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISmppAddressCom * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISmppAddressCom * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISmppAddressCom * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISmppAddressCom * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISmppAddressCom * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISmppAddressCom * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_TON )( 
            ISmppAddressCom * This,
            /* [retval][out] */ SHORT *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_TON )( 
            ISmppAddressCom * This,
            /* [in] */ SHORT newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_NPI )( 
            ISmppAddressCom * This,
            /* [retval][out] */ SHORT *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_NPI )( 
            ISmppAddressCom * This,
            /* [in] */ SHORT newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Address )( 
            ISmppAddressCom * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Address )( 
            ISmppAddressCom * This,
            /* [in] */ BSTR newVal);
        
        END_INTERFACE
    } ISmppAddressComVtbl;

    interface ISmppAddressCom
    {
        CONST_VTBL struct ISmppAddressComVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISmppAddressCom_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISmppAddressCom_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISmppAddressCom_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISmppAddressCom_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISmppAddressCom_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISmppAddressCom_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISmppAddressCom_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISmppAddressCom_get_TON(This,pVal)	\
    (This)->lpVtbl -> get_TON(This,pVal)

#define ISmppAddressCom_put_TON(This,newVal)	\
    (This)->lpVtbl -> put_TON(This,newVal)

#define ISmppAddressCom_get_NPI(This,pVal)	\
    (This)->lpVtbl -> get_NPI(This,pVal)

#define ISmppAddressCom_put_NPI(This,newVal)	\
    (This)->lpVtbl -> put_NPI(This,newVal)

#define ISmppAddressCom_get_Address(This,pVal)	\
    (This)->lpVtbl -> get_Address(This,pVal)

#define ISmppAddressCom_put_Address(This,newVal)	\
    (This)->lpVtbl -> put_Address(This,newVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISmppAddressCom_get_TON_Proxy( 
    ISmppAddressCom * This,
    /* [retval][out] */ SHORT *pVal);


void __RPC_STUB ISmppAddressCom_get_TON_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISmppAddressCom_put_TON_Proxy( 
    ISmppAddressCom * This,
    /* [in] */ SHORT newVal);


void __RPC_STUB ISmppAddressCom_put_TON_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISmppAddressCom_get_NPI_Proxy( 
    ISmppAddressCom * This,
    /* [retval][out] */ SHORT *pVal);


void __RPC_STUB ISmppAddressCom_get_NPI_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISmppAddressCom_put_NPI_Proxy( 
    ISmppAddressCom * This,
    /* [in] */ SHORT newVal);


void __RPC_STUB ISmppAddressCom_put_NPI_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISmppAddressCom_get_Address_Proxy( 
    ISmppAddressCom * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB ISmppAddressCom_get_Address_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISmppAddressCom_put_Address_Proxy( 
    ISmppAddressCom * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB ISmppAddressCom_put_Address_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISmppAddressCom_INTERFACE_DEFINED__ */


#ifndef __ISubmitSMCom_INTERFACE_DEFINED__
#define __ISubmitSMCom_INTERFACE_DEFINED__

/* interface ISubmitSMCom */
/* [unique][helpstring][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_ISubmitSMCom;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("C464074B-85CF-42B7-AB92-E7998FBAFA74")
    ISubmitSMCom : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ServiceType( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ServiceType( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Source( 
            /* [retval][out] */ ISmppAddressCom **pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Source( 
            /* [in] */ ISmppAddressCom *newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Destination( 
            /* [retval][out] */ ISmppAddressCom **pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Destination( 
            /* [in] */ ISmppAddressCom *newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_esmClass( 
            /* [retval][out] */ SHORT *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_esmClass( 
            /* [in] */ SHORT newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_dataCoding( 
            /* [retval][out] */ SHORT *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_dataCoding( 
            /* [in] */ SHORT newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_protocolID( 
            /* [retval][out] */ SHORT *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_protocolID( 
            /* [in] */ SHORT newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_priorityFlag( 
            /* [retval][out] */ SHORT *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_priorityFlag( 
            /* [in] */ SHORT newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_scheduledDelivery( 
            /* [retval][out] */ ISmppDateCom **pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_scheduledDelivery( 
            /* [in] */ ISmppDateCom *newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_validityPeriod( 
            /* [retval][out] */ ISmppDateCom **pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_validityPeriod( 
            /* [in] */ ISmppDateCom *newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_registeredDelivery( 
            /* [retval][out] */ SHORT *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_registeredDelivery( 
            /* [in] */ SHORT newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_replaceIfPresent( 
            /* [retval][out] */ SHORT *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_replaceIfPresent( 
            /* [in] */ SHORT newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_smDefaultMsgId( 
            /* [retval][out] */ SHORT *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_smDefaultMsgId( 
            /* [in] */ SHORT newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Message( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Message( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE compactMessage( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE flipByteOrder( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE setMessage( 
            /* [in] */ VARIANT msgdata) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE getMessage( 
            /* [retval][out] */ VARIANT *pmsgdata) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISubmitSMComVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISubmitSMCom * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISubmitSMCom * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISubmitSMCom * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISubmitSMCom * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISubmitSMCom * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISubmitSMCom * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISubmitSMCom * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ServiceType )( 
            ISubmitSMCom * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_ServiceType )( 
            ISubmitSMCom * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Source )( 
            ISubmitSMCom * This,
            /* [retval][out] */ ISmppAddressCom **pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Source )( 
            ISubmitSMCom * This,
            /* [in] */ ISmppAddressCom *newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Destination )( 
            ISubmitSMCom * This,
            /* [retval][out] */ ISmppAddressCom **pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Destination )( 
            ISubmitSMCom * This,
            /* [in] */ ISmppAddressCom *newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_esmClass )( 
            ISubmitSMCom * This,
            /* [retval][out] */ SHORT *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_esmClass )( 
            ISubmitSMCom * This,
            /* [in] */ SHORT newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_dataCoding )( 
            ISubmitSMCom * This,
            /* [retval][out] */ SHORT *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_dataCoding )( 
            ISubmitSMCom * This,
            /* [in] */ SHORT newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_protocolID )( 
            ISubmitSMCom * This,
            /* [retval][out] */ SHORT *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_protocolID )( 
            ISubmitSMCom * This,
            /* [in] */ SHORT newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_priorityFlag )( 
            ISubmitSMCom * This,
            /* [retval][out] */ SHORT *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_priorityFlag )( 
            ISubmitSMCom * This,
            /* [in] */ SHORT newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_scheduledDelivery )( 
            ISubmitSMCom * This,
            /* [retval][out] */ ISmppDateCom **pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_scheduledDelivery )( 
            ISubmitSMCom * This,
            /* [in] */ ISmppDateCom *newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_validityPeriod )( 
            ISubmitSMCom * This,
            /* [retval][out] */ ISmppDateCom **pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_validityPeriod )( 
            ISubmitSMCom * This,
            /* [in] */ ISmppDateCom *newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_registeredDelivery )( 
            ISubmitSMCom * This,
            /* [retval][out] */ SHORT *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_registeredDelivery )( 
            ISubmitSMCom * This,
            /* [in] */ SHORT newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_replaceIfPresent )( 
            ISubmitSMCom * This,
            /* [retval][out] */ SHORT *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_replaceIfPresent )( 
            ISubmitSMCom * This,
            /* [in] */ SHORT newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_smDefaultMsgId )( 
            ISubmitSMCom * This,
            /* [retval][out] */ SHORT *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_smDefaultMsgId )( 
            ISubmitSMCom * This,
            /* [in] */ SHORT newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Message )( 
            ISubmitSMCom * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Message )( 
            ISubmitSMCom * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *compactMessage )( 
            ISubmitSMCom * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *flipByteOrder )( 
            ISubmitSMCom * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *setMessage )( 
            ISubmitSMCom * This,
            /* [in] */ VARIANT msgdata);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *getMessage )( 
            ISubmitSMCom * This,
            /* [retval][out] */ VARIANT *pmsgdata);
        
        END_INTERFACE
    } ISubmitSMComVtbl;

    interface ISubmitSMCom
    {
        CONST_VTBL struct ISubmitSMComVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISubmitSMCom_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISubmitSMCom_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISubmitSMCom_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISubmitSMCom_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISubmitSMCom_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISubmitSMCom_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISubmitSMCom_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISubmitSMCom_get_ServiceType(This,pVal)	\
    (This)->lpVtbl -> get_ServiceType(This,pVal)

#define ISubmitSMCom_put_ServiceType(This,newVal)	\
    (This)->lpVtbl -> put_ServiceType(This,newVal)

#define ISubmitSMCom_get_Source(This,pVal)	\
    (This)->lpVtbl -> get_Source(This,pVal)

#define ISubmitSMCom_put_Source(This,newVal)	\
    (This)->lpVtbl -> put_Source(This,newVal)

#define ISubmitSMCom_get_Destination(This,pVal)	\
    (This)->lpVtbl -> get_Destination(This,pVal)

#define ISubmitSMCom_put_Destination(This,newVal)	\
    (This)->lpVtbl -> put_Destination(This,newVal)

#define ISubmitSMCom_get_esmClass(This,pVal)	\
    (This)->lpVtbl -> get_esmClass(This,pVal)

#define ISubmitSMCom_put_esmClass(This,newVal)	\
    (This)->lpVtbl -> put_esmClass(This,newVal)

#define ISubmitSMCom_get_dataCoding(This,pVal)	\
    (This)->lpVtbl -> get_dataCoding(This,pVal)

#define ISubmitSMCom_put_dataCoding(This,newVal)	\
    (This)->lpVtbl -> put_dataCoding(This,newVal)

#define ISubmitSMCom_get_protocolID(This,pVal)	\
    (This)->lpVtbl -> get_protocolID(This,pVal)

#define ISubmitSMCom_put_protocolID(This,newVal)	\
    (This)->lpVtbl -> put_protocolID(This,newVal)

#define ISubmitSMCom_get_priorityFlag(This,pVal)	\
    (This)->lpVtbl -> get_priorityFlag(This,pVal)

#define ISubmitSMCom_put_priorityFlag(This,newVal)	\
    (This)->lpVtbl -> put_priorityFlag(This,newVal)

#define ISubmitSMCom_get_scheduledDelivery(This,pVal)	\
    (This)->lpVtbl -> get_scheduledDelivery(This,pVal)

#define ISubmitSMCom_put_scheduledDelivery(This,newVal)	\
    (This)->lpVtbl -> put_scheduledDelivery(This,newVal)

#define ISubmitSMCom_get_validityPeriod(This,pVal)	\
    (This)->lpVtbl -> get_validityPeriod(This,pVal)

#define ISubmitSMCom_put_validityPeriod(This,newVal)	\
    (This)->lpVtbl -> put_validityPeriod(This,newVal)

#define ISubmitSMCom_get_registeredDelivery(This,pVal)	\
    (This)->lpVtbl -> get_registeredDelivery(This,pVal)

#define ISubmitSMCom_put_registeredDelivery(This,newVal)	\
    (This)->lpVtbl -> put_registeredDelivery(This,newVal)

#define ISubmitSMCom_get_replaceIfPresent(This,pVal)	\
    (This)->lpVtbl -> get_replaceIfPresent(This,pVal)

#define ISubmitSMCom_put_replaceIfPresent(This,newVal)	\
    (This)->lpVtbl -> put_replaceIfPresent(This,newVal)

#define ISubmitSMCom_get_smDefaultMsgId(This,pVal)	\
    (This)->lpVtbl -> get_smDefaultMsgId(This,pVal)

#define ISubmitSMCom_put_smDefaultMsgId(This,newVal)	\
    (This)->lpVtbl -> put_smDefaultMsgId(This,newVal)

#define ISubmitSMCom_get_Message(This,pVal)	\
    (This)->lpVtbl -> get_Message(This,pVal)

#define ISubmitSMCom_put_Message(This,newVal)	\
    (This)->lpVtbl -> put_Message(This,newVal)

#define ISubmitSMCom_compactMessage(This)	\
    (This)->lpVtbl -> compactMessage(This)

#define ISubmitSMCom_flipByteOrder(This)	\
    (This)->lpVtbl -> flipByteOrder(This)

#define ISubmitSMCom_setMessage(This,msgdata)	\
    (This)->lpVtbl -> setMessage(This,msgdata)

#define ISubmitSMCom_getMessage(This,pmsgdata)	\
    (This)->lpVtbl -> getMessage(This,pmsgdata)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISubmitSMCom_get_ServiceType_Proxy( 
    ISubmitSMCom * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB ISubmitSMCom_get_ServiceType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISubmitSMCom_put_ServiceType_Proxy( 
    ISubmitSMCom * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB ISubmitSMCom_put_ServiceType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISubmitSMCom_get_Source_Proxy( 
    ISubmitSMCom * This,
    /* [retval][out] */ ISmppAddressCom **pVal);


void __RPC_STUB ISubmitSMCom_get_Source_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISubmitSMCom_put_Source_Proxy( 
    ISubmitSMCom * This,
    /* [in] */ ISmppAddressCom *newVal);


void __RPC_STUB ISubmitSMCom_put_Source_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISubmitSMCom_get_Destination_Proxy( 
    ISubmitSMCom * This,
    /* [retval][out] */ ISmppAddressCom **pVal);


void __RPC_STUB ISubmitSMCom_get_Destination_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISubmitSMCom_put_Destination_Proxy( 
    ISubmitSMCom * This,
    /* [in] */ ISmppAddressCom *newVal);


void __RPC_STUB ISubmitSMCom_put_Destination_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISubmitSMCom_get_esmClass_Proxy( 
    ISubmitSMCom * This,
    /* [retval][out] */ SHORT *pVal);


void __RPC_STUB ISubmitSMCom_get_esmClass_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISubmitSMCom_put_esmClass_Proxy( 
    ISubmitSMCom * This,
    /* [in] */ SHORT newVal);


void __RPC_STUB ISubmitSMCom_put_esmClass_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISubmitSMCom_get_dataCoding_Proxy( 
    ISubmitSMCom * This,
    /* [retval][out] */ SHORT *pVal);


void __RPC_STUB ISubmitSMCom_get_dataCoding_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISubmitSMCom_put_dataCoding_Proxy( 
    ISubmitSMCom * This,
    /* [in] */ SHORT newVal);


void __RPC_STUB ISubmitSMCom_put_dataCoding_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISubmitSMCom_get_protocolID_Proxy( 
    ISubmitSMCom * This,
    /* [retval][out] */ SHORT *pVal);


void __RPC_STUB ISubmitSMCom_get_protocolID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISubmitSMCom_put_protocolID_Proxy( 
    ISubmitSMCom * This,
    /* [in] */ SHORT newVal);


void __RPC_STUB ISubmitSMCom_put_protocolID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISubmitSMCom_get_priorityFlag_Proxy( 
    ISubmitSMCom * This,
    /* [retval][out] */ SHORT *pVal);


void __RPC_STUB ISubmitSMCom_get_priorityFlag_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISubmitSMCom_put_priorityFlag_Proxy( 
    ISubmitSMCom * This,
    /* [in] */ SHORT newVal);


void __RPC_STUB ISubmitSMCom_put_priorityFlag_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISubmitSMCom_get_scheduledDelivery_Proxy( 
    ISubmitSMCom * This,
    /* [retval][out] */ ISmppDateCom **pVal);


void __RPC_STUB ISubmitSMCom_get_scheduledDelivery_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISubmitSMCom_put_scheduledDelivery_Proxy( 
    ISubmitSMCom * This,
    /* [in] */ ISmppDateCom *newVal);


void __RPC_STUB ISubmitSMCom_put_scheduledDelivery_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISubmitSMCom_get_validityPeriod_Proxy( 
    ISubmitSMCom * This,
    /* [retval][out] */ ISmppDateCom **pVal);


void __RPC_STUB ISubmitSMCom_get_validityPeriod_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISubmitSMCom_put_validityPeriod_Proxy( 
    ISubmitSMCom * This,
    /* [in] */ ISmppDateCom *newVal);


void __RPC_STUB ISubmitSMCom_put_validityPeriod_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISubmitSMCom_get_registeredDelivery_Proxy( 
    ISubmitSMCom * This,
    /* [retval][out] */ SHORT *pVal);


void __RPC_STUB ISubmitSMCom_get_registeredDelivery_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISubmitSMCom_put_registeredDelivery_Proxy( 
    ISubmitSMCom * This,
    /* [in] */ SHORT newVal);


void __RPC_STUB ISubmitSMCom_put_registeredDelivery_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISubmitSMCom_get_replaceIfPresent_Proxy( 
    ISubmitSMCom * This,
    /* [retval][out] */ SHORT *pVal);


void __RPC_STUB ISubmitSMCom_get_replaceIfPresent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISubmitSMCom_put_replaceIfPresent_Proxy( 
    ISubmitSMCom * This,
    /* [in] */ SHORT newVal);


void __RPC_STUB ISubmitSMCom_put_replaceIfPresent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISubmitSMCom_get_smDefaultMsgId_Proxy( 
    ISubmitSMCom * This,
    /* [retval][out] */ SHORT *pVal);


void __RPC_STUB ISubmitSMCom_get_smDefaultMsgId_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISubmitSMCom_put_smDefaultMsgId_Proxy( 
    ISubmitSMCom * This,
    /* [in] */ SHORT newVal);


void __RPC_STUB ISubmitSMCom_put_smDefaultMsgId_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISubmitSMCom_get_Message_Proxy( 
    ISubmitSMCom * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB ISubmitSMCom_get_Message_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISubmitSMCom_put_Message_Proxy( 
    ISubmitSMCom * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB ISubmitSMCom_put_Message_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISubmitSMCom_compactMessage_Proxy( 
    ISubmitSMCom * This);


void __RPC_STUB ISubmitSMCom_compactMessage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISubmitSMCom_flipByteOrder_Proxy( 
    ISubmitSMCom * This);


void __RPC_STUB ISubmitSMCom_flipByteOrder_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISubmitSMCom_setMessage_Proxy( 
    ISubmitSMCom * This,
    /* [in] */ VARIANT msgdata);


void __RPC_STUB ISubmitSMCom_setMessage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISubmitSMCom_getMessage_Proxy( 
    ISubmitSMCom * This,
    /* [retval][out] */ VARIANT *pmsgdata);


void __RPC_STUB ISubmitSMCom_getMessage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISubmitSMCom_INTERFACE_DEFINED__ */


#ifndef __IEsmeTransmitterCom_INTERFACE_DEFINED__
#define __IEsmeTransmitterCom_INTERFACE_DEFINED__

/* interface IEsmeTransmitterCom */
/* [unique][helpstring][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_IEsmeTransmitterCom;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("3C9111B7-D010-48E6-9AA6-33599987481F")
    IEsmeTransmitterCom : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE bind( 
            /* [in] */ BSTR sysid,
            /* [in] */ BSTR passwd,
            /* [in] */ BSTR systype,
            /* [in] */ ISmppAddressCom *iaddr,
            /* [retval][out] */ VARIANT_BOOL *pret) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE unbind( 
            /* [retval][out] */ VARIANT_BOOL *pret) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE enquireLink( 
            /* [retval][out] */ VARIANT_BOOL *pret) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE init( 
            /* [in] */ BSTR svrip,
            /* [in] */ LONG port) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE close( void) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Connected( 
            /* [retval][out] */ VARIANT_BOOL *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE submitMessage( 
            /* [in] */ ISubmitSMCom *isubmit,
            /* [out] */ BSTR *pMsgid,
            /* [retval][out] */ VARIANT_BOOL *pret) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IEsmeTransmitterComVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IEsmeTransmitterCom * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IEsmeTransmitterCom * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IEsmeTransmitterCom * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IEsmeTransmitterCom * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IEsmeTransmitterCom * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IEsmeTransmitterCom * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IEsmeTransmitterCom * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *bind )( 
            IEsmeTransmitterCom * This,
            /* [in] */ BSTR sysid,
            /* [in] */ BSTR passwd,
            /* [in] */ BSTR systype,
            /* [in] */ ISmppAddressCom *iaddr,
            /* [retval][out] */ VARIANT_BOOL *pret);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *unbind )( 
            IEsmeTransmitterCom * This,
            /* [retval][out] */ VARIANT_BOOL *pret);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *enquireLink )( 
            IEsmeTransmitterCom * This,
            /* [retval][out] */ VARIANT_BOOL *pret);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *init )( 
            IEsmeTransmitterCom * This,
            /* [in] */ BSTR svrip,
            /* [in] */ LONG port);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *close )( 
            IEsmeTransmitterCom * This);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Connected )( 
            IEsmeTransmitterCom * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *submitMessage )( 
            IEsmeTransmitterCom * This,
            /* [in] */ ISubmitSMCom *isubmit,
            /* [out] */ BSTR *pMsgid,
            /* [retval][out] */ VARIANT_BOOL *pret);
        
        END_INTERFACE
    } IEsmeTransmitterComVtbl;

    interface IEsmeTransmitterCom
    {
        CONST_VTBL struct IEsmeTransmitterComVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IEsmeTransmitterCom_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IEsmeTransmitterCom_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IEsmeTransmitterCom_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IEsmeTransmitterCom_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IEsmeTransmitterCom_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IEsmeTransmitterCom_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IEsmeTransmitterCom_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IEsmeTransmitterCom_bind(This,sysid,passwd,systype,iaddr,pret)	\
    (This)->lpVtbl -> bind(This,sysid,passwd,systype,iaddr,pret)

#define IEsmeTransmitterCom_unbind(This,pret)	\
    (This)->lpVtbl -> unbind(This,pret)

#define IEsmeTransmitterCom_enquireLink(This,pret)	\
    (This)->lpVtbl -> enquireLink(This,pret)

#define IEsmeTransmitterCom_init(This,svrip,port)	\
    (This)->lpVtbl -> init(This,svrip,port)

#define IEsmeTransmitterCom_close(This)	\
    (This)->lpVtbl -> close(This)

#define IEsmeTransmitterCom_get_Connected(This,pVal)	\
    (This)->lpVtbl -> get_Connected(This,pVal)

#define IEsmeTransmitterCom_submitMessage(This,isubmit,pMsgid,pret)	\
    (This)->lpVtbl -> submitMessage(This,isubmit,pMsgid,pret)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IEsmeTransmitterCom_bind_Proxy( 
    IEsmeTransmitterCom * This,
    /* [in] */ BSTR sysid,
    /* [in] */ BSTR passwd,
    /* [in] */ BSTR systype,
    /* [in] */ ISmppAddressCom *iaddr,
    /* [retval][out] */ VARIANT_BOOL *pret);


void __RPC_STUB IEsmeTransmitterCom_bind_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IEsmeTransmitterCom_unbind_Proxy( 
    IEsmeTransmitterCom * This,
    /* [retval][out] */ VARIANT_BOOL *pret);


void __RPC_STUB IEsmeTransmitterCom_unbind_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IEsmeTransmitterCom_enquireLink_Proxy( 
    IEsmeTransmitterCom * This,
    /* [retval][out] */ VARIANT_BOOL *pret);


void __RPC_STUB IEsmeTransmitterCom_enquireLink_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IEsmeTransmitterCom_init_Proxy( 
    IEsmeTransmitterCom * This,
    /* [in] */ BSTR svrip,
    /* [in] */ LONG port);


void __RPC_STUB IEsmeTransmitterCom_init_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IEsmeTransmitterCom_close_Proxy( 
    IEsmeTransmitterCom * This);


void __RPC_STUB IEsmeTransmitterCom_close_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IEsmeTransmitterCom_get_Connected_Proxy( 
    IEsmeTransmitterCom * This,
    /* [retval][out] */ VARIANT_BOOL *pVal);


void __RPC_STUB IEsmeTransmitterCom_get_Connected_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IEsmeTransmitterCom_submitMessage_Proxy( 
    IEsmeTransmitterCom * This,
    /* [in] */ ISubmitSMCom *isubmit,
    /* [out] */ BSTR *pMsgid,
    /* [retval][out] */ VARIANT_BOOL *pret);


void __RPC_STUB IEsmeTransmitterCom_submitMessage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IEsmeTransmitterCom_INTERFACE_DEFINED__ */


#ifndef __IDeliverSMCom_INTERFACE_DEFINED__
#define __IDeliverSMCom_INTERFACE_DEFINED__

/* interface IDeliverSMCom */
/* [unique][helpstring][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_IDeliverSMCom;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("2DB76F63-43CA-4610-BFD0-3CE885D6078B")
    IDeliverSMCom : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_ServiceType( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_ServiceType( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Source( 
            /* [retval][out] */ ISmppAddressCom **pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Source( 
            /* [in] */ ISmppAddressCom *newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Destination( 
            /* [retval][out] */ ISmppAddressCom **pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Destination( 
            /* [in] */ ISmppAddressCom *newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_esmClass( 
            /* [retval][out] */ SHORT *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_esmClass( 
            /* [in] */ SHORT newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_dataCoding( 
            /* [retval][out] */ SHORT *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_dataCoding( 
            /* [in] */ SHORT newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_protocolID( 
            /* [retval][out] */ SHORT *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_protocolID( 
            /* [in] */ SHORT newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_priorityFlag( 
            /* [retval][out] */ SHORT *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_priorityFlag( 
            /* [in] */ SHORT newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_scheduledDelivery( 
            /* [retval][out] */ ISmppDateCom **pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_scheduledDelivery( 
            /* [in] */ ISmppDateCom *newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_validityPeriod( 
            /* [retval][out] */ ISmppDateCom **pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_validityPeriod( 
            /* [in] */ ISmppDateCom *newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_registeredDelivery( 
            /* [retval][out] */ SHORT *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_registeredDelivery( 
            /* [in] */ SHORT newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_replaceIfPresent( 
            /* [retval][out] */ SHORT *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_replaceIfPresent( 
            /* [in] */ SHORT newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_smDefaultMsgId( 
            /* [retval][out] */ SHORT *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_smDefaultMsgId( 
            /* [in] */ SHORT newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Message( 
            /* [retval][out] */ BSTR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Message( 
            /* [in] */ BSTR newVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE compactMessage( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE flipByteOrder( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE setMessage( 
            /* [in] */ VARIANT msgdata) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE getMessage( 
            /* [retval][out] */ VARIANT *pmsgdata) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IDeliverSMComVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IDeliverSMCom * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IDeliverSMCom * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IDeliverSMCom * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IDeliverSMCom * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IDeliverSMCom * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IDeliverSMCom * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IDeliverSMCom * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_ServiceType )( 
            IDeliverSMCom * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_ServiceType )( 
            IDeliverSMCom * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Source )( 
            IDeliverSMCom * This,
            /* [retval][out] */ ISmppAddressCom **pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Source )( 
            IDeliverSMCom * This,
            /* [in] */ ISmppAddressCom *newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Destination )( 
            IDeliverSMCom * This,
            /* [retval][out] */ ISmppAddressCom **pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Destination )( 
            IDeliverSMCom * This,
            /* [in] */ ISmppAddressCom *newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_esmClass )( 
            IDeliverSMCom * This,
            /* [retval][out] */ SHORT *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_esmClass )( 
            IDeliverSMCom * This,
            /* [in] */ SHORT newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_dataCoding )( 
            IDeliverSMCom * This,
            /* [retval][out] */ SHORT *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_dataCoding )( 
            IDeliverSMCom * This,
            /* [in] */ SHORT newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_protocolID )( 
            IDeliverSMCom * This,
            /* [retval][out] */ SHORT *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_protocolID )( 
            IDeliverSMCom * This,
            /* [in] */ SHORT newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_priorityFlag )( 
            IDeliverSMCom * This,
            /* [retval][out] */ SHORT *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_priorityFlag )( 
            IDeliverSMCom * This,
            /* [in] */ SHORT newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_scheduledDelivery )( 
            IDeliverSMCom * This,
            /* [retval][out] */ ISmppDateCom **pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_scheduledDelivery )( 
            IDeliverSMCom * This,
            /* [in] */ ISmppDateCom *newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_validityPeriod )( 
            IDeliverSMCom * This,
            /* [retval][out] */ ISmppDateCom **pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_validityPeriod )( 
            IDeliverSMCom * This,
            /* [in] */ ISmppDateCom *newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_registeredDelivery )( 
            IDeliverSMCom * This,
            /* [retval][out] */ SHORT *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_registeredDelivery )( 
            IDeliverSMCom * This,
            /* [in] */ SHORT newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_replaceIfPresent )( 
            IDeliverSMCom * This,
            /* [retval][out] */ SHORT *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_replaceIfPresent )( 
            IDeliverSMCom * This,
            /* [in] */ SHORT newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_smDefaultMsgId )( 
            IDeliverSMCom * This,
            /* [retval][out] */ SHORT *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_smDefaultMsgId )( 
            IDeliverSMCom * This,
            /* [in] */ SHORT newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Message )( 
            IDeliverSMCom * This,
            /* [retval][out] */ BSTR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE *put_Message )( 
            IDeliverSMCom * This,
            /* [in] */ BSTR newVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *compactMessage )( 
            IDeliverSMCom * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *flipByteOrder )( 
            IDeliverSMCom * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *setMessage )( 
            IDeliverSMCom * This,
            /* [in] */ VARIANT msgdata);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *getMessage )( 
            IDeliverSMCom * This,
            /* [retval][out] */ VARIANT *pmsgdata);
        
        END_INTERFACE
    } IDeliverSMComVtbl;

    interface IDeliverSMCom
    {
        CONST_VTBL struct IDeliverSMComVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IDeliverSMCom_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IDeliverSMCom_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IDeliverSMCom_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IDeliverSMCom_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IDeliverSMCom_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IDeliverSMCom_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IDeliverSMCom_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IDeliverSMCom_get_ServiceType(This,pVal)	\
    (This)->lpVtbl -> get_ServiceType(This,pVal)

#define IDeliverSMCom_put_ServiceType(This,newVal)	\
    (This)->lpVtbl -> put_ServiceType(This,newVal)

#define IDeliverSMCom_get_Source(This,pVal)	\
    (This)->lpVtbl -> get_Source(This,pVal)

#define IDeliverSMCom_put_Source(This,newVal)	\
    (This)->lpVtbl -> put_Source(This,newVal)

#define IDeliverSMCom_get_Destination(This,pVal)	\
    (This)->lpVtbl -> get_Destination(This,pVal)

#define IDeliverSMCom_put_Destination(This,newVal)	\
    (This)->lpVtbl -> put_Destination(This,newVal)

#define IDeliverSMCom_get_esmClass(This,pVal)	\
    (This)->lpVtbl -> get_esmClass(This,pVal)

#define IDeliverSMCom_put_esmClass(This,newVal)	\
    (This)->lpVtbl -> put_esmClass(This,newVal)

#define IDeliverSMCom_get_dataCoding(This,pVal)	\
    (This)->lpVtbl -> get_dataCoding(This,pVal)

#define IDeliverSMCom_put_dataCoding(This,newVal)	\
    (This)->lpVtbl -> put_dataCoding(This,newVal)

#define IDeliverSMCom_get_protocolID(This,pVal)	\
    (This)->lpVtbl -> get_protocolID(This,pVal)

#define IDeliverSMCom_put_protocolID(This,newVal)	\
    (This)->lpVtbl -> put_protocolID(This,newVal)

#define IDeliverSMCom_get_priorityFlag(This,pVal)	\
    (This)->lpVtbl -> get_priorityFlag(This,pVal)

#define IDeliverSMCom_put_priorityFlag(This,newVal)	\
    (This)->lpVtbl -> put_priorityFlag(This,newVal)

#define IDeliverSMCom_get_scheduledDelivery(This,pVal)	\
    (This)->lpVtbl -> get_scheduledDelivery(This,pVal)

#define IDeliverSMCom_put_scheduledDelivery(This,newVal)	\
    (This)->lpVtbl -> put_scheduledDelivery(This,newVal)

#define IDeliverSMCom_get_validityPeriod(This,pVal)	\
    (This)->lpVtbl -> get_validityPeriod(This,pVal)

#define IDeliverSMCom_put_validityPeriod(This,newVal)	\
    (This)->lpVtbl -> put_validityPeriod(This,newVal)

#define IDeliverSMCom_get_registeredDelivery(This,pVal)	\
    (This)->lpVtbl -> get_registeredDelivery(This,pVal)

#define IDeliverSMCom_put_registeredDelivery(This,newVal)	\
    (This)->lpVtbl -> put_registeredDelivery(This,newVal)

#define IDeliverSMCom_get_replaceIfPresent(This,pVal)	\
    (This)->lpVtbl -> get_replaceIfPresent(This,pVal)

#define IDeliverSMCom_put_replaceIfPresent(This,newVal)	\
    (This)->lpVtbl -> put_replaceIfPresent(This,newVal)

#define IDeliverSMCom_get_smDefaultMsgId(This,pVal)	\
    (This)->lpVtbl -> get_smDefaultMsgId(This,pVal)

#define IDeliverSMCom_put_smDefaultMsgId(This,newVal)	\
    (This)->lpVtbl -> put_smDefaultMsgId(This,newVal)

#define IDeliverSMCom_get_Message(This,pVal)	\
    (This)->lpVtbl -> get_Message(This,pVal)

#define IDeliverSMCom_put_Message(This,newVal)	\
    (This)->lpVtbl -> put_Message(This,newVal)

#define IDeliverSMCom_compactMessage(This)	\
    (This)->lpVtbl -> compactMessage(This)

#define IDeliverSMCom_flipByteOrder(This)	\
    (This)->lpVtbl -> flipByteOrder(This)

#define IDeliverSMCom_setMessage(This,msgdata)	\
    (This)->lpVtbl -> setMessage(This,msgdata)

#define IDeliverSMCom_getMessage(This,pmsgdata)	\
    (This)->lpVtbl -> getMessage(This,pmsgdata)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IDeliverSMCom_get_ServiceType_Proxy( 
    IDeliverSMCom * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IDeliverSMCom_get_ServiceType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IDeliverSMCom_put_ServiceType_Proxy( 
    IDeliverSMCom * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IDeliverSMCom_put_ServiceType_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IDeliverSMCom_get_Source_Proxy( 
    IDeliverSMCom * This,
    /* [retval][out] */ ISmppAddressCom **pVal);


void __RPC_STUB IDeliverSMCom_get_Source_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IDeliverSMCom_put_Source_Proxy( 
    IDeliverSMCom * This,
    /* [in] */ ISmppAddressCom *newVal);


void __RPC_STUB IDeliverSMCom_put_Source_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IDeliverSMCom_get_Destination_Proxy( 
    IDeliverSMCom * This,
    /* [retval][out] */ ISmppAddressCom **pVal);


void __RPC_STUB IDeliverSMCom_get_Destination_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IDeliverSMCom_put_Destination_Proxy( 
    IDeliverSMCom * This,
    /* [in] */ ISmppAddressCom *newVal);


void __RPC_STUB IDeliverSMCom_put_Destination_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IDeliverSMCom_get_esmClass_Proxy( 
    IDeliverSMCom * This,
    /* [retval][out] */ SHORT *pVal);


void __RPC_STUB IDeliverSMCom_get_esmClass_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IDeliverSMCom_put_esmClass_Proxy( 
    IDeliverSMCom * This,
    /* [in] */ SHORT newVal);


void __RPC_STUB IDeliverSMCom_put_esmClass_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IDeliverSMCom_get_dataCoding_Proxy( 
    IDeliverSMCom * This,
    /* [retval][out] */ SHORT *pVal);


void __RPC_STUB IDeliverSMCom_get_dataCoding_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IDeliverSMCom_put_dataCoding_Proxy( 
    IDeliverSMCom * This,
    /* [in] */ SHORT newVal);


void __RPC_STUB IDeliverSMCom_put_dataCoding_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IDeliverSMCom_get_protocolID_Proxy( 
    IDeliverSMCom * This,
    /* [retval][out] */ SHORT *pVal);


void __RPC_STUB IDeliverSMCom_get_protocolID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IDeliverSMCom_put_protocolID_Proxy( 
    IDeliverSMCom * This,
    /* [in] */ SHORT newVal);


void __RPC_STUB IDeliverSMCom_put_protocolID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IDeliverSMCom_get_priorityFlag_Proxy( 
    IDeliverSMCom * This,
    /* [retval][out] */ SHORT *pVal);


void __RPC_STUB IDeliverSMCom_get_priorityFlag_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IDeliverSMCom_put_priorityFlag_Proxy( 
    IDeliverSMCom * This,
    /* [in] */ SHORT newVal);


void __RPC_STUB IDeliverSMCom_put_priorityFlag_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IDeliverSMCom_get_scheduledDelivery_Proxy( 
    IDeliverSMCom * This,
    /* [retval][out] */ ISmppDateCom **pVal);


void __RPC_STUB IDeliverSMCom_get_scheduledDelivery_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IDeliverSMCom_put_scheduledDelivery_Proxy( 
    IDeliverSMCom * This,
    /* [in] */ ISmppDateCom *newVal);


void __RPC_STUB IDeliverSMCom_put_scheduledDelivery_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IDeliverSMCom_get_validityPeriod_Proxy( 
    IDeliverSMCom * This,
    /* [retval][out] */ ISmppDateCom **pVal);


void __RPC_STUB IDeliverSMCom_get_validityPeriod_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IDeliverSMCom_put_validityPeriod_Proxy( 
    IDeliverSMCom * This,
    /* [in] */ ISmppDateCom *newVal);


void __RPC_STUB IDeliverSMCom_put_validityPeriod_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IDeliverSMCom_get_registeredDelivery_Proxy( 
    IDeliverSMCom * This,
    /* [retval][out] */ SHORT *pVal);


void __RPC_STUB IDeliverSMCom_get_registeredDelivery_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IDeliverSMCom_put_registeredDelivery_Proxy( 
    IDeliverSMCom * This,
    /* [in] */ SHORT newVal);


void __RPC_STUB IDeliverSMCom_put_registeredDelivery_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IDeliverSMCom_get_replaceIfPresent_Proxy( 
    IDeliverSMCom * This,
    /* [retval][out] */ SHORT *pVal);


void __RPC_STUB IDeliverSMCom_get_replaceIfPresent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IDeliverSMCom_put_replaceIfPresent_Proxy( 
    IDeliverSMCom * This,
    /* [in] */ SHORT newVal);


void __RPC_STUB IDeliverSMCom_put_replaceIfPresent_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IDeliverSMCom_get_smDefaultMsgId_Proxy( 
    IDeliverSMCom * This,
    /* [retval][out] */ SHORT *pVal);


void __RPC_STUB IDeliverSMCom_get_smDefaultMsgId_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IDeliverSMCom_put_smDefaultMsgId_Proxy( 
    IDeliverSMCom * This,
    /* [in] */ SHORT newVal);


void __RPC_STUB IDeliverSMCom_put_smDefaultMsgId_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IDeliverSMCom_get_Message_Proxy( 
    IDeliverSMCom * This,
    /* [retval][out] */ BSTR *pVal);


void __RPC_STUB IDeliverSMCom_get_Message_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IDeliverSMCom_put_Message_Proxy( 
    IDeliverSMCom * This,
    /* [in] */ BSTR newVal);


void __RPC_STUB IDeliverSMCom_put_Message_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IDeliverSMCom_compactMessage_Proxy( 
    IDeliverSMCom * This);


void __RPC_STUB IDeliverSMCom_compactMessage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IDeliverSMCom_flipByteOrder_Proxy( 
    IDeliverSMCom * This);


void __RPC_STUB IDeliverSMCom_flipByteOrder_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IDeliverSMCom_setMessage_Proxy( 
    IDeliverSMCom * This,
    /* [in] */ VARIANT msgdata);


void __RPC_STUB IDeliverSMCom_setMessage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IDeliverSMCom_getMessage_Proxy( 
    IDeliverSMCom * This,
    /* [retval][out] */ VARIANT *pmsgdata);


void __RPC_STUB IDeliverSMCom_getMessage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IDeliverSMCom_INTERFACE_DEFINED__ */


#ifndef __IEsmeTransceiverCom_INTERFACE_DEFINED__
#define __IEsmeTransceiverCom_INTERFACE_DEFINED__

/* interface IEsmeTransceiverCom */
/* [unique][helpstring][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_IEsmeTransceiverCom;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("C258AF14-8CEF-404F-BE03-62B6C57F6026")
    IEsmeTransceiverCom : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE bind( 
            /* [in] */ BSTR sysid,
            /* [in] */ BSTR passwd,
            /* [in] */ BSTR systype,
            /* [in] */ ISmppAddressCom *iaddr,
            /* [retval][out] */ VARIANT_BOOL *pret) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE unbind( 
            /* [retval][out] */ VARIANT_BOOL *pret) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE enquireLink( 
            /* [retval][out] */ VARIANT_BOOL *pret) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE init( 
            /* [in] */ BSTR svrip,
            /* [in] */ LONG port) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE close( void) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Connected( 
            /* [retval][out] */ VARIANT_BOOL *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE submitMessage( 
            /* [in] */ ISubmitSMCom *isubmit,
            /* [out] */ BSTR *pMsgid,
            /* [retval][out] */ VARIANT_BOOL *pret) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IEsmeTransceiverComVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IEsmeTransceiverCom * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IEsmeTransceiverCom * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IEsmeTransceiverCom * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IEsmeTransceiverCom * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IEsmeTransceiverCom * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IEsmeTransceiverCom * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IEsmeTransceiverCom * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *bind )( 
            IEsmeTransceiverCom * This,
            /* [in] */ BSTR sysid,
            /* [in] */ BSTR passwd,
            /* [in] */ BSTR systype,
            /* [in] */ ISmppAddressCom *iaddr,
            /* [retval][out] */ VARIANT_BOOL *pret);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *unbind )( 
            IEsmeTransceiverCom * This,
            /* [retval][out] */ VARIANT_BOOL *pret);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *enquireLink )( 
            IEsmeTransceiverCom * This,
            /* [retval][out] */ VARIANT_BOOL *pret);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *init )( 
            IEsmeTransceiverCom * This,
            /* [in] */ BSTR svrip,
            /* [in] */ LONG port);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *close )( 
            IEsmeTransceiverCom * This);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Connected )( 
            IEsmeTransceiverCom * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *submitMessage )( 
            IEsmeTransceiverCom * This,
            /* [in] */ ISubmitSMCom *isubmit,
            /* [out] */ BSTR *pMsgid,
            /* [retval][out] */ VARIANT_BOOL *pret);
        
        END_INTERFACE
    } IEsmeTransceiverComVtbl;

    interface IEsmeTransceiverCom
    {
        CONST_VTBL struct IEsmeTransceiverComVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IEsmeTransceiverCom_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IEsmeTransceiverCom_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IEsmeTransceiverCom_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IEsmeTransceiverCom_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IEsmeTransceiverCom_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IEsmeTransceiverCom_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IEsmeTransceiverCom_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IEsmeTransceiverCom_bind(This,sysid,passwd,systype,iaddr,pret)	\
    (This)->lpVtbl -> bind(This,sysid,passwd,systype,iaddr,pret)

#define IEsmeTransceiverCom_unbind(This,pret)	\
    (This)->lpVtbl -> unbind(This,pret)

#define IEsmeTransceiverCom_enquireLink(This,pret)	\
    (This)->lpVtbl -> enquireLink(This,pret)

#define IEsmeTransceiverCom_init(This,svrip,port)	\
    (This)->lpVtbl -> init(This,svrip,port)

#define IEsmeTransceiverCom_close(This)	\
    (This)->lpVtbl -> close(This)

#define IEsmeTransceiverCom_get_Connected(This,pVal)	\
    (This)->lpVtbl -> get_Connected(This,pVal)

#define IEsmeTransceiverCom_submitMessage(This,isubmit,pMsgid,pret)	\
    (This)->lpVtbl -> submitMessage(This,isubmit,pMsgid,pret)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IEsmeTransceiverCom_bind_Proxy( 
    IEsmeTransceiverCom * This,
    /* [in] */ BSTR sysid,
    /* [in] */ BSTR passwd,
    /* [in] */ BSTR systype,
    /* [in] */ ISmppAddressCom *iaddr,
    /* [retval][out] */ VARIANT_BOOL *pret);


void __RPC_STUB IEsmeTransceiverCom_bind_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IEsmeTransceiverCom_unbind_Proxy( 
    IEsmeTransceiverCom * This,
    /* [retval][out] */ VARIANT_BOOL *pret);


void __RPC_STUB IEsmeTransceiverCom_unbind_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IEsmeTransceiverCom_enquireLink_Proxy( 
    IEsmeTransceiverCom * This,
    /* [retval][out] */ VARIANT_BOOL *pret);


void __RPC_STUB IEsmeTransceiverCom_enquireLink_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IEsmeTransceiverCom_init_Proxy( 
    IEsmeTransceiverCom * This,
    /* [in] */ BSTR svrip,
    /* [in] */ LONG port);


void __RPC_STUB IEsmeTransceiverCom_init_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IEsmeTransceiverCom_close_Proxy( 
    IEsmeTransceiverCom * This);


void __RPC_STUB IEsmeTransceiverCom_close_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IEsmeTransceiverCom_get_Connected_Proxy( 
    IEsmeTransceiverCom * This,
    /* [retval][out] */ VARIANT_BOOL *pVal);


void __RPC_STUB IEsmeTransceiverCom_get_Connected_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IEsmeTransceiverCom_submitMessage_Proxy( 
    IEsmeTransceiverCom * This,
    /* [in] */ ISubmitSMCom *isubmit,
    /* [out] */ BSTR *pMsgid,
    /* [retval][out] */ VARIANT_BOOL *pret);


void __RPC_STUB IEsmeTransceiverCom_submitMessage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IEsmeTransceiverCom_INTERFACE_DEFINED__ */


#ifndef __IEsmeReceiverCom_INTERFACE_DEFINED__
#define __IEsmeReceiverCom_INTERFACE_DEFINED__

/* interface IEsmeReceiverCom */
/* [unique][helpstring][nonextensible][dual][uuid][object] */ 


EXTERN_C const IID IID_IEsmeReceiverCom;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("57E38123-98A1-4219-8CB6-EF45A5428238")
    IEsmeReceiverCom : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE bind( 
            /* [in] */ BSTR sysid,
            /* [in] */ BSTR passwd,
            /* [in] */ BSTR systype,
            /* [in] */ ISmppAddressCom *iaddr,
            /* [retval][out] */ VARIANT_BOOL *pret) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE unbind( 
            /* [retval][out] */ VARIANT_BOOL *pret) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE enquireLink( 
            /* [retval][out] */ VARIANT_BOOL *pret) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE init( 
            /* [in] */ BSTR svrip,
            /* [in] */ LONG port) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE close( void) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Connected( 
            /* [retval][out] */ VARIANT_BOOL *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IEsmeReceiverComVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            IEsmeReceiverCom * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            IEsmeReceiverCom * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            IEsmeReceiverCom * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            IEsmeReceiverCom * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            IEsmeReceiverCom * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            IEsmeReceiverCom * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            IEsmeReceiverCom * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *bind )( 
            IEsmeReceiverCom * This,
            /* [in] */ BSTR sysid,
            /* [in] */ BSTR passwd,
            /* [in] */ BSTR systype,
            /* [in] */ ISmppAddressCom *iaddr,
            /* [retval][out] */ VARIANT_BOOL *pret);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *unbind )( 
            IEsmeReceiverCom * This,
            /* [retval][out] */ VARIANT_BOOL *pret);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *enquireLink )( 
            IEsmeReceiverCom * This,
            /* [retval][out] */ VARIANT_BOOL *pret);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *init )( 
            IEsmeReceiverCom * This,
            /* [in] */ BSTR svrip,
            /* [in] */ LONG port);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *close )( 
            IEsmeReceiverCom * This);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE *get_Connected )( 
            IEsmeReceiverCom * This,
            /* [retval][out] */ VARIANT_BOOL *pVal);
        
        END_INTERFACE
    } IEsmeReceiverComVtbl;

    interface IEsmeReceiverCom
    {
        CONST_VTBL struct IEsmeReceiverComVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IEsmeReceiverCom_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IEsmeReceiverCom_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IEsmeReceiverCom_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IEsmeReceiverCom_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IEsmeReceiverCom_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IEsmeReceiverCom_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IEsmeReceiverCom_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IEsmeReceiverCom_bind(This,sysid,passwd,systype,iaddr,pret)	\
    (This)->lpVtbl -> bind(This,sysid,passwd,systype,iaddr,pret)

#define IEsmeReceiverCom_unbind(This,pret)	\
    (This)->lpVtbl -> unbind(This,pret)

#define IEsmeReceiverCom_enquireLink(This,pret)	\
    (This)->lpVtbl -> enquireLink(This,pret)

#define IEsmeReceiverCom_init(This,svrip,port)	\
    (This)->lpVtbl -> init(This,svrip,port)

#define IEsmeReceiverCom_close(This)	\
    (This)->lpVtbl -> close(This)

#define IEsmeReceiverCom_get_Connected(This,pVal)	\
    (This)->lpVtbl -> get_Connected(This,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IEsmeReceiverCom_bind_Proxy( 
    IEsmeReceiverCom * This,
    /* [in] */ BSTR sysid,
    /* [in] */ BSTR passwd,
    /* [in] */ BSTR systype,
    /* [in] */ ISmppAddressCom *iaddr,
    /* [retval][out] */ VARIANT_BOOL *pret);


void __RPC_STUB IEsmeReceiverCom_bind_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IEsmeReceiverCom_unbind_Proxy( 
    IEsmeReceiverCom * This,
    /* [retval][out] */ VARIANT_BOOL *pret);


void __RPC_STUB IEsmeReceiverCom_unbind_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IEsmeReceiverCom_enquireLink_Proxy( 
    IEsmeReceiverCom * This,
    /* [retval][out] */ VARIANT_BOOL *pret);


void __RPC_STUB IEsmeReceiverCom_enquireLink_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IEsmeReceiverCom_init_Proxy( 
    IEsmeReceiverCom * This,
    /* [in] */ BSTR svrip,
    /* [in] */ LONG port);


void __RPC_STUB IEsmeReceiverCom_init_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IEsmeReceiverCom_close_Proxy( 
    IEsmeReceiverCom * This);


void __RPC_STUB IEsmeReceiverCom_close_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IEsmeReceiverCom_get_Connected_Proxy( 
    IEsmeReceiverCom * This,
    /* [retval][out] */ VARIANT_BOOL *pVal);


void __RPC_STUB IEsmeReceiverCom_get_Connected_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IEsmeReceiverCom_INTERFACE_DEFINED__ */



#ifndef __SMPPCOMLib_LIBRARY_DEFINED__
#define __SMPPCOMLib_LIBRARY_DEFINED__

/* library SMPPCOMLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_SMPPCOMLib;

EXTERN_C const CLSID CLSID_SubmitSMCom;

#ifdef __cplusplus

class DECLSPEC_UUID("EC69E685-1C42-41A0-B941-1504F6AC17AD")
SubmitSMCom;
#endif

EXTERN_C const CLSID CLSID_DeliverSMCom;

#ifdef __cplusplus

class DECLSPEC_UUID("A79C8B2C-C8A8-4AB2-8942-E74BB8E7C202")
DeliverSMCom;
#endif

EXTERN_C const CLSID CLSID_SmppDateCom;

#ifdef __cplusplus

class DECLSPEC_UUID("A4A12ED6-F39A-4801-B626-74A2BC332A56")
SmppDateCom;
#endif

EXTERN_C const CLSID CLSID_SmppAddressCom;

#ifdef __cplusplus

class DECLSPEC_UUID("8E5E31AA-DA91-4D7D-868B-945CB4CF6E02")
SmppAddressCom;
#endif

EXTERN_C const CLSID CLSID_EsmeTransmitterCom;

#ifdef __cplusplus

class DECLSPEC_UUID("E8A13A9B-72A2-444E-AA3C-1C7ADBD4BE5E")
EsmeTransmitterCom;
#endif

#ifndef ___IEsmeTransceiverComEvents_DISPINTERFACE_DEFINED__
#define ___IEsmeTransceiverComEvents_DISPINTERFACE_DEFINED__

/* dispinterface _IEsmeTransceiverComEvents */
/* [helpstring][uuid] */ 


EXTERN_C const IID DIID__IEsmeTransceiverComEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("FBD47734-D76D-4327-8AF2-3FD334ECC1A2")
    _IEsmeTransceiverComEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _IEsmeTransceiverComEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            _IEsmeTransceiverComEvents * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            _IEsmeTransceiverComEvents * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            _IEsmeTransceiverComEvents * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            _IEsmeTransceiverComEvents * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            _IEsmeTransceiverComEvents * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            _IEsmeTransceiverComEvents * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            _IEsmeTransceiverComEvents * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        END_INTERFACE
    } _IEsmeTransceiverComEventsVtbl;

    interface _IEsmeTransceiverComEvents
    {
        CONST_VTBL struct _IEsmeTransceiverComEventsVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _IEsmeTransceiverComEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _IEsmeTransceiverComEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _IEsmeTransceiverComEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _IEsmeTransceiverComEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _IEsmeTransceiverComEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _IEsmeTransceiverComEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _IEsmeTransceiverComEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___IEsmeTransceiverComEvents_DISPINTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_EsmeTransceiverCom;

#ifdef __cplusplus

class DECLSPEC_UUID("270CF62C-9385-4D01-900A-9C221199A3B0")
EsmeTransceiverCom;
#endif

#ifndef ___IEsmeReceiverComEvents_DISPINTERFACE_DEFINED__
#define ___IEsmeReceiverComEvents_DISPINTERFACE_DEFINED__

/* dispinterface _IEsmeReceiverComEvents */
/* [helpstring][uuid] */ 


EXTERN_C const IID DIID__IEsmeReceiverComEvents;

#if defined(__cplusplus) && !defined(CINTERFACE)

    MIDL_INTERFACE("0BD6067E-7EF9-4576-B583-DD603ADF8BCC")
    _IEsmeReceiverComEvents : public IDispatch
    {
    };
    
#else 	/* C style interface */

    typedef struct _IEsmeReceiverComEventsVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            _IEsmeReceiverComEvents * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            _IEsmeReceiverComEvents * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            _IEsmeReceiverComEvents * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            _IEsmeReceiverComEvents * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            _IEsmeReceiverComEvents * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            _IEsmeReceiverComEvents * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            _IEsmeReceiverComEvents * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        END_INTERFACE
    } _IEsmeReceiverComEventsVtbl;

    interface _IEsmeReceiverComEvents
    {
        CONST_VTBL struct _IEsmeReceiverComEventsVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define _IEsmeReceiverComEvents_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define _IEsmeReceiverComEvents_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define _IEsmeReceiverComEvents_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define _IEsmeReceiverComEvents_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define _IEsmeReceiverComEvents_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define _IEsmeReceiverComEvents_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define _IEsmeReceiverComEvents_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)

#endif /* COBJMACROS */


#endif 	/* C style interface */


#endif 	/* ___IEsmeReceiverComEvents_DISPINTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_EsmeReceiverCom;

#ifdef __cplusplus

class DECLSPEC_UUID("6CC2B796-F91D-452F-BB3D-1A921F8D5D35")
EsmeReceiverCom;
#endif
#endif /* __SMPPCOMLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long *, unsigned long            , BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserMarshal(  unsigned long *, unsigned char *, BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserUnmarshal(unsigned long *, unsigned char *, BSTR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long *, BSTR * ); 

unsigned long             __RPC_USER  VARIANT_UserSize(     unsigned long *, unsigned long            , VARIANT * ); 
unsigned char * __RPC_USER  VARIANT_UserMarshal(  unsigned long *, unsigned char *, VARIANT * ); 
unsigned char * __RPC_USER  VARIANT_UserUnmarshal(unsigned long *, unsigned char *, VARIANT * ); 
void                      __RPC_USER  VARIANT_UserFree(     unsigned long *, VARIANT * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


