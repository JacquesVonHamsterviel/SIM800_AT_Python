// EsmeReceiver.h: interface for the CEsmeReceiver class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ESMERECEIVER_H__64A6879A_2868_4ABA_9572_9E4A83E0DAE2__INCLUDED_)
#define AFX_ESMERECEIVER_H__64A6879A_2868_4ABA_9572_9E4A83E0DAE2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "SmppConnection.h"

class SMPPLIB_DECLSPEC CEsmeReceiver : public CSmppConnection
{
public:
	CEsmeReceiver();
	virtual ~CEsmeReceiver();

	int bind(CString sysid, CString passwd, CString systype, CSmppAddress &srcrange);

protected:
	void parse_packet(PBYTE pby, int nsz);

	#ifdef SMPPAPI_EVALUATION
		static uint32 m_eval_counter;
	#endif

};

#endif // !defined(AFX_ESMERECEIVER_H__64A6879A_2868_4ABA_9572_9E4A83E0DAE2__INCLUDED_)
