// SmppLibTest.h: interface for the CSmppLibTest class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SMPPLIBTEST_H__FBBDBED7_43CC_4939_BCCC_982299CE7A66__INCLUDED_)
#define AFX_SMPPLIBTEST_H__FBBDBED7_43CC_4939_BCCC_982299CE7A66__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

struct ClientContext;
class CIOCPServer;
#include "..\smpppacket.h"

//class CPacketBase;

class CSmppLibTest  
{
public:
	CSmppLibTest(CIOCPServer *pIOCPServer);

	virtual ~CSmppLibTest();

	void parsePacket(ClientContext *pContext, PBYTE pby, int nsz);

	bool sendPacket(ClientContext *pContext, CPacketBase &pak);

	CIOCPServer *m_pIOCPServer;
};

#endif // !defined(AFX_SMPPLIBTEST_H__FBBDBED7_43CC_4939_BCCC_982299CE7A66__INCLUDED_)
