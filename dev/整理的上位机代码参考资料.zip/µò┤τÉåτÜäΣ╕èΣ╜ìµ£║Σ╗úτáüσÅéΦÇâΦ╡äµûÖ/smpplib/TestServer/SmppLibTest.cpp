// SmppLibTest.cpp: implementation of the CSmppLibTest class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TestServer.h"
#include "SmppLibTest.h"
#include "IOCPServer.h"

#include "..\common.h"
#include "..\smpp.h"
#include "..\smpppacket.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSmppLibTest::CSmppLibTest(CIOCPServer *pIOCPServer)
{
	m_pIOCPServer = pIOCPServer;
}

CSmppLibTest::~CSmppLibTest()
{

}

//create the packet here, and pass to processpacket
void CSmppLibTest::parsePacket(ClientContext *pContext, PBYTE pby, int nsz)
{
	TRACE1("parse packet %d\n", nsz);

	if (nsz < 16)
		return;

	uint32 cmdId = readInt(pby);
	
	TCHAR buff[100];
	sprintf(buff, "MessageId is %x\n", cmdId);
	TRACE(buff);

	int cmdStatus = readInt(pby+4);
	int seqNum = readInt(pby+8);

	switch (cmdId)
	{
		case SMPP_BIND_TRANSMITTER:
		{
			CBindTransmitter* ppak;
			ppak = new CBindTransmitter();
			ppak->loadPacket(pby, nsz);

			CBindTransmitterResp pak;
			sendPacket(pContext, pak);

			delete ppak;
		}
			break;

		case SMPP_BIND_TRANSMITTER_RESP:
		{
			CBindTransmitterResp* ppak;
			ppak = new CBindTransmitterResp();
			ppak->loadPacket(pby, nsz);

			delete ppak;
		}
			break;

		case SMPP_BIND_RECEIVER:
		{
			CBindReceiver* ppak;
			ppak = new CBindReceiver();
			ppak->loadPacket(pby, nsz);

			CBindReceiverResp pak;
			sendPacket(pContext, pak);

			delete ppak;
		}
			break;

		case SMPP_BIND_RECEIVER_RESP:
		{
			CBindReceiverResp* ppak;
			ppak = new CBindReceiverResp();
			ppak->loadPacket(pby, nsz);

			delete ppak;
		}
			break;

		case SMPP_BIND_TRANSCEIVER:
		{
			CBindTransceiver* ppak;
			ppak = new CBindTransceiver();
			ppak->loadPacket(pby, nsz);

			TRACE(ppak->getSystemId());
			TRACE("\n");
			TRACE(ppak->getSystemType());
			TRACE("\n");
			TRACE(ppak->getPassword());
			TRACE("\n");

			CSmppAddress src_adr;
			src_adr = ppak->getSourceRange();
			TRACE(src_adr.m_addr);
			TRACE("\n");

			//reply
			CBindTransceiverResp pak;
			pak.setSystemId("KOTY-AB");
			pak.setCommandStatus(0);

			sendPacket(pContext, pak);

			delete ppak;
		}
			break;

		case SMPP_BIND_TRANSCEIVER_RESP:
		{
			CBindTransceiverResp* ppak;
			ppak = new CBindTransceiverResp();
			ppak->loadPacket(pby, nsz);

			delete ppak;
		}
			break;

		case SMPP_SUBMIT_SM:
		{
			CSubmitSM* ppak;
			ppak = new CSubmitSM();
			ppak->loadPacket(pby, nsz);

			CSmppAddress src = ppak->getSource();
			CSmppAddress dst = ppak->getDestination();

			TRACE("Source address is:\n");
			TRACE(src.m_addr);
			TRACE("\n");

			TRACE("Destination address is:\n");
			TRACE(dst.m_addr);
			TRACE("\n");

			TRACE("Message is:\n");

			PBYTE msg;
			uint32 nsize;
			ppak->getMessage(msg, nsize);
			LPSTR pmsg = new char[nsize+1];
			memcpy(pmsg, msg, nsize);
			pmsg[nsize] = 0;

			TRACE1("%s\n", pmsg);
			delete pmsg;
			delete msg;

			//reply
			CSubmitSMResp pak;
			pak.setMessageId("EABC3141414521265254562553");
			pak.setCommandStatus(0);

			sendPacket(pContext, pak);

			delete ppak;
		}
			break;

		case SMPP_SUBMIT_SM_RESP:
		{
			CSubmitSMResp* ppak;
			ppak = new CSubmitSMResp();
			ppak->loadPacket(pby, nsz);

			delete ppak;
		}
			break;

		case SMPP_DELIVER_SM:
		{
			CDeliverSM*	ppak;
			ppak = new CDeliverSM();
			ppak->loadPacket(pby, nsz);

			delete ppak;
		}
			break;

		case SMPP_DELIVER_SM_RESP:
		{
			CDeliverSMResp*	ppak;
			ppak = new CDeliverSMResp();
			ppak->loadPacket(pby, nsz);

			delete ppak;
		}
			break;

		case SMPP_UNBIND:
		{
			TRACE("Unbind Received");

			CUnbind* ppak;
			ppak = new CUnbind();
			ppak->loadPacket(pby, nsz);

			//reply
			CUnbindResp pak;
			pak.setCommandStatus(0);

			sendPacket(pContext, pak);

			delete ppak;
		}
			break;

		case SMPP_UNBIND_RESP:
		{
			CUnbindResp* ppak;
			ppak = new CUnbindResp();
			ppak->loadPacket(pby, nsz);

			delete ppak;
		}
			break;


		case SMPP_ENQUIRE_LINK:
		{
			CEnquireLink* ppak;
			ppak = new CEnquireLink();
			ppak->loadPacket(pby, nsz);

			CEnquireLinkResp pak;
			pak.setCommandStatus(0);

			sendPacket(pContext, pak);

			delete ppak;

			//testing deliversm
			CDeliverSM dsm;
			CString msg = "Hello, how are you?";
			CSmppAddress adr(1, 2, "567890");
			dsm.setDataCoding(4);
			dsm.setSource(adr);
			dsm.setDestination(adr);
			dsm.setMessage((PBYTE)msg.GetBuffer(0), msg.GetLength());
			sendPacket(pContext, dsm);
		}
			break;

		case SMPP_QUERY_SM:
		{
			CQuerySM* ppak;
			ppak = new CQuerySM();
			ppak->loadPacket(pby, nsz);

			CQuerySMResp pak;
			pak.setErrorCode(11);
			pak.setMessageId("BCAAA213");

			sendPacket(pContext, pak);
		}
			break;

		default:
			break;

	}	//switch

}	//parse packet

bool CSmppLibTest::sendPacket(ClientContext *pContext, CPacketBase &pak)
{
	bool ret = true;

	PBYTE pby;
	int nsz;

	pak.encodeBody(pby, nsz);
	m_pIOCPServer->Send(pContext, pby, nsz);

	delete [] pby;

	return ret;
}