
#define SMPPAPI_GOLD

#define DEFAULT_PORT	5000

//#define DllExport   __declspec( dllexport ) 

#ifdef _EXPORTING
   #define CLASS_DECLSPEC    __declspec(dllexport)
#else
   #define CLASS_DECLSPEC    __declspec(dllimport)
#endif


//##ModelId=3B70A7690168
typedef unsigned short  ushort;
//##ModelId=3B70A7690186
typedef unsigned int    uint;
//##ModelId=3B70A769019A
typedef unsigned char	uchar;
//##ModelId=3B70A76901AE
typedef char	int8;		/* Signed integer >= 8	bits */
//##ModelId=3B70A76901C2
typedef short	int16;		/* Signed integer >= 16 bits */
//##ModelId=3B70A76901D6
typedef unsigned char	uint8;	/* Short for unsigned integer >= 8  bits */
//##ModelId=3B70A76901EB
typedef unsigned short	uint16; /* Short for unsigned integer >= 16 bits */
//##ModelId=3B70A7690200
typedef int		int32;
//##ModelId=3B70A769021D
typedef unsigned int	uint32; /* Short for unsigned integer >= 32 bits */
//##ModelId=3B70A7690231
typedef unsigned long ulong;
//##ModelId=3B70A7690245
typedef unsigned hyper ulonglong;


// Optimized store functions for Intel x86 

#define sint2korr(A)	(*((int16 *) (A)))
#define sint3korr(A)	((int32) ((((uchar) (A)[2]) & 128) ? \
				  (((uint32) 255L << 24) | \
				   (((uint32) (uchar) (A)[2]) << 16) |\
				   (((uint32) (uchar) (A)[1]) << 8) | \
				   ((uint32) (uchar) (A)[0])) : \
				  (((uint32) (uchar) (A)[2]) << 16) |\
				  (((uint32) (uchar) (A)[1]) << 8) | \
				  ((uint32) (uchar) (A)[0])))
#define sint4korr(A)	(*((long *) (A)))
#define uint2korr(A)	(*((uint16 *) (A)))
#define uint3korr(A)	(long) (*((unsigned long *) (A)) & 0xFFFFFF)
#define uint4korr(A)	(*((unsigned long *) (A)))
#define uint5korr(A)	((ulonglong)(((uint32) ((uchar) (A)[0])) +\
				    (((uint32) ((uchar) (A)[1])) << 8) +\
				    (((uint32) ((uchar) (A)[2])) << 16) +\
				    (((uint32) ((uchar) (A)[3])) << 24)) +\
			 	    (((ulonglong) ((uchar) (A)[4])) << 32))
#define uint8korr(A)	(*((ulonglong *) (A)))
#define sint8korr(A)	(*((longlong *) (A)))
#define int2store(T,A)	*((uint16*) (T))= (uint16) (A)
#define int3store(T,A)		{ *(T)=  (uchar) ((A));\
				  *(T+1)=(uchar) (((uint) (A) >> 8));\
				  *(T+2)=(uchar) (((A) >> 16)); }
#define int4store(T,A)	*((long *) (T))= (long) (A)
#define int5store(T,A)	{ *(T)= (uchar)((A));\
			  *((T)+1)=(uchar) (((A) >> 8));\
			  *((T)+2)=(uchar) (((A) >> 16));\
			  *((T)+3)=(uchar) (((A) >> 24)); \
			  *((T)+4)=(uchar) (((A) >> 32)); }
#define int8store(T,A)	*((ulonglong *) (T))= (ulonglong) (A)

#define doubleget(V,M)	{ *((long *) &V) = *((long*) M); \
			  *(((long *) &V)+1) = *(((long*) M)+1); }
#define doublestore(T,V) { *((long *) T) = *((long*) &V); \
			   *(((long *) T)+1) = *(((long*) &V)+1); }
#define float4get(V,M) { *((long *) &(V)) = *((long*) (M)); }
#define float8get(V,M) doubleget((V),(M))
#define float4store(V,M) memcpy((byte*) V,(byte*) (&M),sizeof(float))
#define float8store(V,M) doublestore((V),(M))

//Starting here, for Big Endian defition
#define storeInt(T, A) {	\
	*((T)+3) =	(uchar) ((A));	\
	*((T)+2) = (uchar) (((A) >> 8));	\
	*((T)+1) = (uchar) (((A) >> 16));	\
	*(T) = (uchar) (((A) >> 24)); }

#define storeInt2(T, A) {	\
	*((T)+1) = (uchar) (((A)));	\
	*(T) = (uchar) (((A) >> 8)); }

#define readInt(A)	((int) (	\
				    (((int) ((uchar) (A)[0])) << 24) +\
				    (((uint32) ((uchar) (A)[1])) << 16) +\
				    (((uint32) ((uchar) (A)[2])) << 8) +\
					((uchar) (A)[3])))

#define readInt2(A)	((int) (	\
				    (((int) ((uchar) (A)[0])) << 8) +\
					((uchar) (A)[1])))